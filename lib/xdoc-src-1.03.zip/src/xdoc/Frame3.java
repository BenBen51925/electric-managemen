/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;
import org.apache.xerces.impl.xs.*;
import org.apache.xerces.dom.PSVIElementNSImpl;
import org.apache.xerces.parsers.*;
//import org.w3c.dom.DOMConfiguration;

import org.apache.xerces.xni.grammars.*;
// Imported TraX classes
//import xni.Counter;
import java.beans.*;
// Imported java.io classes
// Imported SAX classes
import java.io.*;
import java.net.*;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import org.apache.xerces.parsers.XMLGrammarPreparser;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.plaf.basic.*;
import javax.swing.table.*;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.undo.*;

// Imported Serializer classes
import org.apache.xalan.serialize.Serializer;
import org.apache.xalan.serialize.SerializerFactory;
import org.apache.xalan.templates.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.impl.*;
import org.apache.xerces.impl.xs.*;
import org.apache.xerces.util.*;
import org.apache.xerces.util.XMLGrammarPoolImpl.*;
import org.apache.xerces.xni.*;
import org.apache.xerces.xni.parser.*;
import org.apache.xerces.xs.*;
import org.apache.xml.serialize.*;
// Imported Serializer classes
// Imported Serializer classes
import org.w3c.dom.*;
// Imported DOM classes
import org.w3c.dom.Document;
import org.w3c.dom.Element;
// Imported DOM classes
import org.xml.sax.*;
//import com.borland.jbcl.layout.*;
//import ui.*;



/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Frame3 extends JFrame {
  PSVIElementNSImpl asdf;
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  JMenuItem jMenuItem3 = new JMenuItem();
  TableModel errorModel = new ErrorTableModel();

  JPopupMenu popm=new JPopupMenu();


  String currFileName = null;  // Full path with filename. null means new/untitled.
  boolean dirty=false;
  static int WARNING = 0;
  static int ERROR=1;
  static int FATAL_ERROR=2;
  ErrorStorer ef = new ErrorStorer();;
  EntityResolver es = new MyEntityResolver();
  class MyEntityResolver implements EntityResolver {

  public InputSource resolveEntity(String string, String string1) throws SAXException, IOException {
    System.out.println(string+"->"+string1);
    return null;
  }
  }

   XMLEntityResolver es2 = new MyXMLEntityResolver();
   class MyXMLEntityResolver extends EntityResolverWrapper {

     public XMLInputSource resolveEntity(XMLResourceIdentifier resourceIdentifier)
         throws XNIException, IOException {
       XMLInputSource src = super.resolveEntity(resourceIdentifier);
       //We choose strategy 3 at http://www.w3.org/TR/xmlschema-1/#schema_reference

         if (src == null && resourceIdentifier != null &&
             resourceIdentifier.getNamespace() != null &&
             (resourceIdentifier.getExpandedSystemId() == null ||
              resourceIdentifier instanceof XMLSchemaDescription && ((XMLSchemaDescription)resourceIdentifier).getContextType()>=XMLSchemaDescription.CONTEXT_IMPORT && !resourceIdentifier.getExpandedSystemId().startsWith("file:"))) {
           //exclude the CONTEXT_INCLUDE and CONTEXT_REDEFINE context since then the standard schema of the target namespace is not wanted
           MapNamespace map = ConfigureNamespacesDialog.getMappingFor(resourceIdentifier.
               getNamespace());
           if (map == null && resourceIdentifier.getExpandedSystemId() == null)
             map = DialogSchemaLocation.getNewMappingFor(resourceIdentifier.
                 getNamespace(), Frame3.this);
           if (map!=null && map.isDTD())
             map = null;
           if (map == null || !map.hasLocation())
             src = null; else
             src = new XMLInputSource(null, map.getExpandedSystemId(), null);
         }
         if (src==null && resourceIdentifier != null && resourceIdentifier.getExpandedSystemId()!=null)
           //if ("http://www.w3.org/2001/XMLSchema.dtd".equals(resourceIdentifier.getExpandedSystemId()))
           //  src = new XMLInputSource(null, "schema/XMLSchema/XMLSchema.xsd", System.getProperty( "user.dir" )+"/"); else
           if (resourceIdentifier.getExpandedSystemId().endsWith("xhtml-lat1.ent"))
             src = new XMLInputSource(null, "dtd/xhtml-lat1.ent", /*System.getProperty( "user.dir" )+"/"*/null); else
           if (resourceIdentifier.getExpandedSystemId().endsWith("xhtml-symbol.ent"))
             src = new XMLInputSource(null, "dtd/xhtml-symbol.ent", /*System.getProperty( "user.dir" )+"/"*/null); else
           if (resourceIdentifier.getExpandedSystemId().endsWith("xhtml-special.ent"))
             src = new XMLInputSource(null, "dtd/xhtml-special.ent", /*System.getProperty( "user.dir" )+"/"*/null);


         //we need manually add an error since xerces dont (only
         //if we would preparse a schema, but we never,XSDHandler.java, getSchemaDocument(), mustResolve
         String filename=null;
         if (src!=null && src.getSystemId()!=null)
           filename=XMLEntityManager.expandSystemId(src.getSystemId(),src.getBaseSystemId(),false); else
         if (resourceIdentifier != null && resourceIdentifier.getExpandedSystemId() != null)
           filename=XMLEntityManager.expandSystemId(resourceIdentifier.getExpandedSystemId(),null,false);;
         if (filename!=null)
         try {

           //org.apache.xerces.util.URI u = new org.apache.xerces.util.URI(XMLEntityManager.expandSystemId(filename, null, false));

           java.net.URI u = new java.net.URI(XMLEntityManager.expandSystemId(filename, null, false));

           //if (!new File(u.getPath()).exists()) { //erkennt keine whitespaces
           if (!new File(u).exists()) {
             //we only add this error message because Xerces not adds it if it not finds that file in question;
             //we not want to read the file..
             ef.AddErrorUnique(new ParseError(resourceIdentifier != null ? resourceIdentifier.getBaseSystemId() : null, -1, -1, null,
                                              "[Error] " + "Cannot open file \"" +
                                              filename + "\"", null));

           }
         }
       catch (Exception e) {
       }



       return src;
     }

   }


  org.apache.xerces.dom.CoreDocumentImpl newRoot;

  /**
   *  The DOMParserSaveEncoding class extends DOMParser. It also provides
   *  the Java Encoding of the XML document by overriding the startDocument method
   *  and providing a way to capture the MIME encoding from the XML document which
   *  in turn is converted to the Java Encoding by the internal MIME2Java class.
   *
   */


  public class DOMParserSaveEncoding extends DOMParser {
      String _mimeEncoding = "UTF-8";//Default  MIME so we check the file.encoding
      private void setMimeEncoding( String encoding ) {
          _mimeEncoding = encoding;
      }
      private String getMimeEncoding() {
          return(_mimeEncoding);
      }
      public String getJavaEncoding() {
          String javaEncoding = null;
          String mimeEncoding = getMimeEncoding();

          if (mimeEncoding != null) {
              if (mimeEncoding.equals( "DEFAULT" ))
                  javaEncoding =  "UTF8";
              else if (mimeEncoding.equalsIgnoreCase( "UTF-16" ))
                  javaEncoding = "Unicode";
              else
                  javaEncoding = EncodingMap.getIANA2JavaMapping( mimeEncoding );
          }
          if(javaEncoding == null)   // Should never return null
              javaEncoding = "UTF8";
          return(javaEncoding);
      }
      public void startGeneralEntity(String name,
                              XMLResourceIdentifier identifier,
                              String encoding, Augmentations augs) throws XNIException {
          if( encoding != null){
              setMimeEncoding( encoding);
          }
          super.startGeneralEntity(name, identifier, encoding, augs);
      }

  }



  DOMParserSaveEncoding parser;
  Border border1;
  JMenu jMenuAfter = new JMenu();
  JMenu jMenuBefore = new JMenu();
  JMenu jMenuAddChild = new JMenu();

  class MyDOMNormalizer extends DOMNormalizer {

  }

  //Construct the frame
  public Frame3() {
      //System.out.println(userDir);        StringToFile(currFileName,jTextXML.getText().getBytes(EncodingMap.getIANA2JavaMapping(getOutputEncoding())));

    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      parser = new DOMParserSaveEncoding();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }

  DefaultListSelectionModel errorSel=new DefaultListSelectionModel();
  DefaultListSelectionModel attrSel=new DefaultListSelectionModel();

  protected String userDir="";

  //Component initialization
  private void jbInit() throws Exception  {

    boxLayout21 = new BoxLayout(jPanel2,BoxLayout.Y_AXIS);
    boxLayout22 = new BoxLayout(jPanel4,BoxLayout.Y_AXIS);
    boxLayout23 = new BoxLayout(jPanel3,BoxLayout.X_AXIS);
    boxLayout25 = new BoxLayout(jPanel6,BoxLayout.Y_AXIS);
    boxLayout24 = new BoxLayout(jPanel5,BoxLayout.Y_AXIS);

    document1 = jTextXML.getDocument();
    document2 = jTextContent.getDocument();
    // Add this as a listener for undoable edits.
    border6 = BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178)),BorderFactory.createEmptyBorder(0,6,0,0));
    document1.addUndoableEditListener(undoHandler);


    border1 = BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(103, 101, 98),new Color(148, 145, 140));
    border2 = BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(103, 101, 98),new Color(148, 145, 140)),BorderFactory.createEmptyBorder(13,13,13,13));
    border3 = BorderFactory.createLineBorder(Color.white,1);
    border4 = BorderFactory.createEmptyBorder(7,0,0,0);
    border5 = BorderFactory.createEmptyBorder(7,0,0,0);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setLocale(java.util.Locale.getDefault());
    setJMenuBar(jMenuBar1);
    setResizable(true);
    setSize(new Dimension(675, 626));
    getContentPane().setLayout(gridBagLayout1);
    addWindowListener(new Frame3_this_windowAdapter(this));
    jMenuFile.setText("File");
    jMenuItem1.setText("Open");
    jMenuItem1.addActionListener(new Frame3_jMenuItem1_actionAdapter(this));
    jMenuItem2.setText("Save");
    jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke('S', java.awt.event.KeyEvent.CTRL_MASK, false));
    jMenuItem2.addActionListener(new Frame3_jMenuItem2_actionAdapter(this));
    jMenuItem3.setText("Exit");
    jMenuItem3.addActionListener(new Frame3_jMenuItem3_actionAdapter(this));
    jMenuAfter.setText("Insert Element After");
    jMenuAfter.addMenuListener(new Frame3_jMenuAfter_menuAdapter(this));
    jMenuBefore.setText("Insert Element Before");
    jMenuBefore.addActionListener(new Frame3_jMenuBefore_actionAdapter(this));
    jMenuBefore.addMenuListener(new Frame3_jMenuBefore_menuAdapter(this));
    jMenuAddChild.setText("Append Child Element");
    jMenuAddChild.addMenuListener(new Frame3_jMenuAddChild_menuAdapter(this));
    jMenuItem6.setToolTipText("");
    jMenuItem6.setText("About");
    jMenuItem6.addActionListener(new Frame3_jMenuItem6_actionAdapter(this));
    jMenuItem7.setText("Save As");
    jMenuItem7.addActionListener(new Frame3_jMenuItem7_actionAdapter(this));
    jMenu3.setText("Help");
    jTextAfter.setAlignmentY((float) 0.0);
    jTextAfter.setAlignmentX((float) 0.0);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setAlignmentY((float) 0.0);
    jPanel4.setBorder(null);
    jLabel1.setBorder(border5);
    jLabel1.setMaximumSize(new Dimension(153, 20));
    jLabel1.setMinimumSize(new Dimension(153, 20));
    jLabel1.setPreferredSize(new Dimension(153, 20));
    jLabel1.setRequestFocusEnabled(true);
    jLabel1.setText("Text before this node:");
    jLabel3.setText("Text content:");
    jLabel3.setPreferredSize(new Dimension(153, 20));
    jLabel3.setMinimumSize(new Dimension(153, 20));
    jLabel3.setBorder(border5);
    jLabel3.setMaximumSize(new Dimension(153, 20));
    jTextContent.setAlignmentX((float) 0.0);
    jTextContent.setAlignmentY((float) 0.0);
    jTextContent.setDoubleBuffered(false);
    jTextContent.setText("");
    jTextContent.setRows(0);
    m_tree.setBackground(Color.lightGray);
    m_tree.setRootVisible(false);
    m_tree.setScrollsOnExpand(true);
    m_tree.addKeyListener(new Frame3_m_tree_keyAdapter(this));
    m_tree.addMouseListener(new Frame3_m_tree_mouseAdapter(this));
    m_tree.addTreeSelectionListener(new Frame3_m_tree_treeSelectionAdapter(this));
    jScrollPane5.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    jScrollPane5.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    jScrollPane5.setAlignmentX((float) 0.0);
    jScrollPane5.setAlignmentY((float) 0.0);
    jScrollPane5.setAutoscrolls(true);
    jScrollPane5.setMaximumSize(new Dimension(32767, 100));
    jScrollPane5.setPreferredSize(new Dimension(53, 100));
    jLabel2.setBorder(border5);
    jLabel2.setMaximumSize(new Dimension(153, 20));
    jLabel2.setMinimumSize(new Dimension(153, 20));
    jLabel2.setPreferredSize(new Dimension(153, 20));
    jLabel2.setToolTipText("");
    jLabel2.setText("Text after this node:");
    jScrollPane4.setAlignmentX((float) 0.0);
    jScrollPane4.setAlignmentY((float) 0.0);
    jScrollPane4.setAutoscrolls(false);
    jScrollPane4.setMaximumSize(new Dimension(32767, 100));
    jScrollPane4.setOpaque(true);
    jScrollPane4.setPreferredSize(new Dimension(32, 100));
    jSplitPane1.setBorder(null);
    jSplitPane1.setMaximumSize(new Dimension(32767, 32767));
    jTextBefore.setRows(0);
    jTextBefore.setTabSize(8);
    jTextBefore.setAlignmentY((float) 0.0);
    jTextBefore.setMinimumSize(new Dimension(28, 17));
    jTextBefore.setText("");
    jTextBefore.setAlignmentX((float) 0.0);
    jPanel2.setLayout(boxLayout21);
    jPanel2.setDebugGraphicsOptions(0);
    jPanel2.setMinimumSize(new Dimension(207, 681));
    jPanel2.setOpaque(false);
    jPanel2.setPreferredSize(new Dimension(207, 681));
    jScrollPane2.setAutoscrolls(true);
    jScrollPane2.setBorder(null);
    jScrollPane2.setMinimumSize(new Dimension(207, 681));
    jScrollPane2.setOpaque(false);
    jScrollPane2.setPreferredSize(new Dimension(207, 681));
    jScrollPane6.setAlignmentX((float) 0.0);
    jScrollPane6.setAlignmentY((float) 0.0);
    jScrollPane6.setMaximumSize(new Dimension(32767, 100));
    jScrollPane6.setPreferredSize(new Dimension(32, 100));
    jLabel5.setBorder(border4);
    jLabel5.setMaximumSize(new Dimension(153, 20));
    jLabel5.setMinimumSize(new Dimension(153, 20));
    jLabel5.setPreferredSize(new Dimension(153, 20));
    jLabel5.setText("Attributes:");

    jTable1.setBackground(Color.lightGray);
    jTable1.setAlignmentX((float) 0.0);
    jTable1.setAlignmentY((float) 0.0);
    jTable1.setBorder(BorderFactory.createLoweredBevelBorder());
    jTable1.setAutoCreateColumnsFromModel(!false);
    jTable1.setSelectionModel(attrSel);
    jTable1.addKeyListener(new Frame3_jTable1_keyAdapter(this));
    jTable1.setRowHeight(23); //high for jComboBox
    jTable1.setModel(dataModel);
    jTable1.createDefaultColumnsFromModel();
    //jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    //boxLayout21.setAxis(BoxLayout.Y_AXIS);
    //boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jMenuBar1.setBorder(null);
    jScrollPane1.setAlignmentX((float) 0.0);
    jScrollPane1.setAlignmentY((float) 0.0);
    jScrollPane1.setAutoscrolls(false);
    jScrollPane1.setPreferredSize(new Dimension(32, 100));
    jMenu1.setText("Edit");
    jMenu1.addMenuListener(new Frame3_jMenu1_menuAdapter(this));
    jMenuDeleteNode.setText("Delete Element");
    jMenuDeleteNode.addActionListener(new Frame3_jMenuDeleteNode_actionAdapter(this));
    jMenuDeleteAttribute.setText("Delete Attribute");
    jMenuDeleteAttribute.addActionListener(new Frame3_jMenuDeleteAttribute_actionAdapter(this));
    jTextXML.setText("XML");
    jTextXML.addMouseListener(new Frame3_jTextXML_mouseAdapter(this));
    jTextXML.addInputMethodListener(new Frame3_jTextXML_inputMethodAdapter(this));
    jScrollPane8.setAlignmentX((float) 0.0);
    jScrollPane8.setAlignmentY((float) 0.0);
    jScrollPane8.setAutoscrolls(false);
    jScrollPane8.setMaximumSize(new Dimension(32767, 32767));
    jScrollPane8.setMinimumSize(new Dimension(525, 104));
    jScrollPane8.setOpaque(true);

    jTable2.setBorder(border3);
    jTable2.setAutoscrolls(true);
    jTable2.setAutoCreateColumnsFromModel(false);
    jTable2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    jTable2.setShowHorizontalLines(false);
    jTable2.addMouseListener(new Frame3_jTable2_mouseAdapter(this));
    jTable2.setSelectionModel(errorSel);
    jTable2.getSelectionModel().setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
    jTable1.getSelectionModel().setSelectionMode (ListSelectionModel.SINGLE_SELECTION);

    //jTable2.setTableHeader(null);
    jPanel1.setLayout(borderLayout1);
    jPanel1.setBackground(Color.red);
    jPanel1.setBorder(null);
    //jPanel1.setDoubleBuffered(true);

    jTabbedPane1.addPropertyChangeListener(new Frame3_jTabbedPane1_propertyChangeAdapter(this));
    jTabbedPane1.addChangeListener(new Frame3_jTabbedPane1_changeAdapter(this));
    jSplitPane2.setOrientation(JSplitPane.VERTICAL_SPLIT);
//    jSplitPane2.setMaximumSize(new Dimension(32767, 32767));
//    jSplitPane2.setLastDividerLocation(300);
    //jSplitPane2.setLeftComponent(jSplitPane1);
    jSplitPane2.setResizeWeight(1.0);
    errorSel.addListSelectionListener(new Frame3_errorSel_listSelectionAdapter(this));
    jMenuItem9.setText("Configure Namespaces");
    jMenuItem9.addActionListener(new Frame3_jMenuItem9_actionAdapter(this));
    jMenuItem8.setText("New");
    jMenuItem8.addActionListener(new Frame3_jMenuItem8_actionAdapter(this));
    jNewFromItem.addActionListener(new Frame3_jNewFromItem_actionAdapter(this));
    jMenuNewFrom.setText("New From..");
    jMenuNewFrom.addMenuListener(new Frame3_jMenuNewFrom_menuAdapter(this));
    jNewFromItem.setText("adfasdf");
    jMenuItem10.setVerifyInputWhenFocusTarget(true);
    jMenuItem10.setText("Show element declaration");
    jMenuItem10.addActionListener(new Frame3_jMenuItem10_actionAdapter(this));
    jButton2.setToolTipText("Save File");



    userDir=""+Expand(this,"closeFile.gif");
    userDir=userDir.substring(0,userDir.lastIndexOf("/",userDir.lastIndexOf("/")-1));
    if (userDir.startsWith("jar:"))
      userDir=userDir.substring(4);
    if (userDir.startsWith("file:/"))
      userDir=userDir.substring(6);
    System.setProperty( "user.dir", userDir);

/*          JOptionPane.showMessageDialog(null,null,
                                userDir,
                                JOptionPane.INFORMATION_MESSAGE);
*/

    jButton2.setIcon(new ImageIcon(Expand(this,"closeFile.gif")));
    jButton2.addActionListener(new Frame3_jButton2_actionAdapter(this));
    jButton1.setToolTipText("Open File");
    jButton1.setIcon(new ImageIcon(Expand(this,"openFile.gif")));
    jButton1.addActionListener(new Frame3_jButton1_actionAdapter(this));
    jButton3.setIcon(new ImageIcon(Expand(this,"help.gif")));
    jButton3.setToolTipText("About");
    jButton3.addActionListener(new Frame3_jButton3_actionAdapter(this));
    toolBar.setAlignmentX((float) 0.0);
    toolBar.setAlignmentY((float) 0.0);
    jButtonAddAttr.setIcon(new ImageIcon(Expand(this,"insert_attribute.gif")));
    jButtonAddAttr.addActionListener(new Frame3_jButtonAddAttr_actionAdapter(this));
    jButtonAddAttr.setToolTipText("Add Attribute");
    jButton5.setIcon(new ImageIcon(Expand(this,"openFile.gif")));
    jButton5.setToolTipText("Open File");
    jButtonAddAfter.setToolTipText("Insert Element After");
    jButtonAddAfter.setIcon(new ImageIcon(Expand(this,"insert_child.gif")));
    jButtonAddBefore.setToolTipText("Insert Element Before");
    jButtonAddBefore.setIcon(new ImageIcon(Expand(this,"insert_child.gif")));
    jButtonAddAfter.setIcon(new ImageIcon(Expand(this,"insert_after.gif")));
    jButtonAddAfter.addActionListener(new Frame3_jButtonAddAfter_actionAdapter(this));
    jButtonAddBefore.setIcon(new ImageIcon(Expand(this,"insert_before.gif")));
    jButtonAddBefore.addActionListener(new Frame3_jButtonAddBefore_actionAdapter(this));
    jButton9.setIcon(new ImageIcon(Expand(this,"insert_before.gif")));
    jButton9.setIcon(new ImageIcon(Expand(this,"insert_child.gif")));
    jButton9.addActionListener(new Frame3_jButton9_actionAdapter(this));
    jButton9.setToolTipText("Append Child Element");
    jButton10.setIcon(new ImageIcon(Expand(this,"insert_before.gif")));
    jButton10.setBorder(null);
    jButton10.setToolTipText("About");
    jButton10.setVerifyInputWhenFocusTarget(true);
    jButton10.setIcon(null);
    jButton10.setText("         ");
    document1.addDocumentListener(new Frame3_document1_documentAdapter(this));
    document2.addDocumentListener(new Frame3_document2_documentAdapter(this));
    jPanel3.setAlignmentX((float) 0.0);
    jPanel3.setAlignmentY((float) 0.0);
    jPanel3.setMaximumSize(new Dimension(32767, 16));
    jPanel3.setMinimumSize(new Dimension(167, 35));
    jPanel3.setLayout(boxLayout23);
    jButtonAddAttr2.setText("Add attribute");
    jButtonAddAttr2.addActionListener(new Frame3_jButtonAddAttr2_actionAdapter(this));
    jButtonDeleteAttr.setText("Delete attribute");
    jButtonDeleteAttr.addActionListener(new Frame3_jButtonDeleteAttr_actionAdapter(this));
    jMenuItem11.setText("Delete Element Without Children");
    jMenuItem11.addActionListener(new Frame3_jMenuItem11_actionAdapter(this));
    jPanel5.setLayout(boxLayout24);
    //boxLayout24.setAxis(BoxLayout.Y_AXIS);
    jPanel6.setLayout(boxLayout25);
    jButton12.setText("Commit !");
    jButton12.addActionListener(new Frame3_jButton12_actionAdapter(this));
    jPanel6.setAlignmentX((float) 0.0);
    jPanel6.setAlignmentY((float) 0.0);
    jMenuItemUndo.setMnemonic('0');
    jMenuItemUndo.setText("Undo");
    jMenuItemUndo.setAccelerator(javax.swing.KeyStroke.getKeyStroke('Z', java.awt.event.KeyEvent.CTRL_MASK, false));
    jMenuItemUndo.addActionListener(new Frame3_jMenuItemUndo_actionAdapter(this));
    jMenuItemRedo.setToolTipText("");
    jMenuItemRedo.setText("Redo");
    jMenuItemRedo.setAccelerator(javax.swing.KeyStroke.getKeyStroke('Z', java.awt.event.KeyEvent.CTRL_MASK | java.awt.event.KeyEvent.SHIFT_MASK, false));
    jMenuItemRedo.addActionListener(new Frame3_jMenuItemRedo_actionAdapter(this));
    jMenuElement.setText("Element");
    jMenuElement.addMenuListener(new Frame3_jMenuElement_menuAdapter(this));
    jTextAfter.getDocument().addDocumentListener(new Frame3_document2_documentAdapter(this));
    jTextBefore.getDocument().addDocumentListener(new Frame3_document2_documentAdapter(this));
    jMenuItem5.setPreferredSize(new Dimension(161, 19));
    jMenuItem5.setFocusPainted(false);
    jMenuItem5.setText("Show attribute declaration");
    jMenuItem5.addActionListener(new Frame3_jMenuItem5_actionAdapter(this));
    jButton13.addActionListener(new Frame3_jButton13_actionAdapter(this));
    jButton13.setActionCommand("Go there!");
    jButton13.setText("Go there!");
    jButton13.addActionListener(new Frame3_jButton13_actionAdapter(this));
    attrSel.setSelectionMode(2);
    attrSel.setLeadSelectionIndex(-1);
    attrSel.addListSelectionListener(new Frame3_attrSel_listSelectionAdapter(this));
    jMenuItem13.setText("Clear Cached Grammars");
    jMenuItem13.addActionListener(new Frame3_jMenuItem13_actionAdapter(this));
    jMenuItem14.setText("Find");
    jMenuItem14.setAccelerator(javax.swing.KeyStroke.getKeyStroke('F', java.awt.event.KeyEvent.CTRL_MASK, false));
    jMenuItem14.addActionListener(new Frame3_jMenuItem14_actionAdapter(this));
    jMenuItem15.setText("Find again");
    jMenuItem15.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3,0,false));
    jMenuItem15.addActionListener(new Frame3_jMenuItem15_actionAdapter(this));
    jMenuItem115.setText("Apply Stylesheet");
    jMenuItem115.addActionListener(new Frame3_jMenuItem115_actionAdapter(this));
    jMenuItem116.setText("Set Stylesheet");
    jMenuItem116.addActionListener(new Frame3_jMenuItem116_actionAdapter(this));
    jMenuItem4.setText("Options");
    jMenuItem4.addActionListener(new Frame3_jMenuItem4_actionAdapter(this));
    menuItem1.setLabel("Copy to clipboard");
    menuItem1.addActionListener(new Frame3_menuItem1_actionAdapter(this));
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenu1);
    jMenuBar1.add(jMenuElement);
    jMenuElement.add(jMenuBefore);
    jMenuElement.add(jMenuAfter);
    jMenuElement.add(jMenuAddChild);
    jMenuElement.add(jMenuDeleteNode);
    jMenuElement.add(jMenuItem11);
    jMenuElement.addSeparator();
    jMenuElement.add(jMenuAddAttribute);
    jMenuBar1.add(jMenu3);
    jMenuFile.add(jMenuNewFrom);
    jMenuFile.add(jMenuItem8);
    jMenuFile.add(jMenuItem1);
    jMenuFile.add(jMenuItem2);
    jMenuFile.add(jMenuItem7);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuItem13);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuItem3);
    jMenu3.add(jMenuItem6);
    jMenuAddAttribute.setText("Add Attribute");

    //this.getContentPane().add(this.jSplitPane1, BorderLayout.WEST);
    jSplitPane1.setDividerLocation(300);
    jSplitPane1.add(jScrollPane3, JSplitPane.LEFT);
    jSplitPane1.add(jTabbedPane1, JSplitPane.RIGHT);
    jScrollPane3.getViewport().add(m_tree);


    jPanel5.add(jScrollPane1);
    jPanel5.add(jPanel6, null);
    jPanel6.add(jButton12, null);
    jTabbedPane1.addTab("Edit", jScrollPane2);
    jTabbedPane1.add(jPanel5, "Source");
    jScrollPane2.getViewport().add(jPanel4, null);
    jSplitPane2.add(jSplitPane1, JSplitPane.LEFT);
    jSplitPane2.add(jScrollPane8, JSplitPane.RIGHT);
    this.getContentPane().add(toolBar,     new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 103), 0, 0));
    toolBar.add(jButton1);
    toolBar.add(jButton2);
    toolBar.add(jButton3);
    toolBar.add(jButton10, null);
    toolBar.add(jButtonAddBefore, null);
    toolBar.add(jButtonAddAfter, null);
    toolBar.add(jButton9, null);
    toolBar.add(jButtonAddAttr);
    jScrollPane8.getViewport().add(jPanel1, null);
    jPanel1.add(jTable2, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTextXML, null);
    jPanel4.add(jLabel5, null);
    jPanel4.add(jTable1, null);
    jPanel4.add(jPanel3, null);
    jPanel3.add(jButtonAddAttr2, null);
    jPanel3.add(jButtonDeleteAttr, null);
    jPanel3.add(jButton13, null);
    jPanel4.add(jLabel1, null);
    jPanel4.add(jScrollPane4, null);
    jPanel4.add(jLabel3, null);
    jPanel4.add(jScrollPane5, null);
    jPanel4.add(jLabel2, null);
    jPanel4.add(jScrollPane6, null);
    jScrollPane6.getViewport().add(jTextAfter, null);
    jScrollPane5.getViewport().add(jTextContent, null);
    jScrollPane4.getViewport().add(jTextBefore, null);
    //this.getContentPane().add(jScrollPane8, BorderLayout.SOUTH);
    jMenuElement.add(jMenuDeleteAttribute);
    jMenuElement.addSeparator();
    jMenu1.add(jMenuItemUndo);
    jMenu1.add(jMenuItemRedo);
    jMenu1.addSeparator();
    jMenu1.add(jMenuItem14);
    jMenu1.add(jMenuItem15);
    jMenu1.addSeparator();
    jMenu1.add(jMenuItem116);
    jMenu1.add(jMenuItem115);
    jMenu1.addSeparator();
    jMenu1.add(jMenuItem9);
    jMenu1.add(jMenuItem4);
    jMenuElement.add(jMenuItem10);
    jMenuElement.add(jMenuItem5);
    this.getContentPane().add(jSplitPane2,  new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), -127, 0));
    jMenuNewFrom.add(jNewFromItem);
    popm.add(menuItem1);



    //Dimension screenSize = Toolkit.getDefaultToolkit ().getScreenSize ();
    //setSize (screenSize);
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING && !okToAbandon()) return;
    super.processWindowEvent(e);
  }



  public static java.net.URL Expand(Window Self,String f) {
   // System.setProperty( "user.dir", getClass().getprogetResource("."))

    try {

//      return getClass().getResource("image/"+f).toString();
      //return XMLEntityManager.expandSystemId(f, "image/", false);
      //java.net.URL ss=Self.getClass().getClassLoader().getResource(f);;
      //System.out.println(ss.toString());

      return Self.getClass().getClassLoader().getResource(f);

//      return XMLEntityManager.expandSystemId(f, getClass().getResource("image/").getPath(), false);
//      return XMLEntityManager.expandSystemId(f, /*System.getProperty("user.dir")+"/image/"*/ (new File("")).getAbsolutePath()+"/image/", false);
//      return (new File("")).getAbsolutePath()+"image"+File.pathSeparator+f;
    }catch(Exception e) {
      return null;
    }
  }



  void jToggleButton1_actionPerformed(ActionEvent e) {
  }

  void jButton1_actionPerformed(ActionEvent e) {
    fileOpen();
//    MyASBuilder.main(new String[]{"-f","-a","D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\Employees.xsd","-i","D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
//    TreeView.main(new String[]{"c:\\xdoc\\po.xml"});
//    TreeView.main(new String[]{"D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
//    Counten.main(new String[]{"D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
//    SaxParser1.main(new String[]{"D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
  }

  // Update the caption of the application to show the filename and its dirty state.
  void updateCaption() {

    jMenuItemUndo.setEnabled(undo.canUndo());
    jMenuItemRedo.setEnabled(undo.canRedo());

    String caption= (currFileName == null ? "Untitled" : currFileName);

    // add a "*" in the caption if the file is dirty.
    if (dirty) {
      caption = "* " + caption;
    }
    caption = "XDoc - " + caption;

    this.setTitle(caption);
  }

  void AfterValidation() {
    NodeList nodes = newRoot.getChildNodes();
    int len = (nodes != null) ? nodes.getLength() : 0;
    for (int i = 0; i < len; i++) {
      Node node = nodes.item(i);
      if (node instanceof ElementImpl)
        ClearDefaultAttributes( (ElementImpl) node);
    }
    ((AbstractTableModel)jTable2.getModel()).fireTableStructureChanged();
    m_tree.repaint();
  }



  javax.swing.text.Document document1;
  javax.swing.text.Document document2;

  boolean openFile(String fileName)  {
    //String currXML="";
    //String s;

/*
    if (fileName!=null)
    try {

      // Open a file of the given name.
      File file = new File(fileName);

      // Get the size of the opened file.
      int size = (int) file.length();

      // Set to zero a counter for counting the number of
      // characters that have been read from the file.
      int chars_read = 0;

      // Create an input reader based on the file, so we can read its data.
      // FileReader handles international character encoding conversions.
      FileReader in = new FileReader(file);

      // Create a character array of the size of the file,
      // to use as a data buffer, into which we will read
      // the text data.
      char[] data = new char[size];

      // Read all available characters into the buffer.
      while (in.ready()) {
        // Increment the count for each character read,
        // and accumulate them in the data buffer.
        chars_read += in.read(data, chars_read, size - chars_read);


      }
      in.close();



      //FileInputStream fos = new FileInputStream(fileName);
      //InputStreamReader in = new InputStreamReader(fos, "UTF-8" );

      // Create a temporary string containing the data,
      // and set the string into the JTextArea.
      currXML = new String(data, 0, chars_read);
    }
    catch (Exception e) {
      JOptionPane.showMessageDialog(this,"<html>Cannot read "+ +":<br><b>"+e.getMessage()+"</b></html>","Error",JOptionPane.WARNING_MESSAGE);
      return false;
    }
  */

    this.currFileName = fileName;
    //this.XmlUpToDate=true;
    //this.jTextXML.setText(currXML);
    SetTextModified(true,true);
//    BuildDOM(true);
//    if (fileName==null)
//      ef.errorItems.clear();

    // Cache the currently opened filename for use at save time...
    this.SetClean();
    return true;

  }

  void SetClean() {
    //Resets the undo manager
    undo.discardAllEdits();
    // and mark the edit session as being clean
    this.dirty = false;
    // Display the name of the opened directory+file in the statusBar.
    //statusBar.setText("Opened " + fileName);
    updateCaption();
  }



  //
  // Create a URL object from either a URL string or a plain file name.
  //
  static URL createURL(String name) throws Exception {
      try {
              URL u = new URL(name);
              return u;
      } catch (MalformedURLException ex) {
      }
      URL u = new URL("file:" + new File(name).getAbsolutePath());
      return u;
  }


  synchronized void readXMLFile(String filename, JTextArea ta) {

      if (filename == null || filename.equals(""))
          return;
      InputStream fis = null;
      BufferedReader dis = null;
      try {
          java.net.URL file = createURL(filename);
          fis = file.openStream();

          String javaEncoding = parser.getJavaEncoding(); // get saved java encoding
          try
          {
          dis = new BufferedReader(new InputStreamReader(fis, javaEncoding ));
          }
          catch( UnsupportedEncodingException ex )
          {
          dis = new BufferedReader(new InputStreamReader(fis ));
          }
      } catch (Exception ex) {
          System.err.println("ERROR: Xerces.readXMLFile: "+ex);
          return;
      }

      String line;
      String nl = "\n";
      StringBuffer sb = new StringBuffer();

      try{
          readline: while ((line = dis.readLine()) != null) {
              sb.append(line+nl);
          }
          ta.setText(sb.toString());
      } catch (IOException io) {
          System.err.println(io);
          return;
      }

      // relayout because contents have changed
      //ta.revalidate();

      return;

  }

  class ErrorTreeCellRenderer extends DefaultTableCellRenderer {
    public ErrorTreeCellRenderer() {
      super();
      this.setBorder(null);//.setBorderSelectionColor(Color.white);
    }

  }


  /*
   * The XMLTreeCellRenderer is an inner class which enables the
   * highlighting of errors in the tree and shows the gender values
   * as different icons.
   */
  class XMLTreeCellRenderer extends DefaultTreeCellRenderer
  {

      public Component getTreeCellRendererComponent(JTree tree, Object value,
                        boolean selected, boolean expanded,
                        boolean leaf, int row,
                            boolean hasFocus)
      {
        Component comp = super.getTreeCellRendererComponent(tree, value,
                       selected,  expanded, leaf,  row, hasFocus);
          Node node = (Node)value;
          if (node==null) return comp;
          if (selected) {
              comp.setBackground(Color.blue);
          }
          try {


            if ( ef.getErrors(node).size()!=0) {
              if (!FeasibleNodesHelper.AcceptedByParent(node))
                comp.setForeground(new Color(0xFF, 0xA0, 0xA0));
              else
                comp.setForeground(Color.red);
            }
            else
            if (!FeasibleNodesHelper.AcceptedByParent(node))
              comp.setForeground(new Color(0xA0, 0xA0, 0xA0));
              /*
            if (node != null) {
              if (leaf) {
                setIcon(new ImageIcon(leafImage));
              }
              else if (expanded) {
                setIcon(new ImageIcon(openFolder));
              }
              else {
                setIcon(new ImageIcon(closedFolder));
              }
            }
            if (node != null && node instanceof Element) {

              Element txNode = (Element) node;
              Attr txAtt = (Attr) txNode.getAttributeNode("gender");
              if (txAtt != null) {
                if (txAtt.getValue().equals("male")) {
                  setIcon(new ImageIcon("male.gif"));
                }
                else
                if (txAtt.getValue().equals("female")) {
                  setIcon(new ImageIcon("female.gif"));
                }
              }
            }*/
          }


        catch (Exception ee) {

        }
          return comp;
      }
  }

/*
  void expandTree() {
      int rows = 0;
      for (int levels=0; levels <= 4; levels++) {
          rows=m_tree.getRowCount();
          for (int i = 0; i < rows; i++) {
              m_tree.expandRow(i);
          }
      }
  }*/
/*
  XMLEntityManager fEntityManager=new MyXMLEntityManager();

  class MyXMLEntityManager extends XMLEntityManager {
    public MyXMLEntityManager() {
      super();
    }

  }
*/
  /*XMLEntityResolver fEntityResolver=new MyXMLEntityResolver();

  class MyXMLEntityResolver implements XMLEntityResolver {
    public MyXMLEntityResolver() {
      super();
    }

  }*/
  class MyPSVIElementNSImpl extends org.apache.xerces.dom.PSVIElementNSImpl implements ElementPSVI {

        public MyPSVIElementNSImpl(CoreDocumentImpl ownerDocument, XSElementDeclaration d) {
          super(ownerDocument, d.getNamespace(), d.getName());
          fDeclaration=d;
          fTypeDecl=d.getTypeDefinition();
        }
  /*
        public void PreferPrefix() {
          String prefix=lookupPrefix(getNamespaceURI());
          if (prefix!=null && !(getParentNode()!=null && getNamespaceURI().equals(getParentNode().getNamespaceURI())))
//       this.getElementDeclaration().
            setPrefix(prefix);
        }*/
  }

  class MyXMLErrorReporter extends XMLErrorReporter{

    public MyXMLErrorReporter() {
      super();
    }

    public void reportError(XMLLocator location,
                            String domain, String key, Object[] arguments,
                            short severity) throws XNIException {
      super.reportError(location,domain,key,arguments,severity);
      System.out.println("report error:"+arguments);
    }

  }

  MyXMLErrorReporter ErrRep=new MyXMLErrorReporter();



  Node ValidateDOM(Node someNode) {
    XmlUpToDate=false;
    ef.resetErrors();
    try {
      if (newRoot.getDoctype()!=null && newRoot.getDoctype().getSystemId()!=null) {
        int nodeIndex=XDocUtilities.getElementIndex(someNode);
        this.UpdateXML();
        BuildDOM(false,true);
        someNode=XDocUtilities.getElementWithIndex(newRoot,nodeIndex);
      } else {
        DialogSchemaLocation.DialogCanceled = false;
        DOMConfigurationImpl config = (DOMConfigurationImpl)newRoot.getDomConfig();
        config.setProperty(
            "http://apache.org/xml/properties/internal/grammar-pool",
            myFullGrammarPool);
        config.setParameter("error-handler", ef);
        config.setParameter("validate", Boolean.TRUE);
        config.setParameter("psvi", Boolean.TRUE);
        config.setEntityResolver(es2);
        newRoot.normalizeDocument();
        AfterValidation();
      }
    }
    catch(Exception e) {
      ef.AddError(new ParseError(null,-1,-1,null,"[Validate exception] "+e.getMessage(),null));
    }
    XmlUpToDate=false;
    return someNode;
  }

  MyXMLGrammarPoolImpl myFullGrammarPool=new MyXMLGrammarPoolImpl();

  class MyXMLGrammarPoolImpl extends XMLGrammarPoolImpl {
    /*
     Note the retrieveInitialGrammarSet and  getGrammar aim is that
     not the same grammar is applied to two documents with
     different noNamespaceSchemaLocation attributes (namespace is null, hash is 0, so they would match otherwise).
     */


    XMLAttributes GetNS (String ns) {

      //if (ns!=null && ns.equals(""))
      for (int i = 0; i < fGrammars.length; i++)
      for (Entry entry = fGrammars[i]; entry != null; entry = entry.next) {
          if ( ns.equals(entry.desc.getNamespace()) && entry.desc instanceof XSDDescription) {
//            ((SchemaGrammar)entry.grammar).getDocumentLocations().fd
//              entry.desc.
              return ((XSDDescription)entry.desc).getAttributes();
          }
      }
      return null;
    }


    public Grammar getGrammar(XMLGrammarDescription desc) {


      synchronized (fGrammars) {
          int hash = hashCode(desc);
      int index = (hash & 0x7FFFFFFF) % fGrammars.length;
      for (Entry entry = fGrammars[index] ; entry != null ; entry = entry.next) {
          if ((entry.hash == hash) && equals(entry.desc, desc)) {
            if (desc.getNamespace()==null && desc instanceof XSDDescription && ((XSDDescription)desc).getLocationHints()!=null && ((XSDDescription)desc).getLocationHints().length>=1) {
              String wh=((XSDDescription)desc).getLocationHints()[0];
              if (wh!=null && !wh.equals(entry.desc.getExpandedSystemId())) {
                  this.removeGrammar(entry.desc);
                  return null;
          }

              return entry.grammar;
          }
      }
      }
      return null;
    }
   }


    public Grammar [] retrieveInitialGrammarSet (String grammarType) {
        synchronized (fGrammars) {
            int grammarSize = fGrammars.length ;
            Grammar [] tempGrammars = new Grammar[fGrammarCount];
            int pos = 0;
            for (int i = 0; i < grammarSize; i++) {
                for (Entry e = fGrammars[i]; e != null; e = e.next) {
                    if (e.desc.getGrammarType().equals(grammarType) && e.desc.getNamespace()!=null) {
                        tempGrammars[pos++] = e.grammar;
                    }
                }
            }
            Grammar[] toReturn = new Grammar[pos];
            System.arraycopy(tempGrammars, 0, toReturn, 0, pos);
            return toReturn;
        }
    }

  }


  void ReadFile() {
      String currXML="";
    try {


      if (currFileName!=null) {


        // Open a file of the given name.
        File file = new File(currFileName);

        // Get the size of the opened file.
        int size = (int) file.length();

        // Set to zero a counter for counting the number of
        // characters that have been read from the file.
        int chars_read = 0;

        // Create an input reader based on the file, so we can read its data.
        // FileReader handles international character encoding conversions.
        //FileReader in = new FileReader(file);
        FileInputStream fos = new FileInputStream(file);
        InputStreamReader in = new InputStreamReader(fos,
            ( (org.apache.xerces.dom.CoreDocumentImpl)
             parser.getDocument()).
            getInputEncoding());

        // Create a character array of the size of the file,
        // to use as a data buffer, into which we will read
        // the text data.
        char[] data = new char[size];

        // Read all available characters into the buffer.
        while (in.ready()) {
          // Increment the count for each character read,
          // and accumulate them in the data buffer.
          chars_read += in.read(data, chars_read, size - chars_read);

        }
        in.close();

        //FileInputStream fos = new FileInputStream(fileName);
        //InputStreamReader in = new InputStreamReader(fos, "UTF-8" );

        // Create a temporary string containing the data,
        // and set the string into the JTextArea.
        currXML = new String(data, 0, chars_read);
      }
    }
    catch (Exception e) {
    }

      UpdatingDocument = true;
      jTextXML.setText(currXML);
      UpdatingDocument = false;
  }




  /**
   *  Invoke the Parser on fname and return the root TreeNode.
   */
  public void BuildDOM(boolean fromFile, boolean withValidation)/* throws SAXNotRecognizedException, SAXNotSupportedException, SAXException, IOException*/ {

    ef.resetErrors();

    try {
      try {

        if (fromFile && currFileName==null || !fromFile && jTextXML.getText().equals("")) return;

        //
        // Reset the Error Storage and handling
        //

        parser.setErrorHandler(ef);

//          parser.setEntityResolver(es);
        parser.setProperty(
            "http://apache.org/xml/properties/internal/entity-resolver", es2);
        parser.setProperty(
            "http://apache.org/xml/properties/internal/grammar-pool",
            myFullGrammarPool);
//          parser.setEntityResolver();

        parser.setProperty(
            "http://apache.org/xml/properties/dom/document-class-name",
            "org.apache.xerces.dom.PSVIDocumentImpl");
//          parser.setProperty(XMLSchemaValidator.ENTITY_RESOLVER, fEntityResolver);
//          parser.setProperty(XMLSchemaValidator.ENTITY_MANAGER, fEntityManager);
//          parser.setProperty("http://apache.org/xml/properties/dom/document-class-name","org.apache.xerces.dom.CoreDocumentImpl");
//          parser.setProperty("http://apache.org/xml/properties/dom/document-class-name","org.apache.xerces.dom.DSCCDocumentImpl");

//          parser.setFeature("http://apache.org/xml/features/validation/schema/augment-psvi", true);
        parser.setFeature(
            "http://apache.org/xml/features/dom/defer-node-expansion", false); // otherwise parser.getCurrentNode() == null
        parser.setFeature(
            "http://apache.org/xml/features/continue-after-fatal-error", true);
        parser.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
        //parser.setFeature("http://xml.org/sax/features/namespace-prefixes", true);

        parser.setFeature("http://xml.org/sax/features/validation",
                          withValidation);
            /*parser.setFeature("http://apache.org/xml/features/validation/schema", true);
                   parser.setFeature("http://apache.org/xml/features/validation/schema-full-checking",true);
         */

//          parser.setProperty(Constants.XERCES_PROPERTY_PREFIX + Constants.ERROR_REPORTER_PROPERTY,ErrRep);

        if (fromFile) {
          XMLInputSource xis = new XMLInputSource(null, this.currFileName, null);
          parser.parse(xis);
//            parser.parse(/*this.currFileName*/"c:\\shortnews.html");
        }
        else {
          InputSource is = new InputSource(new java.io.StringReader(jTextXML.
              getText()));
          is.setSystemId(this.currFileName);
          parser.parse(is);
        }

        if (withValidation || ef.errorItems.size() == 0) {
          setRoot( (org.apache.xerces.dom.CoreDocumentImpl) parser.getDocument());
          return;
        }

      }
      catch (Exception e) {
        ef.AddError(new ParseError(null, -1, -1, null,
                                   "[Parse exception] " + e.getMessage(), null));
      }
    }
    finally {
      if (fromFile)
        ReadFile();
    }


      JOptionPane.showMessageDialog(this,"<html>This document is not well-formed. <br> Note: All errors must be corrected before the document can be validated.</html>","Error",JOptionPane.WARNING_MESSAGE);
  }


  void setRoot(CoreDocumentImpl newRoot) {
    this.newRoot=newRoot;
    m_tree.setModel(new  VirtualDomTreeModel());
    ((VirtualDomTreeModel)m_tree.getModel()).setRoot(newRoot);
    m_tree.expandRow(0);
  }


  void jMenuItem1_actionPerformed(ActionEvent e) {
    fileOpen();
  }

/*
  public String saveXML(org.apache.xerces.dom.CoreDocumentImpl newRoot,Node node) {
      DOMImplementationLS domImplLS = (DOMImplementationLS)newRoot.getImplementation();
      LSSerializer xmlWriter = domImplLS.createLSSerializer();
      if (node == null) {
          node = this;
      }
      return xmlWriter.writeToString(node);
  }
*/

  void StringToFile(String filename, byte[] content) throws IOException {
    // Open a file of the current name.
    File file = new File (filename);

    // Create an output writer that will write to that file.
    // FileWriter handles international characters encoding conversions.
    FileWriter out = new FileWriter(file);

    out.write(new String(content));
    out.close();
  }

  // Save current file; handle not yet having a filename; report to statusBar.
  boolean saveFile() {

    // Handle the case where we don't have a file name yet.
    if (currFileName == null) {
      return saveAsFile();
    }

    try
    {
      UpdateXML();
      if (newRoot!=null)
        StringToFile(currFileName,saveXml(newRoot).toByteArray()/*jTextXML.getText()*/); else
        StringToFile(currFileName,jTextXML.getText().getBytes(EncodingMap.getIANA2JavaMapping(getOutputEncoding())));


      this.dirty = false;

      // Display the name of the saved directory+file in the statusBar.
      //statusBar.setText("Saved to " + currFileName);
      updateCaption();
      return true;
    }
    catch (IOException e) {
      //statusBar.setText("Error saving " + currFileName);
    }
    return false;
  }

  // Save current file, asking user for new destination name.
  // Report to statusBar.
  boolean saveAsFile() {
    this.repaint();
    // Use the SAVE version of the dialog, test return for Approve/Cancel
    if (JFileChooser.APPROVE_OPTION == jFileChooser1.showSaveDialog(this)) {
      // Set the current file name to the user's selection,
      // then do a regular saveFile
      currFileName = jFileChooser1.getSelectedFile().getPath();

      //repaints menu after item is selected
      this.repaint();
      return saveFile();
    }
    else {
      this.repaint();
      return false;
    }
  }


  /** Normalizes the given string. */
  static protected String normalize(String s) {
      StringBuffer str = new StringBuffer();

      int len = (s != null) ? s.length() : 0;
      for (int i = 0; i < len; i++) {
          char ch = s.charAt(i);
          switch (ch) {
              case '<': {
                  str.append("&lt;");
                  break;
              }
              case '>': {
                  str.append("&gt;");
                  break;
              }
              case '&': {
                  str.append("&amp;");
                  break;
              }
              case '"': {
                  str.append("&quot;");
                  break;
              }
              case '\r':
              case '\n':
              default: {
                  str.append(ch);
              }
          }
      }

      return str.toString();

  } // normalize(String):String

  static String DisplayNode(Node node) {
    String s = node.getNodeName();
    if (node.getAttributes() != null)
      for (int i = 0; i < node.getAttributes().getLength(); i++) {
        Attr attr = (Attr) node.getAttributes().item(i);
        s = s + " " + attr.getNodeName() + "=\"" + normalize(attr.getNodeValue()) +
            "\"";
      }
    return s;
  }





  // Check if file is dirty.
  // If so get user to make a "Save? yes/no/cancel" decision.
  boolean okToAbandon() {
    if (!dirty) {
      return true;
    }
    int value =  JOptionPane.showConfirmDialog(this, "Save changes?",
                                         "XDoc", JOptionPane.YES_NO_CANCEL_OPTION) ;

    switch (value) {
       case JOptionPane.YES_OPTION:
         // yes, please save changes
         return saveFile();
       case JOptionPane.NO_OPTION:
         // no, abandon edits
         // i.e. return true without saving
         return true;
       case JOptionPane.CANCEL_OPTION:
       default:
         // cancel
         return false;
    }
  }

  // Handle the File|Open menu or button, invoking okToAbandon and openFile
  // as needed.
  void fileOpen() {
    if (!okToAbandon()) {
      return;
    }
    // Use the OPEN version of the dialog, test return for Approve/Cancel
    if (JFileChooser.APPROVE_OPTION == jFileChooser1.showOpenDialog(this)) {
      // Call openFile to attempt to load the text from file into TextArea
      openFile(jFileChooser1.getSelectedFile().getPath());
    }
    this.repaint();
  }





  /**
   * The ErrorStorer maps Nodes to errors. It receives a reference
   * to the ErrorTreeFactory in the Constructor.
   *
   * When error is called, it asks the
   * ErrorTreeFactory for the current node, and uses this as the
   * "key" of a Hashtable, with the error as a value. The error
   * value is wrapped up nicely in an ParseError object.
   *
   * It is used in the XML Tutorial to illustrate how to implement
   * the ErrorListener to provide error storage for later reference.
   *
   */
  class ErrorStorer
      implements ErrorHandler, DOMErrorHandler

  {

      //
      // Data
      //
      //private Hashtable errorNodes = null;

      /**
       * Constructor
       */
      Vector errorItems=new Vector();

      public ErrorStorer() {
      }

      /**
       * The ParseError object for the node key is returned.
       * If the node doesn't have errors, null is returned.
       */
      public Vector getErrors(Node node) {
        Vector v=new Vector();
        for (int i=0; i<errorItems.size(); i++)
        if (((ParseError)errorItems.get(i)).getRelatedNode()==node)
          v.add(errorItems.get(i));
        return v;
      }

      /**
       * Reset the error storage.
       */
      public void resetErrors() {
        errorItems.clear();
        ((AbstractTableModel)jTable2.getModel()).fireTableStructureChanged();
      }

      /***/
      public void warning(SAXParseException ex) {
          handleError(ex, WARNING);
      }

      public void error(SAXParseException ex) {
          handleError(ex, ERROR);
      }


      public void fatalError(SAXParseException ex) throws SAXException {
          handleError(ex, FATAL_ERROR);
      }

      void AddError(ParseError err) {
         errorItems.add(err);
      }

      void AddErrorUnique(ParseError err) {
        for (int i=0; i<errorItems.size(); i++)
          if (err.toString().equals(((ParseError)errorItems.get(i)).toString()))
            return;
        AddError(err);
      }



      public boolean handleError(DOMError error){
          org.w3c.dom.DOMLocator loc=error.getLocation();
          String ErrMsg=Shorten(error.getMessage(),loc.getRelatedNode());
          if (ErrMsg.indexOf(": ")!=-1)
            ErrMsg=ErrMsg.substring(ErrMsg.indexOf(": ")+": ".length());
          AddError(new ParseError(loc.getUri(),/*loc.getLineNumber(),loc.getColumnNumber()*/-1,-1,null,"[Error] "+ErrMsg,loc.getRelatedNode()));
          return true;
      }

      String[] ErrorType={"Warning","Error","Fatal Error"};

      private void handleError(SAXParseException ex, int type) {

          try {
            Node current = ( Node ) parser.getProperty( "http://apache.org/xml/properties/dom/current-element-node" );
            //if (current==null) current=parser.getDocument();
            AddError(new ParseError(ex.getSystemId(),ex.getLineNumber(),ex.getColumnNumber(),null,"["+ErrorType[type]+"] "+ex.getMessage(),current));
          }
          catch( SAXException exception  ) {
          }

      }

  }

    /**
     * The ParseError class wraps up all the error info from
     * the ErrorStorer's error method.
     *
     * @see ErrorStorer
     */
    class ParseError extends Object {

        //
        // Data
        //
        Node relatedNode=null;

        String fileName;
        int lineNo;
        int charOffset;
        Object key;
        String msg;

        /**
         * Constructor
         */
        public ParseError(String fileName, int lineNo, int charOffset,
                           Object key,
                           String msg, Node relatedNode)
        {
            if (newRoot!=null && fileName!=null/*&& !newRoot.getDocumentURI().equals(fileName)*/)
              msg=msg+" ("+fileName+")";
            this. fileName=fileName;
            this. lineNo=lineNo;
            this. charOffset=charOffset;
            this. key=key;
            this. msg=msg;
            this. relatedNode=relatedNode;
        }

        public String toString() {
          /*String s=msg;
          if (lineNo!=-1 && charOffset!=-1)
            s=s+"at line "+lineNo+", column line "+charOffset;
          return s+" ("+fileName+")";*/
          return msg;
        }

        //
        // Getters...
        //
        public String getFileName() { return fileName; }
        public int getLineNo() { return lineNo; }
        public int getCharOffset() { return charOffset;}
        public Object getKey() { return key; }
        public String getMsg() { return msg; }
        public void setMsg(String s) { msg = s; }
        public Node getRelatedNode() { return relatedNode; }
    }



/*    int GetElementNodes(Node node,Node LookAt, Vector cnodes) {
      int LookAtIndex=-1;
      for (int i=0; i<node.getChildNodes().getLength(); i++) {
        Node _cnode = node.getChildNodes().item(i);
        if (_cnode.getNodeType()==Node.ELEMENT_NODE) cnodes.add(((PSVIElementNSImpl)_cnode).getElementDeclaration());
        if (_cnode==LookAt) LookAtIndex=cnodes.size()-1;
      }
      return LookAtIndex;
    }

*/





    void UpdateMenu() {
      AddInserts(INSERT_AFTER,jMenuAfter);
      AddInserts(INSERT_BEFORE,jMenuBefore);
      AddInserts(INSERT_CHILD,jMenuAddChild);
      AddInserts(INSERT_ATTRIBUTE,jMenuAddAttribute);
      UpdateDeleteNode();
    }

    void MarkImportance(JComponent menu, boolean important) {
      if (important)
        menu.setFont(new java.awt.Font("Dialog", java.awt.Font.ITALIC | java.awt.Font.BOLD,11)); else
        menu.setFont(jMenuFile.getFont());
    }

    void UpdateDeleteNode() {
      MarkImportance(jMenuDeleteNode,GetSelectedNode()!=null && !FeasibleNodesHelper.AcceptedByParent(GetSelectedNode()));
    }

    class SrcInfo {
      int startTag=0;
      int closeTag=0;
    }

    class MyIndentPrinter extends IndentPrinter {

      int _ltCount=0;

      int getLTCount() {
        return _ltCount;
      }

      public MyIndentPrinter( Writer writer, OutputFormat format)
      {
        super( writer, format );
      }

      /*public void setRawOutput(boolean b)  {
        ((OutputStreamWriter)this._writer).
      }*/

      public void evaluateChar(char ch) {
        if (ch=='<')
        if (this._writer!=this._dtdWriter)
          _ltCount++;
      }

      public void printText( String text )
      {
        super.printText(text);
        for (int i=0; i<text.length(); i++)
          evaluateChar(text.charAt(i));
      }


      public void printText( StringBuffer text )
      {
        super.printText(text);
        for (int i=0; i<text.length(); i++)
          evaluateChar(text.charAt(i));
      }


      public void printText( char ch )
      {
        super.printText(ch);
        evaluateChar(ch);
      }


      public void printText( char[] chars, int start, int length )
      {
        super.printText(chars,start,length);
        for (int i=start; i<start+length; i++)
          evaluateChar(chars[i]);
      }


    }

    class MyXMLSerializer extends XMLSerializer {

      private Writer          _writer2;
      private OutputStream    _output2;

      protected void prepare()
          throws IOException
      {
        super.prepare();
        _printer = new MyIndentPrinter( _writer2, _format );
      }

      public MyXMLSerializer( OutputStream output, OutputFormat format) {
          super(output,format);
          _output2=output;
          try {
            //if (RawOutput)
            //  _writer2 = new OutputStreamWriter(_output2, "UTF16"); else
              _writer2 = _format.getEncodingInfo().getWriter(_output2);
            this.setOutputCharStream(_writer2);
          } catch(Exception e) {
          }
      }

      /*boolean fRawOutput=false;

      public setRawOutput(boolean b)  {
        fRawOutput=b;
      }*/

      protected void serializeElement( Element elem )
      throws IOException
      {

          SrcInfo i = new SrcInfo();
          i.startTag = ((MyIndentPrinter)_printer).getLTCount()+1;
          super.serializeElement(elem);
          i.closeTag = ((MyIndentPrinter)_printer).getLTCount();
          if (elem instanceof PSVIElementNSImpl)
          try {
            ((PSVIElementNSImpl)elem).setUserData("loc", i, null);
          } catch(Exception ee) {
          }
      }

    }

    class MyOutputFormat extends OutputFormat {

      boolean Escape=true;

      public MyOutputFormat( Document doc )
      {
          super(doc);
      }


      public boolean isNonEscapingElement( String tagName )
      {
          if (!Escape)
            return true;
          return super.isNonEscapingElement(tagName);
      }


    }

    //return IANA Encoding name for output
    String getOutputEncoding() {
      CoreDocumentImpl newRoot=(CoreDocumentImpl) parser.getDocument();
      if (newRoot!=null && newRoot.getXmlEncoding()!=null)
        return newRoot.getXmlEncoding().toUpperCase();
      if (newRoot!=null && newRoot.getInputEncoding()!=null)
        return newRoot.getInputEncoding().toUpperCase();
      return "UTF-8";
    }

    private ByteArrayOutputStream saveXml(Document document) {

      ByteArrayOutputStream output = new ByteArrayOutputStream();
      MyOutputFormat format = new MyOutputFormat(document);
      format.setIndenting(true);
      format.setLineWidth(0);
      format.setPreserveSpace(false);

      /*"ISO-8859-1"*/
      format.setEncoding(getOutputEncoding());

      try {
        XMLSerializer serializer = new MyXMLSerializer(output, format);
        serializer.asDOMSerializer();
        serializer.serialize(document);

        /*if (RawOutput)
           return output.toString(EncodingMap.getIANA2JavaMapping(format.getEncoding())); else
         //return output.toString();
         return new String(output.toByteArray());
         */

      }
      catch (IOException ioe) {
      }
      return output;
    }




  int FindLT(String s, int numberLT, boolean findClose) {

    for (int i=0; i<s.length(); i++)
    if (s.charAt(i)=='<') {
        numberLT--;
        if (numberLT == 0) {
          if (findClose) {
            boolean isWithinAttribute = false;
            while (i < s.length()) {
              if (s.charAt(i) == '>' && !isWithinAttribute) {
                i++;
                break;
              } else
              if (s.charAt(i) == '\"')
                isWithinAttribute = !isWithinAttribute;
              i++;
            }
          }
          return i;
        }
      }
    return 0;
  }


  static int CountLT(String s, int pos) {
    int res=0;
    for (int i=0; i<pos; i++)
      if (s.charAt(i)=='<')
        res++;
    return res;
  }


  String GetText(ParentNode node, int INSERT_WHERE) {
    switch (INSERT_WHERE) {
      case INSERT_BEFORE:  {
        Node asibling = node.getPreviousSibling();
        if (asibling != null && asibling.getNodeType() == Node.TEXT_NODE)
          return asibling.getNodeValue();
        break;
      }
      case INSERT_AFTER: {
        Node asibling = node.getNextSibling();
        if (asibling != null && asibling.getNodeType() == Node.TEXT_NODE)
          return asibling.getNodeValue();
        break;
      }
      case INSERT_CHILD:  return node.getTextContent();
    }
    return "";
  }
  boolean InTextUpdate=false;

  void SelectNode(PSVIElementNSImpl node) {

    boolean contenttext = false;
    boolean siblingtext = false;

    if (node!=null) {

      if (node.getParentNode() instanceof PSVIElementNSImpl) {
        PSVIElementNSImpl pnode =(PSVIElementNSImpl)node.getParentNode();
        if (pnode.getTypeDefinition() instanceof XSComplexTypeDecl) {
          XSComplexTypeDecl CT = (XSComplexTypeDecl) pnode.getTypeDefinition();
          if (CT == null ||
              CT.getContentType() == XSComplexTypeDecl.CONTENTTYPE_MIXED)
            siblingtext = true;
        }
      }

      if (node.getTypeDefinition() instanceof XSComplexTypeDecl) {
        XSComplexTypeDecl CT = (XSComplexTypeDecl) node.getTypeDefinition();
        if (CT == null ||
            VirtualDomTreeModel.GetChildrenNodes(node).size() == 0 && (
            /*!GetText(node,INSERT_CHILD).equals("") ||
            CT.getContentType() == XSComplexTypeDecl.CONTENTTYPE_SIMPLE ||*/
            CT.getContentType() == XSComplexTypeDecl.CONTENTTYPE_MIXED))
          contenttext = true;
          //if (CT.getContentType()==XSComplexTypeDecl.CONTENTTYPE_SIMPLE)
          //  contenttext=true;
      }
      /*else
        contenttext = true;*/
    }

      //jLabel5.setVisible(jTable1.getModel().getRowCount()!=0);

    jLabel3.setVisible(contenttext);
    jScrollPane5.setVisible(contenttext);

    jLabel1.setVisible(siblingtext);
    jScrollPane4.setVisible(siblingtext);

    jLabel2.setVisible(siblingtext);
    jScrollPane6.setVisible(siblingtext);

    if (!InTextUpdate) {
      InTextUpdate = true;

        if (contenttext) {
          jTextContent.setText(GetText(node, INSERT_CHILD));
          jTextContent.select(0,0);
        }

        if (siblingtext) {
          jTextBefore.setText(GetText(node, INSERT_BEFORE));
          //jTextBefore.select(0,0);
          jTextBefore.select(0,0);
        }

        if (siblingtext) {
          jTextAfter.setText(GetText(node, INSERT_AFTER));
          jTextAfter.select(jTextAfter.getText().length(),jTextAfter.getText().length());
        }
        InTextUpdate = false;
      }


    SelectTextFromNode(node);

    jMenuElement.setEnabled(node!=null);
    jButtonAddBefore.setEnabled(node!=null && node!=newRoot.getDocumentElement());
    jButtonAddAfter.setEnabled(node!=null && node!=newRoot.getDocumentElement());
    jButtonAddAttr.setEnabled(node!=null);
    jButtonAddAttr2.setEnabled(node!=null);
    jButtonDeleteAttr.setEnabled(node!=null);
  }

  void SelectTextFromNode(PSVIElementNSImpl node) {
    if (!NotSelectNodeXML && node!=null && XmlUpToDate)
    try {
      Object ob = node.getUserData("loc");
      if (ob instanceof SrcInfo) {
        SrcInfo i = (SrcInfo) ob;
        int selectionStart=FindLT(jTextXML.getText(), i.startTag, false);
        int selectionEnd=FindLT(jTextXML.getText(), i.closeTag, true);

        //jTextXML.select(selectionStart,selectionEnd); //same as next 2 statements, but not scrolled to right
        jTextXML.setCaretPosition(selectionEnd);
        jTextXML.moveCaretPosition(selectionStart);

        jTextXML.getCaret().setSelectionVisible(true);
      }
    }
    catch (Exception ee) {
    }
  }



  void m_tree_valueChanged(TreeSelectionEvent e) {
      Node node=this.GetSelectedNode();
      UpdateXML();
      SelectNode(node instanceof PSVIElementNSImpl ? (PSVIElementNSImpl)node : null );
      UpdateElementUI();
      SelectErrorsFromNode();
  }

  void SelectErrorsFromNode() {
    if (!(jTable2.getSelectedRow()!=-1 && ((ParseError)ef.errorItems.get(jTable2.getSelectedRow())).relatedNode==GetSelectedNode()))
    if (ef.getErrors(GetSelectedNode()).size()!=0) {
      int i=ef.errorItems.indexOf(ef.getErrors(this.GetSelectedNode()).firstElement());
      jTable2.setRowSelectionInterval(i, i); //.addListSelectionListener();
      Rectangle cellRect = jTable2.getCellRect(i, 0, false);
      if (cellRect != null)
        jTable2.scrollRectToVisible(cellRect);
    }
  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    saveFile();
//    Counter.main(new String[]{"-v","-s","-p","xni.parser.PSVIParser","D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
//   TreeView.main(new String[]{"D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
//    Counten.main(new String[]{"D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});
//    SaxParser1.main(new String[]{"D:\\JBuilder9\\samples\\Tutorials\\XML\\presentation\\MyEmployees.xml"});

  }

  void ReadProps() {
    //Dimension screenSize = Toolkit.getDefaultToolkit ().getScreenSize ();
    Rectangle NewBounds=null;

    DefaultTreeCellRenderer renderer=new XMLTreeCellRenderer();
    Color col = new Color(0,0,0,0);
    renderer.setBackgroundNonSelectionColor(col);

    m_tree.setCellRenderer(renderer);
    m_tree.getSelectionModel().setSelectionMode
        (TreeSelectionModel.SINGLE_TREE_SELECTION);

    //jTextContent.enableInputMethods(true);


   // jTable1.createScrollPaneForTable() TableColumn(0));
     //(jSplitPane1.getUI()).setdgetDivider().setBackground(color);
    String lastFile="";
    Properties myProp = new Properties();
    try {
      FileInputStream fis = new FileInputStream(userDir+"/"+"config.properties");
      myProp.load(fis);
      lastFile = myProp.getProperty("lastFile");
      int mapCount=Integer.parseInt(myProp.getProperty("numberNS"));
      for (int i = 0; i < mapCount; i++) {
        String si = new Integer(i).toString();
        ConfigureNamespacesDialog.MapNamespaces.add(new MapNamespace(myProp.getProperty("DESC" + si),myProp.getProperty("NS" + si), myProp.getProperty("LOC" + si), myProp.getProperty("ROOT" + si)));
      }

      //NewBounds=new Rectangle(Integer.parseInt(myProp.getProperty("WindowLeft")),Integer.parseInt(myProp.getProperty("WindowTop")),Integer.parseInt(myProp.getProperty("WindowWidth")),Integer.parseInt(myProp.getProperty("WindowHeight")));

      this.fontFamilyForDOM=myProp.getProperty("fontFamilyForDOM");
      this.fontFamilyForSRC=myProp.getProperty("fontFamilyForSRC");


    } catch(IOException ee) {
    }

    this.setFontFamilyForDOM(fontFamilyForDOM);
    this.setFontFamilyForSRC(fontFamilyForSRC);

    if (NewBounds!=null) this.setBounds(NewBounds);

    openFile(lastFile);

    ExampleFileFilter filter = new ExampleFileFilter();
    filter.addExtension("xsd");
    filter.addExtension("xsl");
    filter.addExtension("xhtml");
    filter.addExtension("smil");
    filter.addExtension("wsdl");
    filter.addExtension("wsil");
    filter.addExtension("xml");
    filter.addExtension("wml");
    filter.addExtension("jsp");
    filter.setDescription("XML files");
    jFileChooser1.setFileFilter(filter);

    jSchemaChooser.setDialogTitle("Select Schema Location");
    jSchemaChooser.setCurrentDirectory(new File(System.getProperty( "user.dir" )));
    jStylesheetChooser.setDialogTitle("Select Stylesheet");
    jStylesheetChooser.setCurrentDirectory(new File(System.getProperty( "user.dir" )));


    ExampleFileFilter filter2 = new ExampleFileFilter();
    filter2.addExtension("xsd");
    filter2.addExtension("dtd");
    filter2.setDescription("DTD and Schema files");
    jSchemaChooser.setFileFilter(filter2);

    ExampleFileFilter filter3 = new ExampleFileFilter();
    filter3.addExtension("xsl");
    filter3.setDescription("XSLT Stylesheets");
    jStylesheetChooser.setFileFilter(filter3);



    try {
      if (currFileName!=null)
        jFileChooser1.setCurrentDirectory(new File(this.currFileName)); else
        jFileChooser1.setCurrentDirectory(new File(System.getProperty( "user.dir" )));
    } catch (Exception ee) {
    }

    //pack();
    //setSize (screenSize);

  }


  void this_windowOpened(WindowEvent e) {
    jTextXML.setCaret(new MyDefaultCaret());
    jTextContent.setCaret(new MyDefaultCaret());
    jTextBefore.setCaret(new MyDefaultCaret());
    jTextAfter.setCaret(new MyDefaultCaret());


    ReadProps();
    setExtendedState(Frame.MAXIMIZED_BOTH);

//    jMenuItem1_actionPerformed(null);


  }

  class MyDefaultCaret extends DefaultCaret {
      public void focusLost(FocusEvent e) {
        super.focusLost(e);
        //try {
          setSelectionVisible(true);
        //}
        //catch (Exception ee) {
        //}
      }

  }


  int GetCompIndex(Component[] cs, Object c) {
    for (int i=0; i<cs.length; i++)
      if (cs[i]==c) return i;
    return -1;
  }

  static void SetPrefix(NodeImpl node) {
    String ns=node.getNamespaceURI();
    if (ns==null || node.getPrefix()!=null) return; //unqualified node
    String prefix=node.lookupPrefix(node.getNamespaceURI());
    if (prefix==null) return;
    node.setPrefix(prefix);
    if (node.isDefaultNamespace(ns))
      node.setPrefix(null);
  }
/*
  void SetPrefixes(PSVIElementNSImpl pnode) {
    if (pnode instanceof NodeImpl)
      SetPrefix(((NodeImpl)pnode));
    for (Node node=pnode.getFirstChild(); node!=null; node=node.getNextSibling())
      if (node instanceof PSVIElementNSImpl)
        SetPrefixes((PSVIElementNSImpl)node);
  }
*/




  void ClearDefaultAttributes(ElementImpl pnode) {

    Vector v=XDocUtilities.getAttrChildren(pnode);
    for (int i=0; i<v.size(); i++) {
      PSVIAttrNSImpl attr=(PSVIAttrNSImpl)v.get(i);
       if (!attr.getSpecified() && !FeasibleNodesHelper.isReservedAttribute(attr) && FeasibleNodesHelper.RequiredAttributes(pnode).indexOf(attr.getAttributeDeclaration())==-1)
        pnode.removeAttributeNode(attr);
    }

    for (Node node=pnode.getFirstChild(); node!=null; node=node.getNextSibling())
    if (node instanceof PSVIElementNSImpl)
      ClearDefaultAttributes((PSVIElementNSImpl)node);

  }


  NodeImpl GetSelectedNode() {
    if (m_tree.getLastSelectedPathComponent() instanceof NodeImpl)
      return (NodeImpl)m_tree.getLastSelectedPathComponent(); else
      return null;
  }

  void SaveExpandedState(ParentNode node,TreePath tp) {
    if (m_tree.isExpanded(tp)) {
      node.setUserData("exp","yes",null);
      Vector v=VirtualDomTreeModel.GetChildrenNodes(node);
      for (int i=0; i<v.size(); i++)
        SaveExpandedState((ParentNode)v.get(i),tp.pathByAddingChild(v.get(i)));
    } else
      node.setUserData("exp",null,null);
  }

  void RestoreExpandedState(ParentNode node,TreePath tp) {
    if (node.getUserData("exp")!=null) {
      m_tree.expandPath(tp);
      Vector v=VirtualDomTreeModel.GetChildrenNodes(node);
      for (int i=0; i<v.size(); i++)
        RestoreExpandedState((ParentNode)v.get(i),tp.pathByAddingChild(v.get(i)));
    }
  }

  TreePath getPath(Node node) {
    if (node.getParentNode()!=null)
      return getPath(node.getParentNode()).pathByAddingChild(node); else
      return new TreePath(node);
  }

  void SetTextModified(boolean build_dom, boolean fromFile) {
    if (newRoot!=null)
      ef.resetErrors();
    newRoot = null;
    m_tree.setModel(null);
    SelectNode(null);
    if (build_dom)
      BuildDOM(fromFile,false);
    SetDomModified(null);
  }

  void UpdateDOM(Node node) {


    if (node != null)
      SaveExpandedState( (ParentNode) newRoot, new TreePath(newRoot));

    if (newRoot != null)
      node = ValidateDOM(node);

    if (newRoot == null)
      jTextXML.setBackground(Color.white);
    else
      jTextXML.setBackground(Color.lightGray);

      //jScrollPane2.setVisible(newRoot!=null);

    if ( (newRoot != null) != (jTabbedPane1.getTitleAt(0).equals("Edit")))
      if (newRoot != null)
        jTabbedPane1.insertTab("Edit", null, jScrollPane2, "", 0);
      else
        jTabbedPane1.removeTabAt(0);

    jPanel6.setVisible(newRoot == null);

    if (node != null)
      this.UpdateXML();
    if (node != null)
      ( (VirtualDomTreeModel) m_tree.getModel()).fireTreeStructureChanged(node);
    if (node != null)
      RestoreExpandedState( (ParentNode) newRoot, new TreePath(newRoot));

    SelectTreeNode(node);
  }

  void SetDomModified(Node node) {
    UpdateDOM(node);
    MarkDirty();

    //jScrollPane8.setVisible(ef.errorItems.size()!=0);
  }

  void MarkDirty() {
    this.dirty=true;
    UpdateElementUI();
    updateCaption();
  }

  void UpdateElementUI() {
    UpdateMenu();
    if (jTable1.getCellEditor()!=null)
      jTable1.getCellEditor().cancelCellEditing();
    ((AbstractTableModel)jTable1.getModel()).fireTableStructureChanged();
    UpdateAttributeUI();
  }

  void UpdateAttributeUI() {
    jMenuDeleteAttribute.setEnabled(GetSelectedAttribute()!=null);
    jButton13.setVisible(GetReferencedNode()!=null);
  }

  void SplitText(ParentNode node,JTextArea text) {
    SetTextContent(node,text.getSelectedText());
    SetTextBefore(node,text.getText().substring(0,text.getSelectionStart()));
    SetTextAfter(node,text.getText().substring(text.getSelectionEnd()));
  }

  String ChooseName() {
   String value = JOptionPane.showInputDialog(this, null,"") ;
   if ("".equals(value)) value=null;
   return value;
  }

  static void getEnumerationValues(XSSimpleTypeDefinition st, Vector v) {
    StringList enumeration = st.getLexicalEnumeration();
    if (enumeration!=null)
    for (int i=0; i<enumeration.getLength(); i++)
      v.add(enumeration.item(i));
    XSObjectList unionMembers=st.getMemberTypes();
    if (unionMembers!=null)
    for (int i=0; i<unionMembers.getLength(); i++)
      getEnumerationValues( (XSSimpleTypeDefinition) unionMembers.item(i), v);
    if (st.getItemType()!=null)
      getEnumerationValues(st.getItemType(),v);
  }


  static Vector getPossibleSTValues(XSSimpleTypeDefinition ST) {
    Vector v = new Vector();
    getEnumerationValues(ST,v);
    if ("boolean".equals(ST.getName())) {
      v.add("false");
      v.add("true");
    }
    return v;
  }


  static Vector getPossibleValues(XSAttributeDeclaration d) {
    if (d==null) return new Vector();
    Vector v=getPossibleSTValues(d.getTypeDefinition());
    String _default=d.getConstraintValue();
    if (_default!=null)
      v.insertElementAt(_default,0);
    return XDocUtilities.UniqueStringVector(v);
  }

  static Vector getPossibleValues(XSElementDeclaration d) {
    if (d==null) return new Vector();
    Vector v=getPossibleSTValues(IDConstraintHelper.getST(d));
    String _default=d.getConstraintValue();
    if (_default!=null)
      v.insertElementAt(_default,0);
    return XDocUtilities.UniqueStringVector(v);
  }

  static Vector getPossibleValues(NodeImpl d) {
    if (d instanceof PSVIAttrNSImpl)
      return getPossibleValues(((PSVIAttrNSImpl)d).getAttributeDeclaration()); else
    if (d instanceof PSVIElementNSImpl)
      return getPossibleValues(((PSVIElementNSImpl)d).getElementDeclaration()); else
      return new Vector();
  }

  static Vector getPossibleValuesPlusKeys(NodeImpl d,boolean OnlyOneKey) {
    Vector v=getPossibleValues(d);
    Vector v2=getNodeValues(IDConstraintHelper.getPossibleReferences(d));
    if (!OnlyOneKey || v2.size()==1)
     v.addAll(v2);
    return v;
  }



  //This method fills element "pnode" with children to satisfy the content model
  //there are two possible dangers that this method could not terminate:
  //1. If the content model is invalid (see ./examples/tg/) the outer for-loop
  //   could never stop, this is prevented by the "count<minCheapCount":
  //   -If the content model is valid, a shortest sequence of children is added (as designed by getInsertableElements)
  //   -If not, the number of childs added is bounded by minCheapCount
  //2. An infinite nesting of kind <x><x><x>..</x></x></x> is prevented
  void FillNeeded(PSVIElementNSImpl pnode, Node NodeStarted) {
   // if (pnode instanceof MyPSVIElementNSImpl)
   //   ((MyPSVIElementNSImpl)pnode).PreferPrefix();
    SetPrefix(pnode);
    FillAttrNeeded(pnode);
    Node newNode=null;
    int minCheapCount=0;//the shortest content in element number satisfying the content model
    int count=0;
    if (pnode.getTypeDefinition() instanceof XSComplexTypeDecl) {
      XSComplexTypeDecl d=(XSComplexTypeDecl)pnode.getTypeDefinition();
      if (d.getParticle()!=null && d.getParticle().getTerm() instanceof XSModelGroupImpl) {
        XSModelGroupImpl model = (XSModelGroupImpl) d.getParticle().getTerm();
        minCheapCount=model.minEffectiveTotalRange();
      }
    }
    do {
      Vector Required=new Vector();
      FeasibleNodesHelper.getInsertableElements(pnode.getTypeDefinition(), FeasibleNodesHelper.GetChildrenDecl(pnode), FeasibleNodesHelper.GetChildrenDecl(pnode).size(),
                       Required, new Vector());
      newNode=null;
      for (int i=0; i<Required.size(); i++)
      if (Required.get(i) instanceof XSElementDeclaration) {
        XSElementDeclaration d=(XSElementDeclaration)Required.get(i);

        //prevent infinite nested filling
        //can happen in valid schemas, too: "callout" element in DocBook
        //correctness is maintained by choosing other elements in <xs:choose>
        for (Node lookup=pnode; lookup!=NodeStarted; lookup=lookup.getParentNode())
          if (((PSVIElementNSImpl)lookup).getElementDeclaration()==d)
            d=null;//assure recursion termination
        if (d==null) continue;

        newNode=pnode.appendChild(new MyPSVIElementNSImpl((CoreDocumentImpl)pnode.getOwnerDocument(),d));
        FillNeeded((PSVIElementNSImpl)newNode,NodeStarted);
        count++;
        break;
      }
  } while(newNode!=null && (count<minCheapCount/*assure iteration termination*/));
  }

  void FillAttrNeeded(PSVIElementNSImpl pnode) {
    Vector Required=new Vector();
    do {
      Required.clear();
      FeasibleNodesHelper.ValidAttributes(pnode,Required, new Vector());
      if (!Required.isEmpty()) {
        XSAttributeDeclaration d=(XSAttributeDeclaration)Required.firstElement();
        AddAttribute(pnode,d);
      } else break;
    } while(true);
  }

  static String GetNS(NodeImpl node,String name,boolean SupportDefaultNamespace) {
    String ns="";
    int i=name.indexOf(":");
    if (i!=-1) {
      String prefix=name.substring(0,i);
      ns=node.lookupNamespaceURI(prefix);
      if (prefix.equals("xmlns"))
        ns="http://www.w3.org/2000/xmlns/";
    } else
    if (name.equals("xmlns"))
      ns="http://www.w3.org/2000/xmlns/"; else
    if (SupportDefaultNamespace)
      ns=node.lookupNamespaceURI(null);
    return ns;
  }

  PSVIAttrNSImpl AddAttribute(NodeImpl node,XSAttributeDeclaration d) {

    PSVIAttrNSImpl newNode=null;
    if (d==null) {
      String name=ChooseName();
      if (name==null) return null;
      newNode = new PSVIAttrNSImpl((CoreDocumentImpl)node.getOwnerDocument(),GetNS(node,name,false), name);
    } else
      newNode = new MyPSVIAttrNSImpl((CoreDocumentImpl)node.getOwnerDocument(), d);
    ((PSVIElementNSImpl)node).setAttributeNode(newNode);
    if (d!=null) {
      //( (MyPSVIAttrNSImpl) newNode).PreferPrefix();
      SetPrefix(newNode);
      if (getPossibleValuesPlusKeys(newNode,true).size()!=0)
        newNode.setNodeValue((String)getPossibleValuesPlusKeys(newNode,true).firstElement());
    }
    return newNode;
  }

  void mi_actionPerformed(ActionEvent e) {
    AddOb(((JMyMenuItem)e.getSource()));
  }
  void AddOb(JMyMenuItem mi) {

    //MutableTreeNode treeNode = (MutableTreeNode) (m_tree.getLastSelectedPathComponent());
    Object ob=mi.d;
/*    Container p=((JMyMenuItem)e.getSource()).getParent();
    if (p instanceof JComboBox)
      ((JPopupMenu)p.getParent()).setVisible(false);
*/
    if (ob instanceof XSNamespaceItem) {
      XSNamespaceItem n=(XSNamespaceItem)ob;
      if (!(n instanceof SchemaGrammar)) return;
      XSElementDecl root=GetRootFor((SchemaGrammar)n,null,true);
      ob=root;
    }
    if (mi.INSERT_WHERE==INSERT_ATTRIBUTE) {
      XSAttributeDecl d=(XSAttributeDecl) ob;
      PSVIAttrNSImpl newNode=AddAttribute(GetSelectedNode(),d);
      if (newNode==null) return;
      SetDomModified(GetSelectedNode());
      ConfigureNamespacesDialog.DoUpdateTable(jTable1,XDocUtilities.getAttrChildren(GetSelectedNode()).indexOf(newNode));
    } else {
      PSVIElementNSImpl newNode=null;
      NodeImpl pnode=(mi.INSERT_WHERE==INSERT_CHILD) ? GetSelectedNode() : (NodeImpl)GetSelectedNode().getParentNode();
      /*if (ob instanceof XSWildcardDecl) {
        XSWildcardDecl wc=(XSWildcardDecl)ob;
      }*/
      XSElementDeclaration d = (XSElementDeclaration) ob;
      boolean needSecondValidtation=false;
      if (d==null) {
        String name=ChooseName();
        if (name==null) return;
        newNode = new PSVIElementNSImpl(newRoot,GetNS(pnode,name,false), name);
        needSecondValidtation=true;//newNode.getNamespaceURI()!=null;
      } else
        newNode = new MyPSVIElementNSImpl(newRoot, d);
      switch (mi.INSERT_WHERE) {
        case INSERT_AFTER: {
          pnode.insertBefore(newNode, GetSelectedNode().getNextSibling());
          if (jScrollPane6.isVisible())
            SplitText(newNode,jTextAfter);
          break;
        }
        case INSERT_BEFORE: {
          pnode.insertBefore(newNode, GetSelectedNode());
          if (jScrollPane4.isVisible())
            SplitText(newNode,jTextBefore);
          break;
        }
        case INSERT_CHILD: {
          pnode.insertBefore(newNode, null);
          if (jScrollPane5.isVisible())
            SplitText(newNode,jTextContent);
          break;
        }
      }
      FillNeeded(newNode,newNode);
      SetDomModified(newNode);
      if (needSecondValidtation) {
        FillNeeded(newNode,newNode);
        SetDomModified(newNode);
      }
    }
  }

  final int INSERT_BEFORE=0;
  final int INSERT_AFTER=1;
  final int INSERT_CHILD=2;
  final int INSERT_ATTRIBUTE=3;
  JMenu jMenu3 = new JMenu();
  JMenuItem jMenuItem6 = new JMenuItem();
  JFileChooser jFileChooser1 = new JFileChooser();
  JMenuItem jMenuItem7 = new JMenuItem();
  static public JFileChooser jSchemaChooser = new JFileChooser();
  static public JFileChooser jStylesheetChooser = new JFileChooser();



  JMenu jMenuAddAttribute = new JMenu();

  Border border2;
  JTextArea jTextAfter = new JTextArea();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextArea jTextContent = new JTextArea();
  JTree m_tree = new MyJTree(null);
  JScrollPane jScrollPane5 = new JScrollPane();
  JLabel jLabel2 = new JLabel();
  JScrollPane jScrollPane4 = new JScrollPane();
  JSplitPane jSplitPane1 = new JSplitPane();
  JTextArea jTextBefore = new JTextArea();
  JPanel jPanel2 = new JPanel();
  JScrollPane jScrollPane3 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane6 = new JScrollPane();
  JLabel jLabel5 = new JLabel();
  TableModel dataModel = new MyAbstractTableModel();
  JTable jTable1 = new MyJTable();
  BoxLayout boxLayout21;
  BoxLayout boxLayout22;
  JScrollPane jScrollPane1 = new JScrollPane();
  JMenu jMenu1 = new JMenu();
  JMenuItem jMenuDeleteNode = new JMenuItem();
  JMenuItem jMenuDeleteAttribute = new JMenuItem();
  JTextArea jTextXML = new JTextArea();
  boolean XmlUpToDate=false;
  JScrollPane jScrollPane8 = new JScrollPane();
  JTable jTable2 = new JTableError(errorModel);
  //JTable jTable2 = new JTable(errorModel);
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JSplitPane jSplitPane2 = new JSplitPane();
  JMenuItem jMenuItem9 = new JMenuItem();
  JMenuItem jMenuItem8 = new JMenuItem();
  JMenu jMenuNewFrom = new JMenu();
  JMenuItem jNewFromItem = new JMenuItem();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  Border border3;
  JMenuItem jMenuItem10 = new JMenuItem();
  JButton jButton2 = new JButton();
  JButton jButton1 = new JButton();
  JToolBar toolBar = new JToolBar();
  JButton jButton3 = new JButton();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton jButtonAddAttr = new JButton();
  JButton jButton5 = new JButton();
  JButton jButtonAddAfter = new JButton();
  JButton jButtonAddBefore = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();

/*  class ErrorSelectionModel extends DefaultListSelectionModel {
    public ErrorSelectionModel() {
      super();
    }
  }*/
  class ErrorTableModel extends AbstractTableModel {
    public int getColumnCount() { return 1; }
    //public String getColumnName(int columnIndex) { return new String[] {"Attribute","Name"} [columnIndex]; }
    public int getRowCount() { return ef.errorItems.size(); }
    public Object getValueAt(int row, int col) { return ef.errorItems.get(row); }
    public boolean isCellEditable(int row, int col) {return false;}
  }


  class MyAbstractTableModel extends AbstractTableModel {
    public int getColumnCount() { return 2; }
    public String getColumnName(int columnIndex) { return new String[] {"Attribute","Name"} [columnIndex]; }
    public int getRowCount() {
      //XSSimpleTypeDecl s;
      if (GetSelectedNode()!=null && GetSelectedNode().getAttributes()!=null) {
        if (IDConstraintHelper.getST(GetSelectedNode())!=null)
          return GetSelectedNode().getAttributes().getLength()+1;  else
          return GetSelectedNode().getAttributes().getLength();
      }else
        return 0;
    }
    public Object getValueAt(int row, int col) {
      if (col==0)
        return getAttrNode(GetSelectedNode(),row).getNodeName(); else
        return getAttrNode(GetSelectedNode(),row).getTextContent();
    }
    public boolean isCellEditable(int row, int col) {return col==1;}
  };



  class JTableError extends JTable {

    public TableCellRenderer getCellRenderer(int row, int column){
        return new ErrorTreeCellRenderer();
    }

    public JTableError(TableModel tableModel) {
      super(tableModel);
    }

    public JTableError() {
      super();
    }

    public TableCellEditor getCellEditor(int row, int column) {
      JTextField tf=new JTextField();
      tf.setEditable(false);
      return new DefaultCellEditor(tf);
    }

    public Dimension getPreferredSize() {
            Dimension d=super.getPreferredSize();
            d.setSize(adjustColumnSize(0)+16,d.getHeight());
//            d.setSize(Math.max(adjustColumnSize(0)+16,jScrollPane8.getWidth()),Math.max(d.getHeight(),jScrollPane8.getHeight()));
            //d.setSize(d.getWidth(),this.ui.getPreferredSize(this).getHeight());
            return d;
    }

    protected int adjustColumnSize(int col){
        int maxPrefWidth = 0;
        for (int row = 0; row < getRowCount(); row++) {
            Component cellAtCol=getDefaultRenderer(getModel().getColumnClass(col+1))
                .getTableCellRendererComponent(
                                               this, getModel().getValueAt(row,col+1),
                                               false, false, row, col);
            int prefWidth = cellAtCol.getPreferredSize().width;
            maxPrefWidth = Math.max(maxPrefWidth, prefWidth);
        }
        return maxPrefWidth;
    }



  }

  void setNodeValue(NodeImpl node,String s) {
    if (node instanceof AttrImpl)
      ((AttrImpl)node).setNodeValue(s);  else
      node.setTextContent(s);
  }

  NodeImpl getAttrNode(NodeImpl node,int row) {
    if (row<=node.getAttributes().getLength()-1)
      return (PSVIAttrNSImpl)node.getAttributes().item(row);     else
      return node;
  }

  class MyJTable extends JTable {
/*
    public int getRowHeight(int row) {
//      if (this.isEditing() && this.getEditingRow()==row)
//        return super.getRowHeight(row)+9; else
        return super.getRowHeight(row)+36;
    }
*/

    public TableCellEditor getCellEditor(int row, int column) {

        //PSVIAttrNSImpl attr=(PSVIAttrNSImpl)GetSelectedNode().getAttributes().item(row);
        NodeImpl attr=getAttrNode(GetSelectedNode(),row);
        //XSAttributeDecl d=(XSAttributeDecl)attr.getAttributeDeclaration();

        Vector v=Frame3.getPossibleValuesPlusKeys(attr,false);

        if ("http://www.w3.org/2000/xmlns/".equals(attr.getNamespaceURI()) ||
           (attr instanceof AttrImpl) && ((AttrImpl)attr).getOwnerElement()!=null && "http://www.w3.org/2001/XMLSchema".equals(((AttrImpl)attr).getOwnerElement().getNamespaceURI()) && "namespace".equals(attr.getLocalName())) {
          v.addAll(ConfigureNamespacesDialog.getNamespaces());
          XSModelImpl si=(XSModelImpl)((PSVIElementNSImpl)attr.getOwnerDocument().getDocumentElement()).getSchemaInformation();
          if (si!=null)
          for (int i=0; i<si.getNamespaces().getLength(); i++)
            v.add(si.getNamespaces().item(i));
          v= XDocUtilities.UniqueStringVector(v);
        }

        DefaultCellEditor ce;
        if (v.size()!=0) {
          JComboBox cb=new JComboBox(v);
          cb.setEditable(true);
          ce=new DefaultCellEditor(cb);
        } else
          ce=(DefaultCellEditor)super.getCellEditor(row,column);
        setFontFamily(ce.getComponent(),fontFamilyForDOM);
        return ce;
    }


    public void setValueAt(Object aValue, int row, int column) {
      PSVIElementNSImpl n=(PSVIElementNSImpl) GetSelectedNode();
      NodeImpl attr=getAttrNode(n,row);
      Vector v=IDConstraintHelper.getIDListeners(attr);
      String Value=(aValue == null) ? "" :  aValue.toString();
      v.add(attr);
      for (int i=0; i<v.size(); i++) {
        NodeImpl node=( (NodeImpl) v.get(i));
        setNodeValue(node, Value );
//        if ((node is PSVIAttrNSImpl) &&  node.getLocalName()="xmlns";
//          ((PSVIAttrNSImpl)node).getOwnerElement().setname
      }
      if (attr.getLocalName().equals("xmlns")) {
        ((CoreDocumentImpl)n.getOwnerDocument()).renameNode(n,Value,n.getLocalName());
        SetDomModified(n);
        FillNeeded(n,n);
      }
      //XSAttributeDecl ad=(XSAttributeDecl)attr.getAttributeDeclaration();
      SetDomModified(GetSelectedNode());
    }


    public TableCellRenderer getCellRenderer(int row, int column) {

      //NodeImpl attr=(PSVIAttrNSImpl)GetSelectedNode().getAttributes().item(row);
        NodeImpl attr=getAttrNode(GetSelectedNode(),row);
        if (FeasibleNodesHelper.isReservedAttribute(attr))
          return reservedRenderer;
        if (attr instanceof PSVIAttrNSImpl && !FeasibleNodesHelper.AcceptedAttrByParent((PSVIAttrNSImpl)attr,GetSelectedNode()))
          return accRenderer;

        return super.getCellRenderer(row,column);
    }

    DefaultTableCellRenderer accRenderer = new DefaultTableCellRenderer() {
        public void setValue(Object value) {
            setForeground(Color.red);
            setText((value == null) ? "" : value.toString());
        }
    };
    DefaultTableCellRenderer reservedRenderer = new DefaultTableCellRenderer() {
        public void setValue(Object value) {
            this.setFont(new java.awt.Font("Dialog", java.awt.Font.ITALIC,11));
            setText((value == null) ? "" : value.toString());
        }
    };


  }


  class DeclWrapper {
    XSElementDecl d;

    DeclWrapper(XSElementDecl d) {
      this.d=d;
    }

    public String toString() {
      return d.getName();
    }
  }

  XSElementDecl GetRootFor(SchemaGrammar n, MapNamespace map, boolean prompt_default_root) {
    //NamedNodeMapImpl n=new NamedNodeMapImpl();
//    List l=new List();

    Hashtable h= new Hashtable();
    DeclWrapper def=null;

    if (map==null)
      map=ConfigureNamespacesDialog.getMappingFor(n.getTargetNamespace());
    XSNamedMap elements = n.getComponents(XSConstants.ELEMENT_DECLARATION);
    Vector v=new Vector();
    for (int i = 0; i < elements.getLength(); i++) {
      XSElementDecl d=(XSElementDecl) elements.item(i);
      v.add(new DeclWrapper(d));
      if (map!=null && d.getName().equalsIgnoreCase(map.getRoot()))
      if (prompt_default_root)
        def=(DeclWrapper)v.lastElement(); else
        return d;
    }

    java.util.Collections.sort(v,new ToStringComparator());

    if (v.size()==0) {
      JOptionPane.showMessageDialog(this,"There is no root element available for this namespace","",JOptionPane.INFORMATION_MESSAGE);
      return null;
    }

    JComboBox cb=new JComboBox(v);
    cb.setSelectedItem(def);
    if (JOptionPane.showConfirmDialog(this,cb,"Select root element", JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION)
      if (cb.getSelectedItem()!=null)
        return ((DeclWrapper)cb.getSelectedItem()).d;

    return null;
  }

  class ToStringComparator extends Object implements Comparator {
    public int compare(Object object, Object object1) {
      return object.toString().compareTo(object1.toString());
    }
  }

  String GetAnno(XSAnnotation a) {
    if (a==null)
      return null;
    String anno=a.getAnnotationString();
    int from=0;
    int from2=0;
    while ((from=anno.indexOf("<",from))!=-1 && (from2=anno.indexOf(">",from))!=-1) {
      int sourceAttr=anno.indexOf("source=\"",from);
      if (sourceAttr!=-1 && sourceAttr<from2) {
        sourceAttr =  sourceAttr + "source=\"".length();
        anno = anno + anno.substring(sourceAttr,anno.indexOf("\"",sourceAttr));
      }
      anno = anno.substring(0, from) + anno.substring(from2 + 1);
    }
    if (anno.equals(""))
      anno=null;
    return anno;
  }

  String GetAnno(XSObjectList ol) {
    if (ol!=null)
    for (int i=0; i<ol.getLength(); i++)
      if (GetAnno((XSAnnotation)ol.item(i))!=null)
        return GetAnno((XSAnnotation)ol.item(i));
    return null;
  }


  void AddInserts(int INSERT_WHERE, JComponent menu) {
    menu.removeAll();
    if (GetSelectedNode()==null) return;
    Vector Required=new Vector();
    Vector Optional=new Vector();
    switch (INSERT_WHERE) {
      case INSERT_BEFORE:  FeasibleNodesHelper.ValidNodesBefore(GetSelectedNode(),Required,Optional); break;
      case INSERT_AFTER:  FeasibleNodesHelper.ValidNodesAfter(GetSelectedNode(),Required,Optional); break;
      case INSERT_CHILD:  FeasibleNodesHelper.ValidNodesForChildAppending(GetSelectedNode(),Required,Optional); break;
      case INSERT_ATTRIBUTE: FeasibleNodesHelper.ValidAttributes(GetSelectedNode(),Required,Optional); break;
    }

    int RequiredCount=Required.size();
    Required.addAll(Optional);
    if (!Required.isEmpty())
      menu.setForeground(Color.black); else
      menu.setForeground(Color.gray);
    MarkImportance(menu,RequiredCount>0);

    Vector lv=Required.size()>20 ? new Vector() : null;

    for (int i=0; i<Required.size(); i++) {
      XSObject d=(XSObject)Required.get(i);
      if (d instanceof XSWildcardDecl) {

        XSWildcardDecl wc=(XSWildcardDecl)d;

        if (wc.getConstraintType()==XSWildcard.NSCONSTRAINT_LIST) {
          StringList sl = wc.getNsConstraintList();
          for (int i2 = 0; i2 < sl.getLength(); i2++) {
            XSNamespaceItem n = IDConstraintHelper.GetNamespaceItem(sl.item(i2), newRoot);
            if (n == null)
              continue;
            MapNamespace map = ConfigureNamespacesDialog.getMappingFor(sl.item(i2));
            JMenuItem mi = new JMyMenuItem(this,
                                           "(" +
                                           (map != null ? map.toString() :
                                            sl.item(i2)) + ")", n, INSERT_WHERE);
            MarkImportance(mi, i < RequiredCount);
            menu.add(mi);
          }
        } else {
          JMenuItem mi = new JMyMenuItem(this, "(any)", null, INSERT_WHERE);
          MarkImportance(mi, i < RequiredCount);
          menu.add(mi);
        }

      } else {
        XSObject[] ve=new XSObject[1];
        if (d instanceof XSElementDecl) {
          XSModelImpl si=(XSModelImpl)((PSVIElementNSImpl)newRoot.getDocumentElement()).getSchemaInformation();
          XSObjectList ol=si.getSubstitutionGroup((XSElementDeclaration)d);
          if (ol!=null) {
            ve = new XSObject[ol.getLength() + 1];
            for (int ii = 0; ii < ol.getLength(); ii++)
              ve[ii + 1] = ol.item(ii);
          }
        }
        ve[0]=d;
        for (int ii=0; ii<ve.length; ii++) {
        XSObject dd=ve[ii];
        JMenuItem mi = new JMyMenuItem(this,dd.getName(), dd, INSERT_WHERE);

        String anno=null;
        if (dd instanceof XSElementDecl) {
          XSElementDeclaration ed=(XSElementDeclaration)dd;
          anno=GetAnno(ed.getAnnotation());
          if (anno==null && ed.getTypeDefinition() instanceof XSComplexTypeDecl)
            anno=GetAnno(((XSComplexTypeDecl)ed.getTypeDefinition()).getAnnotations());
        }
        if (dd instanceof XSAttributeDecl)
          anno=GetAnno(((XSAttributeDecl)dd).getAnnotation());
        if (anno!=null)
          mi.setToolTipText(anno);

        MarkImportance(mi, i < RequiredCount);

        if (lv!=null)
          lv.add(mi); else
          menu.add(mi);
      }
    }
    }

    if (lv!=null) {
      Collections.sort(lv,new ToStringComparator());
      JList l=new JList(lv);
      //l.addActionListener(new Frame3_mi_actionAdapter(this));
      l.addMouseListener(new Frame3_jList1_mouseAdapter(this));
      l.setOpaque(true);
      l.setVisibleRowCount(10);
      /*JMenu l=new JMenu();
      for (int i=0; i<lv.size(); i++)
        l.add((JMenuItem)lv.get(i));
      l.setMinimumSize(new Dimension(40,100));
      l.setPreferredSize(new Dimension(40,100));*/
      JScrollPane sp=new JScrollPane(l);
      sp.setOpaque(true);
      sp.setBorder(null);
      l.setBorder(null);
      menu.add(sp);
      l.setBackground(menu.getBackground());
    }

    if (GetSelectedNode()!=null) {
      menu.add(new JPopupMenu.Separator());
      menu.add(new JMyMenuItem(this, "(arbitrary)", null, INSERT_WHERE));
    }
  }

  void jMenuAfter_menuSelected(MenuEvent e) {
    AddInserts(INSERT_AFTER,jMenuAfter);
  }

  void jMenuBefore_menuSelected(MenuEvent e) {
    AddInserts(INSERT_BEFORE,jMenuBefore);
  }

  void jMenuAddChild_menuSelected(MenuEvent e) {
    AddInserts(INSERT_CHILD,jMenuAddChild);
  }


  void this_windowClosed(WindowEvent e) {
  }

  void this_windowClosing(WindowEvent e) {
    Properties myProp = new Properties();
    try {
      FileOutputStream fis = new FileOutputStream(userDir+"/"+"config.properties");
      if (this.currFileName!=null)
        myProp.setProperty("lastFile",this.currFileName);
      myProp.setProperty("numberNS",new Integer(ConfigureNamespacesDialog.MapNamespaces.size()).toString());
      for (int i=0; i<ConfigureNamespacesDialog.MapNamespaces.size(); i++) {
        MapNamespace map=(MapNamespace)ConfigureNamespacesDialog.MapNamespaces.get(i);
        String si=new Integer(i).toString();
        myProp.setProperty("DESC"+si,map.getDesc());
        myProp.setProperty("NS"+si,map.getNamespace());
        myProp.setProperty("LOC"+si,map.getLiteralSystemID());
        myProp.setProperty("ROOT"+si,map.getRoot());
      }
      /*
      myProp.setProperty("WindowTop",""+this.getY());
      myProp.setProperty("WindowLeft",""+this.getX());
      myProp.setProperty("WindowWidth",""+getWidth());
      myProp.setProperty("WindowHeight",""+getHeight());*/

      myProp.setProperty("fontFamilyForDOM",this.fontFamilyForDOM);
      myProp.setProperty("fontFamilyForSRC",this.fontFamilyForSRC);

      myProp.store(fis,"aheader");
    } catch(IOException ee) {
    }
  }


  // Display the About box.
  void helpAbout() {
    AboutDialog dlg = new AboutDialog(this);
    dlg.setLocationRelativeTo(this);
    dlg.show();
  }

  void jMenu3_actionPerformed(ActionEvent e) {
  }

  void jMenuItem6_actionPerformed(ActionEvent e) {
    helpAbout();
  }

  void jMenuItem3_actionPerformed(ActionEvent e) {
    if (okToAbandon()) {
      System.exit(0);
    }
  }

  void jMenuItem7_actionPerformed(ActionEvent e) {
    saveAsFile();
  }

  class NOe
      implements ErrorHandler, DOMErrorHandler

  {
      String msg="";

      public NOe() {
      }

      public void warning(SAXParseException ex) {
      }

      public void error(SAXParseException ex) {
      }

      public void fatalError(SAXParseException ex) throws SAXException {
      }

      public boolean handleError(DOMError error){
          msg=msg+"<br>"+error.getMessage();
          return true;
      }

  }

  void setNoNamespaceSchemaLocation(Element node, String schemaLocation) {
    IDConstraintHelper.AddPrefix(node,
                                 "xsi",
                                 "http://www.w3.org/2001/XMLSchema-instance");
    PSVIAttrNSImpl newNode = new PSVIAttrNSImpl((CoreDocumentImpl)node.getOwnerDocument(),
        "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:noNamespaceSchemaLocation");
    newNode.setValue(schemaLocation);
    node.setAttributeNodeNS(newNode);
  }

  void setSchemaLocation(Element node, String schemaLocation, String NS_URI) {
    IDConstraintHelper.AddPrefix(node,
                                 "xsi",
                                 "http://www.w3.org/2001/XMLSchema-instance");
    PSVIAttrNSImpl newNode = new PSVIAttrNSImpl((CoreDocumentImpl)node.getOwnerDocument(),
        "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:schemaLocation");
    newNode.setValue(NS_URI+" "+schemaLocation);
    node.setAttributeNodeNS(newNode);
  }

  /** Property identifier: symbol table. */
      public static final String SYMBOL_TABLE =
          org.apache.xerces.impl.Constants.XERCES_PROPERTY_PREFIX + org.apache.xerces.impl.Constants.SYMBOL_TABLE_PROPERTY;

      /** Property identifier: grammar pool. */
      public static final String GRAMMAR_POOL =
          org.apache.xerces.impl.Constants.XERCES_PROPERTY_PREFIX + org.apache.xerces.impl.Constants.XMLGRAMMAR_POOL_PROPERTY;

      // feature ids

      /** Namespaces feature id (http://xml.org/sax/features/namespaces). */
      protected static final String NAMESPACES_FEATURE_ID = "http://xml.org/sax/features/namespaces";

      /** Validation feature id (http://xml.org/sax/features/validation). */
      protected static final String VALIDATION_FEATURE_ID = "http://xml.org/sax/features/validation";

      /** Schema validation feature id (http://apache.org/xml/features/validation/schema). */
      protected static final String SCHEMA_VALIDATION_FEATURE_ID = "http://apache.org/xml/features/validation/schema";

      /** Schema full checking feature id (http://apache.org/xml/features/validation/schema-full-checking). */
      protected static final String SCHEMA_FULL_CHECKING_FEATURE_ID = "http://apache.org/xml/features/validation/schema-full-checking";



  void jNewFromItem_actionPerformed(ActionEvent e) {
    if (!newFile()) return;
    DialogSchemaLocation.DialogCanceled=false;
    //parser = new DOMParserSaveEncoding();
    XSNamespaceItem n=null;
    MapNamespace map=((JNewFromMenuItem)e.getSource()).d;

    if (map==null) {
      if (JFileChooser.APPROVE_OPTION == jSchemaChooser.showOpenDialog(this))
        map = new MapNamespace("", "", jSchemaChooser.getSelectedFile().getPath(), ""); else
        return;
    }
    String testRoot=(map.hasRoot() ? map.getRoot() : "testroot");

    if (map.isDTD() && !map.hasRoot())
      testRoot=this.ChooseName();
    if (testRoot==null) return;

    PSVIDocumentImpl parameterDocument =(PSVIDocumentImpl) PSVIDOMImplementationImpl.getDOMImplementation().createDocument(map.getNamespace(),testRoot,null);
    if (map.isDTD()) {
      DocumentType dt = parameterDocument.createDocumentType(testRoot, null,
          map.getExpandedSystemId());
      parameterDocument.insertBefore(dt,parameterDocument.getDocumentElement());
    } else
    {
      NOe myNOe= new NOe();
      org.apache.xerces.dom.DOMConfigurationImpl config = (org.apache.xerces.dom.DOMConfigurationImpl) parameterDocument.
          getDomConfig();
      try {

      config.setProperty(
          "http://apache.org/xml/properties/internal/grammar-pool",
          myFullGrammarPool);
      config.setParameter("error-handler", myNOe);
      config.setParameter("validate", Boolean.TRUE);
      config.setParameter("psvi", Boolean.TRUE);
      //config.setProperty(Constants.XERCES_PROPERTY_PREFIX + Constants.ERROR_REPORTER_PROPERTY,ErrRep);
      //wenn ERROR_REPORTER gesetzt-> fehler
      config.setEntityResolver(es2);


      XMLGrammarPreparser preparser=new XMLGrammarPreparser();
      preparser.registerPreparser(XMLGrammarDescription.XML_SCHEMA, null);
      preparser.setProperty(GRAMMAR_POOL, myFullGrammarPool);
      //preparser.setFeature(SCHEMA_VALIDATION_FEATURE_ID, true);
      // preparser.setFeature(SCHEMA_FULL_CHECKING_FEATURE_ID, false);

      //preparser.setErrorHandler((XMLErrorHandler)myNOe);
      preparser.setFeature(VALIDATION_FEATURE_ID, true);
      //preparser.setParameter("psvi", Boolean.TRUE);
      preparser.setEntityResolver(es2);
      Grammar g=preparser.preparseGrammar(XMLGrammarDescription.XML_SCHEMA,new XMLInputSource(null, map.getExpandedSystemId(), null));
      n=(XSNamespaceItem)g;


            /*
      //with following "preparsing" method, it is not possible
      //to preparse a XML Schema having a targetNamespace,
      //when you only know the file location and not the targetNamespace
      //so using XMLGrammarPreparser as above is better

        if (map.hasNoNamespace()) {
               setNoNamespaceSchemaLocation(parameterDocument.getDocumentElement(),
                                 map.getExpandedSystemId());
        }
        parameterDocument.normalizeDocument();

        if (map.hasLocation())
          n = IDConstraintHelper.GetNoNamespaceItem(map.getExpandedSystemId(),
              parameterDocument);
        if (n==null)
          n = IDConstraintHelper.GetNamespaceItem(map.getNamespace(),
                                                  parameterDocument);*/

      }
      catch (Exception ee) {
        JOptionPane.showMessageDialog(this, ee.getMessage(),
                                      "Error", JOptionPane.WARNING_MESSAGE);

      }
      //    CoreDocumentImpl parameterDocument =(CoreDocumentImpl) DOMImplementationImpl.getDOMImplementation().createDocument(map.getNamespace(),"rootele",null);
      //newRoot
      //XSModelImpl mi=(XSModelImpl)((PSVIElementNSImpl)parameterDocument.getDocumentElement()).getSchemaInformation();

      if (n == null) {
        if (!map.hasLocation())
          JOptionPane.showMessageDialog(this,
              "<html>The schema file for namespace <b>\"" + map.getNamespace() +
              "\"</b> seems to be not valid by itself"+myNOe.msg+"</html>",
                                        "Schema error",
                                        JOptionPane.WARNING_MESSAGE);
        else
        if (JOptionPane.showConfirmDialog(this,
            "<html>The schema file for namespace <b>\"" + map.getNamespace() +
            "\"</b> seems to be not valid by itself."+myNOe.msg+"<br>Do you want to open the file?</html>",
                                          "Schema error",
                                          JOptionPane.YES_NO_OPTION) ==
            JOptionPane.YES_OPTION)
          try {

            java.net.URI u = new java.net.URI(map.getExpandedSystemId());
            openFile((new File(u)).getPath());

            //org.apache.xerces.util.URI u = new org.apache.xerces.util.URI(map.getExpandedSystemId());
            //openFile(u.getPath());

            //openFile(XMLEntityManager.expandSystemId(map.getLocation(),System.getProperty("user.dir")+"\\", false));
            return;
          }
          catch (Exception ee) {
          }
        newFile();
        return;
      }
      if (! (n instanceof SchemaGrammar))
        return;
      XSElementDecl root = GetRootFor( (SchemaGrammar) n, map,false);
      if (root == null)
        return;

      parameterDocument = (PSVIDocumentImpl) PSVIDOMImplementationImpl.
          getDOMImplementation().createDocument(root.getNamespace(),
                                                root.getName(), null);
      config = (DOMConfigurationImpl) parameterDocument.getDomConfig();
      //config.setParameter("error-handler", new NOe());
      config.setProperty(
          "http://apache.org/xml/properties/internal/grammar-pool",
          myFullGrammarPool);
      config.setParameter("error-handler", new NOe()); //this must be set otherwise XSDHandler.reset.fSchemaParser.setProperty(ERROR_HANDLER, currErrorHandler) with currErrorHandler==null
      config.setParameter("validate", Boolean.TRUE);
      config.setParameter("psvi", Boolean.TRUE);
      config.setEntityResolver(es2);
      //myFullGrammarPool.getGrammar(s)

      if (/*map.hasNoNamespace()*/root.getNamespace()==null) {
        setNoNamespaceSchemaLocation(parameterDocument.getDocumentElement(),
                          map.getExpandedSystemId());
      } else
      if (map.hasNoNamespace()) {
        setSchemaLocation(parameterDocument.getDocumentElement(),
                          map.getExpandedSystemId(),root.getNamespace());
      }


      parameterDocument.normalizeDocument();
      IDConstraintHelper.AddSchemaPrefixes( (SchemaGrammar) n
          /*myFullGrammarPool.GetNS(map.getNamespace())*/,
                                           parameterDocument.getDocumentElement());
      FillNeeded( (PSVIElementNSImpl) parameterDocument.getDocumentElement(),
                 (PSVIElementNSImpl) parameterDocument.getDocumentElement());
    }
    setRoot(parameterDocument);
    SetDomModified(parameterDocument.getDocumentElement());
    SetClean();
  }



  void SetTextBefore(Node node, String s) {
    if (node!=null)
    if (node.getPreviousSibling()!=null && node.getPreviousSibling().getNodeType()==Node.TEXT_NODE)
      node.getPreviousSibling().setNodeValue(s); else
      node.getParentNode().insertBefore(node.getOwnerDocument().createTextNode(s),node);
  }

  void SetTextContent(Node node, String s) {
    if (node instanceof ParentNode)
      ((ParentNode)node).setTextContent(s);
  }


  void SetTextAfter(Node node, String s) {
    if (node!=null)
    if (node.getNextSibling()!=null && node.getNextSibling().getNodeType()==Node.TEXT_NODE)
      node.getNextSibling().setNodeValue(s); else
      node.getParentNode().insertBefore(node.getOwnerDocument().createTextNode(s),node.getNextSibling());
  }


  void jMenuDeleteNode_actionPerformed(ActionEvent e) {
    Node pnode=GetSelectedNode().getParentNode();
    if (pnode==null) return;
    pnode.removeChild(GetSelectedNode());
    SetDomModified(pnode);
  }


  void jTabbedPane1_propertyChange(PropertyChangeEvent e) {

  }

  boolean AlwaysUpdateXML=true/*for undo capability*/;

  boolean UpdatingDocument=false;
  JPanel jPanel3 = new JPanel();
  JButton jButtonAddAttr2 = new JButton();
  JButton jButtonDeleteAttr = new JButton();
  BoxLayout boxLayout23;
  Border border4;
  Border border5;
  JMenuItem jMenuItem11 = new JMenuItem();
  JPanel jPanel5 = new JPanel();
  BoxLayout boxLayout24/* = new BoxLayout2()*/;
  JPanel jPanel6 = new JPanel();
  BoxLayout boxLayout25;
  JButton jButton12 = new JButton();

  CompoundEdit collectUndo;

  int EqualCharsFromBegin(String oldXML,String newXML) {
    int i = 0;
    int maxEqual=Math.min(newXML.length(), oldXML.length());
    for (i = 0; i < maxEqual; i++)
      if (newXML.charAt(i) != oldXML.charAt(i))
        break;
    return i;
  }

  int EqualCharsFromEnd(String oldXML,String newXML,int EqualCharsFromBegin) {
    int i2 = 0;
    int maxEqual=Math.min(newXML.length(), oldXML.length())-EqualCharsFromBegin;
    for (i2 = 0; i2 < maxEqual; i2++)
      if (newXML.charAt(newXML.length() - i2 - 1) !=
          oldXML.charAt(oldXML.length() - i2 - 1))
        break;
    return i2;
  }

  void UpdateXML() {

    try {
      if (!XmlUpToDate && newRoot!=null &&
          (jTabbedPane1.getSelectedComponent() == jPanel5 || AlwaysUpdateXML)) {
        String newXML = saveXml(newRoot).toString(EncodingMap.getIANA2JavaMapping(getOutputEncoding()));

        /*
        //FileInputStream fos = new FileInputStream(fileName);
        Reader sr=new java.io.StringReader(newXML);
        StringReader ssr=new StringReader(newXML);
        ByteArrayInputStream asdf=new ByteArrayInputStream(newXML.getBytes());
        //asdf.read();
        //InputStream ip=ByteArrayInputStream();
        InputStreamReader in = new InputStreamReader(asdf, "UTF-8" );
        char[] ch=new char[newXML.length()];
        int how=in.read(ch,0,ch.length);
        newXML=new String(ch,0,how);
*/

        String oldXML = jTextXML.getText();
        int i = EqualCharsFromBegin(oldXML,newXML);
        int i2 = EqualCharsFromEnd(oldXML,newXML,i);
        UpdatingDocument = true;
        collectUndo=new CompoundEdit();
        document1.remove(i, oldXML.length() - i2 - i);
        document1.insertString(i, newXML.substring(i, newXML.length() - i2), null);
        collectUndo.end();
        undo.addEdit(collectUndo);
        collectUndo = null;
        UpdatingDocument = false;
        XmlUpToDate = true;
        if (GetSelectedNode() instanceof PSVIElementNSImpl)
          SelectTextFromNode((PSVIElementNSImpl)GetSelectedNode());
      }
    }
    catch(Exception e) {
      JOptionPane.showMessageDialog(this,"Cannot serialize DOM tree: "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
    }
  }


  /**
   * Listener for the edits on the current document.
   */
  protected UndoableEditListener undoHandler = new UndoHandler();

  /** UndoManager that we add edits to. */
  protected UndoManager undo = new UndoManager();


  JMenuItem jMenuItemUndo = new JMenuItem();
  JMenuItem jMenuItemRedo = new JMenuItem();
  JMenu jMenuElement = new JMenu();



  class UndoHandler implements UndoableEditListener {

      /**
       * Messaged when the Document has created an edit, the edit is
       * added to <code>undo</code>, an instance of UndoManager.
       */
      public void undoableEditHappened(UndoableEditEvent e) {
        if (collectUndo!=null)
          collectUndo.addEdit(e.getEdit()); else
          undo.addEdit(e.getEdit());
      }
  }


  void jTabbedPane1_stateChanged(ChangeEvent e) {
    UpdateXML();
  }

  boolean NotSelectNodeXML=false;
  JMenuItem jMenuItem5 = new JMenuItem();


  void SelectTreeNode(Node node) {
    if (node==null) return;
    m_tree.setSelectionPath(getPath(node));
    m_tree.scrollPathToVisible(m_tree.getSelectionPath());
  }

  void errorSel_valueChanged(ListSelectionEvent e) {
    if (/*!e.getValueIsAdjusting() && */jTable2.getSelectedRow()!=-1) {
      ParseError err=(ParseError) ef.errorItems.get(jTable2.getSelectedRow());
      if (newRoot!=null && err.getRelatedNode()!=null) {
        SelectTreeNode(err.getRelatedNode());
      } else
      if (err.getLineNo()>=1 && err.getCharOffset()>=1)
      try {
        int start=jTextXML.getLineStartOffset(err.getLineNo()-1)+err.getCharOffset()-1;
        jTextXML.select(start,start+1);
        jTextXML.getCaret().setSelectionVisible(true);
      }
      catch (BadLocationException ee) {
      }
    }
  }


  // Display the About box.
  void showOptions() {
    ConfigureNamespacesDialog dlg = new ConfigureNamespacesDialog(this);
    dlg.setLocationRelativeTo(this);
    dlg.show();
  }


  void jMenuItem9_actionPerformed(ActionEvent e) {
    showOptions();
  }

  void jNewFromItem_menuSelected(MenuEvent e) {
  }

  void jMenuBefore_actionPerformed(ActionEvent e) {

  }

  boolean newFile() {
    // Handle the File|New menu item.
    if (okToAbandon()) {
      // clears the text of the TextArea
      //m_tree.removeAll();
      // clear the current filename and set the file as clean:
      /*currFileName = null;
      dirty = false;
      updateCaption();*/
      openFile(null);
      return true;
    }
    return false;
  }

  void jMenuItem8_actionPerformed(ActionEvent e) {
    newFile();
  }

  void jMenuNewFrom_menuSelected(MenuEvent e) {
    jMenuNewFrom.removeAll();
    for (int i=0; i<ConfigureNamespacesDialog.MapNamespaces.size(); i++) {
      MapNamespace map = (MapNamespace) ConfigureNamespacesDialog.MapNamespaces.get(i);
      if (map.hasNamespace() && ConfigureNamespacesDialog.getMappingFor(map.getNamespace())!=map) continue;
      if (!map.hasDesc()) continue;
      JMenuItem mi=new JNewFromMenuItem(map.toString(),map);
      mi.addActionListener(new Frame3_jNewFromItem_actionAdapter(this));
      jMenuNewFrom.add(mi);
    }
    JMenuItem mi=new JNewFromMenuItem("(Choose Schema)",null);
    mi.addActionListener(new Frame3_jNewFromItem_actionAdapter(this));
    jMenuNewFrom.add(mi);
  }

  String Shorten(String s, Node node) {
    if (node!=null && node.getNamespaceURI()!=null)
      return s.replaceAll("\""+node.getNamespaceURI()+"\":",""); else
      return s;
  }

  void jMenuItem10_actionPerformed(ActionEvent e) {
    if (this.GetSelectedNode() instanceof PSVIElementNSImpl) {
      PSVIElementNSImpl node=(PSVIElementNSImpl)this.GetSelectedNode();
      String decl="Not available";
      if (node.getTypeDefinition()!=null)
        decl=Shorten(node.getTypeDefinition().toString(),node);
      JTextPane  t=new JTextPane ();
      t.setText(decl);
      t.setPreferredSize(new Dimension(700,100));
      JScrollPane sc=new JScrollPane(t);
      JOptionPane.showMessageDialog(this,sc,
                                      "Element declaration of " + "\"" +
                                      node.getLocalName() + "\"",
                                      JOptionPane.INFORMATION_MESSAGE);
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    helpAbout();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    saveFile();
  }

  void DisplayPopup(int INSERT, JButton button) {
    JPopupMenu pop=new JPopupMenu();
    AddInserts(INSERT,pop);
    pop.show(button,0,button.getHeight());
  }

  void jButtonAddBefore_actionPerformed(ActionEvent e) {
    DisplayPopup(INSERT_BEFORE,jButtonAddBefore);
  }

  void jButtonAddAfter_actionPerformed(ActionEvent e) {
    DisplayPopup(INSERT_AFTER,jButtonAddAfter);
  }

  void jButton9_actionPerformed(ActionEvent e) {
    DisplayPopup(INSERT_CHILD,jButton9);
  }

  void jButtonAddAttr_actionPerformed(ActionEvent e) {
    DisplayPopup(INSERT_ATTRIBUTE,(JButton)e.getSource());
  }

  void document1_changedUpdate(DocumentEvent documentEvent) {
    if (!UpdatingDocument) SetTextModified(false,false);
  }

  void jButtonDeleteAttr_actionPerformed(ActionEvent e) {
//    if (jTable1.getSelectedRow()
    int sel=jTable1.getSelectedRow();
    if (sel>=0) {
      NodeImpl node=getAttrNode(GetSelectedNode(),sel);
      if (node instanceof AttrImpl) {
        ( (AttributeMap) GetSelectedNode().getAttributes()).removeNamedItem(
            node.getNodeName());
        SetDomModified(GetSelectedNode());
        ConfigureNamespacesDialog.DoUpdateTable(jTable1, sel);
        return;
      }
    }
    JOptionPane.showMessageDialog(this,"No attribute selected","Error",JOptionPane.WARNING_MESSAGE);
  }

  void jButton12_actionPerformed(ActionEvent e) {
    SetTextModified(true,false);
  }

  void jMenuItem11_actionPerformed(ActionEvent e) {
    Node node=GetSelectedNode();
    Node pnode=node.getParentNode();
    if (pnode==null) return;
    Node cnode=node.getFirstChild();
    while (cnode!=null) {
      node.removeChild(cnode);
      pnode.insertBefore(cnode,node);
      cnode=node.getFirstChild();
    }
    pnode.removeChild(node);
    SetDomModified(pnode);
  }

  void UndoOrRedo(boolean Undo) {
    UpdateXML();
    String oldXML=jTextXML.getText();
    if (Undo)
      undo.undo(); else
      undo.redo();
    String newXML=jTextXML.getText();
    int i = EqualCharsFromBegin(oldXML,newXML);
    int i2 = EqualCharsFromEnd(oldXML,newXML,i);
    jTextXML.setSelectionStart(i);
    jTextXML.setSelectionEnd(newXML.length()-i2);

  }

  void jMenuItemUndo_actionPerformed(ActionEvent e) {
    UndoOrRedo(true);
  }

  void jMenuItemRedo_actionPerformed(ActionEvent e) {
    UndoOrRedo(false);
  }

  Node FindNode(Node node, int c) {
    if (!(node instanceof ParentNode)) return null;
    Object ob = ((ParentNode)node).getUserData("loc");
    if (ob instanceof SrcInfo) {
      SrcInfo i = (SrcInfo) ob;
      if (c==i.startTag || c==i.closeTag)
        return node;
      if (c<i.startTag || c>i.closeTag)
        return null;
    }
    Node cnode=node.getFirstChild();
    while (cnode!=null) {
      Node node2=FindNode(cnode,c);
      if (node2!=null) return node2;
      cnode=cnode.getNextSibling();
    }
    return node;
  }


  void jTextXML_caretPositionChanged(CaretEvent e) {

  }

  void jTextXML_mouseClicked(MouseEvent e) {
    if (newRoot==null) return;
    int i=CountLT(jTextXML.getText(),jTextXML.getSelectionStart());
    Node node=FindNode(newRoot.getDocumentElement(),i);
    if (node==null)
      node=newRoot.getDocumentElement();
    if (node!=null) {
      NotSelectNodeXML=true;
      SelectTreeNode(node);
      NotSelectNodeXML=false;
    }
  }

  void jTextXML_caretPositionChanged(InputMethodEvent e) {

  }

  void document2_changedUpdate(DocumentEvent documentEvent) {
    boolean NeedValidation=false;
    if (!InTextUpdate) {
      InTextUpdate = true;
      if (documentEvent.getDocument() == jTextContent.getDocument()) {
        SetTextContent(GetSelectedNode(),jTextContent.getText());
        /*if (GetSelectedNode() instanceof PSVIElementNSImpl) {
          PSVIElementNSImpl node=(PSVIElementNSImpl)GetSelectedNode();
          if (node.getTypeDefinition() instanceof XSComplexTypeDecl) {
            XSComplexTypeDecl CT=(XSComplexTypeDecl)node.getTypeDefinition();
            if (CT.getContentType() != XSComplexTypeDecl.CONTENTTYPE_MIXED)
              NeedValidation=true;
          }
        }*/
      }
      if (documentEvent.getDocument() == jTextAfter.getDocument()) {
        SetTextAfter(GetSelectedNode(), jTextAfter.getText());
      }
      if (documentEvent.getDocument() == jTextBefore.getDocument()) {
        SetTextBefore(GetSelectedNode(), jTextBefore.getText());
      }
      if (NeedValidation)
        this.SetDomModified(null); else {
        MarkDirty();
        XmlUpToDate=false;
      }
      InTextUpdate = false;
    }
  }





  static Vector getNodeValues(Vector v) {
    Vector res=new Vector();
    for (int i=0; i<v.size(); i++)
      res.add(((NodeImpl)v.get(i)).getTextContent());
    return res;
  }



  void jMenuItem5_actionPerformed(ActionEvent e) {
    int sel=jTable1.getSelectedRow();
    if (sel>=0 && getAttrNode(GetSelectedNode(),sel) instanceof AttrImpl) {
      PSVIAttrNSImpl node=(PSVIAttrNSImpl)getAttrNode(GetSelectedNode(),sel);
      String decl="Not available";
      if (node.getTypeDefinition()!=null)
        decl=node.getTypeDefinition().toString();
      JTextPane  t=new JTextPane ();
      t.setText(decl);
      t.setPreferredSize(new Dimension(700,100));
      JScrollPane sc=new JScrollPane(t);
      JOptionPane.showMessageDialog(this,sc,"Attribute declaration of \""+node.getLocalName()+"\"",JOptionPane.INFORMATION_MESSAGE);
    } else
      JOptionPane.showMessageDialog(this,"No attribute selected","Error",JOptionPane.WARNING_MESSAGE);
  }



  JButton jButton13 = new JButton();
  Border border6;
  JMenuItem jMenuItem13 = new JMenuItem();
  JMenuItem jMenuItem14 = new JMenuItem();
  JMenuItem jMenuItem15 = new JMenuItem();
  JMenuItem jMenuItem115 = new JMenuItem();
  JMenuItem jMenuItem116 = new JMenuItem();
  JMenuItem jMenuItem4 = new JMenuItem();

  String  getStylesheetLocation(ProcessingInstruction PI) {
    int i=PI.getData().indexOf("href=\"");
    if (i==-1) return null;
    i=i+"href=\"".length();
    int i2=PI.getData().indexOf("\"",i);
    if (i2==-1) return null;
    return PI.getData().substring(i,i2);
  }

  ProcessingInstruction getPI() {
    for (Node node=newRoot.getFirstChild(); node!=null; node=node.getNextSibling())
    if (node instanceof ProcessingInstruction) {
      ProcessingInstruction PI=(ProcessingInstruction) node;
      if ("xml-stylesheet".equals(PI.getTarget()) && PI.getData().indexOf("type=\"text/xsl\"")!=-1 && getStylesheetLocation(PI)!=null)
        return PI;
    }
    return null;
  }

  void jMenuItem116_actionPerformed(ActionEvent e) {


    if (JFileChooser.APPROVE_OPTION == jStylesheetChooser.showOpenDialog(this)) {
      try {
        String xsl = XMLEntityManager.expandSystemId(jStylesheetChooser.
            getSelectedFile().getPath(), null, false);

        ProcessingInstruction PI = getPI();
        if (PI == null) {
          PI = newRoot.createProcessingInstruction("xml-stylesheet", "");
          newRoot.insertBefore(PI, newRoot.getDocumentElement());
        }
        PI.setData("type=\"text/xsl\" href=\"" + xsl + "\"");
        this.SetDomModified(GetSelectedNode());
      }
      catch (Exception ee){ }


    }
  }


  void jMenuItem115_actionPerformed(ActionEvent e) {
/*
    JOptionPane.showMessageDialog(this,(new File("")).getAbsolutePath(),"Error66666666666",JOptionPane.WARNING_MESSAGE);
    JOptionPane.showMessageDialog(this,Expand("closeFile.gif"),"Error",JOptionPane.WARNING_MESSAGE);
    try {
      JOptionPane.showMessageDialog(this,
                                    (new org.apache.xerces.util.URI(Expand("closeFile.gif"))).getPath(), "Error",
                                    JOptionPane.WARNING_MESSAGE);
    }
    catch (Exception ee){

    }

    try {
      JOptionPane.showMessageDialog(this,
                                    ""+(new File((new org.apache.xerces.util.URI(Expand("closeFile.gif"))).getPath())).exists()
, "ex12",
                                    JOptionPane.WARNING_MESSAGE);
    }
    catch (Exception ee){

    }

    try {
      JOptionPane.showMessageDialog(this,
                                    ""+(new File(new org.apache.xerces.util.URI(Expand("closeFile.gif")).toString())).exists()
, "ex22",
                                    JOptionPane.WARNING_MESSAGE);
    }
    catch (Exception ee){

    }
*/


    try {
      if (getPI()==null) {
        JOptionPane.showMessageDialog(this,
                                      "No stylesheet defined", "Error",
                                    JOptionPane.WARNING_MESSAGE);
        return;
      }
      String stylesheet=
          (new File(new java.net.URI(XMLEntityManager.expandSystemId(getStylesheetLocation(getPI()), this.currFileName, false)))).getPath();





      TransformerFactory tFactory = TransformerFactory.newInstance();

      //Instantiate a DocumentBuilderFactory.
      DocumentBuilderFactory dFactory = DocumentBuilderFactory.newInstance();

      // And setNamespaceAware, which is required when parsing xsl files
      dFactory.setNamespaceAware(true);

      //Use the DocumentBuilderFactory to create a DocumentBuilder.
      DocumentBuilder dBuilder = dFactory.newDocumentBuilder();

//      dBuilder.setEntityResolver(erXSLT);

      //Use the DocumentBuilder to parse the XSL stylesheet.
      Document xslDoc = dBuilder.parse(/*"C:\\portiko\\style_23b\\style\\contentobject.xsl"*/stylesheet);

      /*parser.setErrorHandler(ef);
      parser.setProperty("http://apache.org/xml/properties/internal/entity-resolver",es2);
      parser.parse("C:\\portiko\\style_23b\\style\\contentobject.xsl");
//      parser.parse(new XMLInputSource(null,"C:\\portiko\\style_23b\\style\\contentobject.xsl","C:\\portiko\\style_23b\\style\\contentobject.xsl"));
      Document xslDoc = parser.getDocument();
*/
//      XSLTInputSource sd;

      // Use the DOM Document to define a DOMSource object.
      DOMSource xslDomSource = new DOMSource(xslDoc);

      xslDomSource.setSystemId(stylesheet);

      // Process the stylesheet DOMSource and generate a Transformer.
      Transformer transformer = tFactory.newTransformer(xslDomSource);

      // Use the DOM Document to define a DOMSource object.
      DOMSource xmlDomSource = new DOMSource(newRoot);

      // Create an empty DOMResult for the Result.
      DOMResult domResult = new DOMResult();

      // Perform the transformation, placing the output in the DOMResult.
      transformer.transform(xmlDomSource, domResult);

      ByteArrayOutputStream output=new ByteArrayOutputStream();
      //Instantiate an Xalan XML serializer and use it to serialize the output DOM to System.out
      // using a default output format.
      Serializer serializer = SerializerFactory.getSerializer
                             (OutputProperties.getDefaultMethodProperties("xml"));
      serializer.setOutputStream(output);
      serializer.asDOMSerializer().serialize(domResult.getNode());


      JOptionPane.showMessageDialog(this,
                                    "Transformation was successful, now choose a file to save the result in", "XSLT",
                                    JOptionPane.INFORMATION_MESSAGE);

      if (JFileChooser.APPROVE_OPTION == jFileChooser1.showSaveDialog(this)) {
        StringToFile(jFileChooser1.getSelectedFile().getPath(),output.toByteArray());
      }
    }
    catch (Exception ee) {
      JOptionPane.showMessageDialog(this,ee.getMessage(),"XSLT Error",JOptionPane.WARNING_MESSAGE);
    }




  }

  PSVIAttrNSImpl GetSelectedAttribute() {
    int sel=jTable1.getSelectedRow();
    if (sel>=0) {
      Node node = GetSelectedNode().getAttributes().item(sel);
      PSVIAttrNSImpl attr = (PSVIAttrNSImpl) node;
      return attr;
    }
    return null;
  }

  Element GetReferencedNode() {
    PSVIAttrNSImpl attr=GetSelectedAttribute();
    if (attr!=null) {
      Vector targets=IDConstraintHelper.getPossibleReferences(attr);
      int i=XDocUtilities.FindStringInVector(attr.getNodeValue(),getNodeValues(targets));
      if (i!=-1)
        return ((PSVIAttrNSImpl)targets.get(i)).getOwnerElement();
    }
    return null;
  }

  void jButton13_actionPerformed(ActionEvent e) {
    SelectTreeNode(GetReferencedNode());
  }

  void attrSel_valueChanged(ListSelectionEvent e) {
    UpdateAttributeUI();
  }

  void jMenuItem13_actionPerformed(ActionEvent e) {
    myFullGrammarPool.clear();
    UpdateDOM(null);
//    m_tree.invalidate();
  }

  void jList1_valueChanged(ListSelectionEvent e) {
  }

  void jList1_mouseReleased(MouseEvent e) {
    JList l=(JList)e.getSource();
    JPopupMenu pm=(JPopupMenu)l.getParent().getParent().getParent();
    pm.setVisible(false);
    jMenuElement.setSelected(false);
    jMenuElement.setPopupMenuVisible(false);
    AddOb((JMyMenuItem)l.getSelectedValue());
  }


  Object GetFindDoc() {
    if (jTabbedPane1.getSelectedComponent() == jPanel5)
      return jTextXML; else
      return m_tree;
  }

  void jMenuItem14_actionPerformed(ActionEvent e) {
    FindDialog.Find(GetFindDoc(),this);
  }

  void jMenuItem15_actionPerformed(ActionEvent e) {
    FindDialog.FindAgain(GetFindDoc(),false,this);
  }

  void jMenuItem4_actionPerformed(ActionEvent e) {
    OptionsDialog.showDialog(this);
  }

  void setFontFamily(Component c,String fontFamily) {
    c.setFont(new java.awt.Font(fontFamily,0,c.getFont().getSize()));
  }

  String fontFamilyForSRC="Arial";
  String fontFamilyForDOM="Arial";
  JMenuItem menuItem1 = new JMenuItem();

  void setFontFamilyForSRC(String s) {
    fontFamilyForSRC=s;
    setFontFamily(jTextXML,fontFamilyForSRC);
  }

  void setFontFamilyForDOM(String s) {
    fontFamilyForDOM=s;
    setFontFamily(jTextContent,fontFamilyForDOM);
    setFontFamily(jTextBefore,fontFamilyForDOM);
    setFontFamily(jTextAfter,fontFamilyForDOM);
    setFontFamily(jTable1,fontFamilyForDOM);
    UpdateElementUI();
  }

  void menuItem1_actionPerformed(ActionEvent e) {
    if (jTable2.getSelectedRow()!=-1) {
      ParseError err = ( (ParseError) ef.errorItems.get(jTable2.getSelectedRow()));
      StringSelection ss = new StringSelection(err.toString());
      Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

    }
  }

  void jTable2_mouseReleased(MouseEvent e) {
    if (e.getButton()==e.BUTTON3)
      popm.show(e.getComponent(),e.getX(),e.getY());
  }

  void m_tree_mouseReleased(MouseEvent e) {

    if (e.getButton()!=e.BUTTON3) return;

    TreePath path = m_tree.getPathForLocation(e.getX(), e.getY());
    if (path != null) {
      Node node = (Node) path.getLastPathComponent();
      SelectTreeNode(node);
    }
    if (jMenuElement.isEnabled())
      jMenuElement.getPopupMenu().show(e.getComponent(), e.getX(), e.getY());
  }

  void jMenu1_menuSelected(MenuEvent e) {
  }

  void jMenuElement_menuSelected(MenuEvent e) {
      jMenuElement.getPopupMenu().setInvoker(jMenuElement);
  }

  void m_tree_keyReleased(KeyEvent e) {
    if (jMenuElement.isEnabled() && jMenuDeleteNode.isEnabled() && e.getKeyCode()==KeyEvent.VK_DELETE)
      jMenuDeleteNode.doClick();
  }

  void jTable1_keyReleased(KeyEvent e) {
    if (jMenuElement.isEnabled() && jMenuDeleteAttribute.isEnabled() && e.getKeyCode()==KeyEvent.VK_DELETE)
      jMenuDeleteAttribute.doClick();
  }



}

class JMyMenuItem extends JMenuItem {
  Object d;
  int INSERT_WHERE;
  public JMyMenuItem(Frame3 adaptee,String string,Object d,int INSERT_WHERE) {
    super(string);
    this.d=d;
    this.INSERT_WHERE=INSERT_WHERE;
    addActionListener(new Frame3_mi_actionAdapter(adaptee));
  }
  public String toString() {
    return this.getText();
  }
}

class JNewFromMenuItem extends JMenuItem {
  MapNamespace d;
  public JNewFromMenuItem(String string,MapNamespace d) {
    super(string);
    this.d=d;
  }
}


class Frame3_jMenuItem1_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem1_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem1_actionPerformed(e);
  }
}


class Frame3_mi_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_mi_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.mi_actionPerformed(e);
  }
}


class Frame3_jMenuItem2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem2_actionPerformed(e);
  }
}

class Frame3_this_windowAdapter extends java.awt.event.WindowAdapter {
  Frame3 adaptee;

  Frame3_this_windowAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void windowOpened(WindowEvent e) {
    adaptee.this_windowOpened(e);
  }
  public void windowClosed(WindowEvent e) {
    adaptee.this_windowClosed(e);
  }
  public void windowClosing(WindowEvent e) {
    adaptee.this_windowClosing(e);
  }
}



    class MyPSVIAttrNSImpl extends PSVIAttrNSImpl implements AttributePSVI {

          public MyPSVIAttrNSImpl(CoreDocumentImpl ownerDocument, XSAttributeDeclaration d) {
            super(ownerDocument, d.getNamespace(), d.getName());
            fDeclaration=d;
          }

/*          public void PreferPrefix() {
            String prefix=this.lookupPrefix(this.getNamespaceURI());
            if (prefix!=null)
              setPrefix(prefix);
          }*/
    }

class Frame3_jMenuAfter_menuAdapter implements javax.swing.event.MenuListener {
  Frame3 adaptee;

  Frame3_jMenuAfter_menuAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void menuSelected(MenuEvent e) {
    adaptee.jMenuAfter_menuSelected(e);
  }
  public void menuDeselected(MenuEvent e) {
  }
  public void menuCanceled(MenuEvent e) {
  }


}

class Frame3_jMenuBefore_menuAdapter implements javax.swing.event.MenuListener {
  Frame3 adaptee;

  Frame3_jMenuBefore_menuAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void menuSelected(MenuEvent e) {
    adaptee.jMenuBefore_menuSelected(e);
  }
  public void menuDeselected(MenuEvent e) {
  }
  public void menuCanceled(MenuEvent e) {
  }
}

class Frame3_jMenuAddChild_menuAdapter implements javax.swing.event.MenuListener {
  Frame3 adaptee;

  Frame3_jMenuAddChild_menuAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void menuSelected(MenuEvent e) {
    adaptee.jMenuAddChild_menuSelected(e);
  }
  public void menuDeselected(MenuEvent e) {
  }
  public void menuCanceled(MenuEvent e) {
  }
}



class Frame3_jMenuItem6_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem6_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem6_actionPerformed(e);
  }
}

class Frame3_jMenuItem3_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem3_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem3_actionPerformed(e);
  }
}

class Frame3_jMenuItem7_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem7_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem7_actionPerformed(e);
  }
}


class Frame3_m_tree_treeSelectionAdapter implements javax.swing.event.TreeSelectionListener {
  Frame3 adaptee;

  Frame3_m_tree_treeSelectionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void valueChanged(TreeSelectionEvent e) {
    adaptee.m_tree_valueChanged(e);
  }
}

class UI
  extends BasicSplitPaneUI
 {
  public BasicSplitPaneDivider createDefaultDivider()
  {
   return new UID( this );
  }
 }

 class UID
  extends BasicSplitPaneDivider
 {
  public UID( BasicSplitPaneUI ui )
  {
   super( ui );
  }
  public void paint( Graphics g )
  {
    super.paint( g );
    g.setColor( new Color(212,208,200) );
    g.fillRect( 0, 0, getSize().width, getSize().height );
  }
 }

class Frame3_jMenuDeleteNode_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuDeleteNode_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuDeleteNode_actionPerformed(e);
  }
}

class MyJTree extends JTree {

  public MyJTree(TreeModel newModel) {
    super(newModel);
  }

  public MyJTree() {
    super();
  }



  public String convertValueToText(Object value,
                                 boolean selected,
                                 boolean expanded,
                                 boolean leaf,
                                 int row,
                                 boolean hasFocus) {
    super.convertValueToText(value,selected,expanded,leaf,row,hasFocus);
    if (!(value instanceof Node)) return null;
    return Frame3.DisplayNode((Node)value);
  }

}

class Frame3_jTabbedPane1_propertyChangeAdapter implements java.beans.PropertyChangeListener {
  Frame3 adaptee;

  Frame3_jTabbedPane1_propertyChangeAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void propertyChange(PropertyChangeEvent e) {
    adaptee.jTabbedPane1_propertyChange(e);
  }
}

class Frame3_jTabbedPane1_changeAdapter implements javax.swing.event.ChangeListener {
  Frame3 adaptee;

  Frame3_jTabbedPane1_changeAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void stateChanged(ChangeEvent e) {
    adaptee.jTabbedPane1_stateChanged(e);
  }
}

class Frame3_errorSel_listSelectionAdapter implements javax.swing.event.ListSelectionListener {
  Frame3 adaptee;

  Frame3_errorSel_listSelectionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void valueChanged(ListSelectionEvent e) {
    adaptee.errorSel_valueChanged(e);
  }
}

class Frame3_jMenuItem9_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem9_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem9_actionPerformed(e);
  }
}


class Frame3_jNewFromItem_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jNewFromItem_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jNewFromItem_actionPerformed(e);
  }
}

class Frame3_jMenuBefore_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuBefore_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuBefore_actionPerformed(e);
  }
}

class Frame3_jMenuItem8_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem8_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem8_actionPerformed(e);
  }
}

class Frame3_jMenuNewFrom_menuAdapter implements javax.swing.event.MenuListener {
  Frame3 adaptee;

  Frame3_jMenuNewFrom_menuAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void menuSelected(MenuEvent e) {
    adaptee.jMenuNewFrom_menuSelected(e);
  }
  public void menuDeselected(MenuEvent e) {
  }
  public void menuCanceled(MenuEvent e) {
  }
}

class Frame3_jMenuItem10_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem10_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem10_actionPerformed(e);
  }
}

class Frame3_jButton3_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton3_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class Frame3_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton1_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class Frame3_jButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class Frame3_jButtonAddBefore_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButtonAddBefore_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButtonAddBefore_actionPerformed(e);
  }
}

class Frame3_jButtonAddAfter_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButtonAddAfter_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButtonAddAfter_actionPerformed(e);
  }
}

class Frame3_jButton9_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton9_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton9_actionPerformed(e);
  }
}

class Frame3_jButtonAddAttr_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButtonAddAttr_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButtonAddAttr_actionPerformed(e);
  }
}

class Frame3_document1_documentAdapter implements javax.swing.event.DocumentListener {
  Frame3 adaptee;

  Frame3_document1_documentAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void insertUpdate(DocumentEvent documentEvent) {
    adaptee.document1_changedUpdate(documentEvent);
  }
  public void removeUpdate(DocumentEvent documentEvent) {
    adaptee.document1_changedUpdate(documentEvent);
  }
  public void changedUpdate(DocumentEvent documentEvent) {
    adaptee.document1_changedUpdate(documentEvent);
  }
}

class Frame3_jButtonAddAttr2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButtonAddAttr2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButtonAddAttr_actionPerformed(e);
  }
}

class Frame3_jButtonDeleteAttr_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButtonDeleteAttr_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButtonDeleteAttr_actionPerformed(e);
  }
}

class Frame3_jMenuDeleteAttribute_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuDeleteAttribute_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButtonDeleteAttr_actionPerformed(e);
  }
}

class Frame3_jButton12_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton12_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton12_actionPerformed(e);
  }
}

class Frame3_jMenuItem11_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem11_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem11_actionPerformed(e);
  }
}

class Frame3_jMenuItemUndo_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItemUndo_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItemUndo_actionPerformed(e);
  }
}

class Frame3_jMenuItemRedo_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItemRedo_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItemRedo_actionPerformed(e);
  }
}

class Frame3_jTextXML_inputMethodAdapter implements java.awt.event.InputMethodListener {
  Frame3 adaptee;

  Frame3_jTextXML_inputMethodAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void inputMethodTextChanged(InputMethodEvent e) {
  }
  public void caretPositionChanged(InputMethodEvent e) {
    adaptee.jTextXML_caretPositionChanged(e);
  }
}

class Frame3_jTextXML_mouseAdapter extends java.awt.event.MouseAdapter {
  Frame3 adaptee;

  Frame3_jTextXML_mouseAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.jTextXML_mouseClicked(e);
  }
}

class Frame3_document2_documentAdapter implements javax.swing.event.DocumentListener {
  Frame3 adaptee;

  Frame3_document2_documentAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void insertUpdate(DocumentEvent documentEvent) {
    adaptee.document2_changedUpdate(documentEvent);
  }
  public void removeUpdate(DocumentEvent documentEvent) {
    adaptee.document2_changedUpdate(documentEvent);
  }
  public void changedUpdate(DocumentEvent documentEvent) {
    adaptee.document2_changedUpdate(documentEvent);
  }
}

class Frame3_jMenuItem5_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem5_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem5_actionPerformed(e);
  }
}

class Frame3_jButton13_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton13_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton13_actionPerformed(e);
  }
}

class Frame3_attrSel_listSelectionAdapter implements javax.swing.event.ListSelectionListener {
  Frame3 adaptee;

  Frame3_attrSel_listSelectionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void valueChanged(ListSelectionEvent e) {
    adaptee.attrSel_valueChanged(e);
  }
}

class Frame3_jMenuItem13_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem13_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem13_actionPerformed(e);
  }
}

class Frame3_jList1_listSelectionAdapter implements javax.swing.event.ListSelectionListener {
  Frame3 adaptee;

  Frame3_jList1_listSelectionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void valueChanged(ListSelectionEvent e) {
    adaptee.jList1_valueChanged(e);
  }
}

class Frame3_jList1_mouseAdapter extends java.awt.event.MouseAdapter {
  Frame3 adaptee;

  Frame3_jList1_mouseAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.jList1_mouseReleased(e);
  }
}



class Frame3_jMenuItem14_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem14_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem14_actionPerformed(e);
  }
}

class Frame3_jMenuItem15_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem15_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem15_actionPerformed(e);
  }
}

class Frame3_jMenuItem115_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem115_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem115_actionPerformed(e);
  }
}


class Frame3_jMenuItem116_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem116_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem116_actionPerformed(e);
  }
}

class Frame3_jMenuItem4_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jMenuItem4_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem4_actionPerformed(e);
  }
}

class Frame3_menuItem1_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_menuItem1_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.menuItem1_actionPerformed(e);
  }
}

class Frame3_jTable2_mouseAdapter extends java.awt.event.MouseAdapter {
  Frame3 adaptee;

  Frame3_jTable2_mouseAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.jTable2_mouseReleased(e);
  }
}

class Frame3_m_tree_mouseAdapter extends java.awt.event.MouseAdapter {
  Frame3 adaptee;

  Frame3_m_tree_mouseAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.m_tree_mouseReleased(e);
  }
}

class Frame3_jMenu1_menuAdapter implements javax.swing.event.MenuListener {
  Frame3 adaptee;

  Frame3_jMenu1_menuAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void menuSelected(MenuEvent e) {
    adaptee.jMenu1_menuSelected(e);
  }
  public void menuDeselected(MenuEvent e) {
  }
  public void menuCanceled(MenuEvent e) {
  }
}

class Frame3_jMenuElement_menuAdapter implements javax.swing.event.MenuListener {
  Frame3 adaptee;

  Frame3_jMenuElement_menuAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void menuSelected(MenuEvent e) {
    adaptee.jMenuElement_menuSelected(e);
  }
  public void menuDeselected(MenuEvent e) {
  }
  public void menuCanceled(MenuEvent e) {
  }
}

class Frame3_m_tree_keyAdapter extends java.awt.event.KeyAdapter {
  Frame3 adaptee;

  Frame3_m_tree_keyAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void keyReleased(KeyEvent e) {
    adaptee.m_tree_keyReleased(e);
  }
}

class Frame3_jTable1_keyAdapter extends java.awt.event.KeyAdapter {
  Frame3 adaptee;

  Frame3_jTable1_keyAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void keyReleased(KeyEvent e) {
    adaptee.jTable1_keyReleased(e);
  }
}

/**
 *  The DOMParserSaveEncoding class extends DOMParser. It also provides
 *  the Java Encoding of the XML document by overriding the startDocument method
 *  and providing a way to capture the MIME encoding from the XML document which
 *  in turn is converted to the Java Encoding by the internal MIME2Java class.
 *
 */

