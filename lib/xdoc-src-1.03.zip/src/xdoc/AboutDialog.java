/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

import java.awt.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class AboutDialog extends JDialog {
  JPanel jPanel1 = new JPanel();
  JLabel label2 = new JLabel();
  JLabel label4 = new JLabel();
  JLabel label1 = new JLabel();
  JLabel label3 = new JLabel();
  JLabel imageControl1 = new JLabel();
  JLabel label5 = new JLabel();
  JLabel label6 = new JLabel();


  public AboutDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public AboutDialog(Frame parent) {
    this(parent, "", false);
  }


  private void jbInit() throws Exception {
    this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    this.setFont(new java.awt.Font("Dialog", 0, 12));
    this.setModal(true);
    this.setResizable(false);
    this.setTitle("");
    jPanel1.setLayout(null);
    label2.setAlignmentY((float) 0.5);
    label2.setToolTipText("");
    label2.setText("Version 1.03");
    label2.setBounds(new Rectangle(3, 124, 153, 15));
    label4.setText("A schema-aware XML editor; http://xdoc.sourceforge.net");
    label4.setBounds(new Rectangle(3, 154, 320, 15));
    label1.setText("XDoc");
    label1.setBounds(new Rectangle(3, 109, 153, 15));
    label3.setText("Copyright (c) 2004-2005");
    label3.setBounds(new Rectangle(3, 139, 153, 15));
    jPanel1.setAlignmentY((float) 0.5);
    jPanel1.setMinimumSize(new Dimension(500, 171));
    jPanel1.setOpaque(true);
    jPanel1.setPreferredSize(new Dimension(512, 203));
    jPanel1.setRequestFocusEnabled(true);
    imageControl1.setDebugGraphicsOptions(0);
    imageControl1.setMaximumSize(new Dimension(1295, 171));
    imageControl1.setToolTipText("");
    imageControl1.setDisplayedMnemonic('0');
    imageControl1.setHorizontalTextPosition(SwingConstants.TRAILING);
    imageControl1.setIcon(new ImageIcon(Frame3.Expand(this,"bg_top.gif")));
    imageControl1.setIconTextGap(4);
    imageControl1.setBounds(new Rectangle(0, 0, 1295, 171));
    label5.setBounds(new Rectangle(3, 172, 358, 15));
    label5.setText("Programmer: cand. Inform. Jörg Kiegeland");
    label5.setToolTipText("");
    label5.setAlignmentY((float) 0.5);
    label6.setAlignmentY((float) 0.5);
    label6.setToolTipText("");
    label6.setText("Supervisor: Dipl.-Inform. C. Werner; Prof. Dr. S. Fischer");
    label6.setBounds(new Rectangle(3, 187, 405, 15));
    jPanel1.add(label2, null);
    jPanel1.add(label1, null);
    jPanel1.add(label4, null);
    jPanel1.add(label3, null);
    jPanel1.add(label6, null);
    jPanel1.add(label5, null);
    jPanel1.add(imageControl1, null);
    this.getContentPane().add(jPanel1);
  }

}
