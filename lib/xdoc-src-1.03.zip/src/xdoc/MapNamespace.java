/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;
import javax.swing.*;

import org.apache.xerces.impl.*;

public class MapNamespace {

  protected String Desc;
  protected String Namespace;
  protected String Location;
  protected String Root;

  public String toString() {
    if (!Desc.equals(""))
      return Desc; else
      return Namespace;
  }

  public MapNamespace() {
    super();
  }

  public MapNamespace(String Desc,String Namespace,String Location,String Root) {
    super();
    this.setDesc(Desc);
    this.setNamespace(Namespace);
    this.setLiteralSystemID(Location);
    this.setRoot(Root);
  }


  public String getDesc() {
    return Desc;
  }

  public String getNamespace() {
    return Namespace;
  }

  public boolean hasNoNamespace() {
    return Namespace.equals("");
  }

  public boolean isDTD() {
    return Location.toLowerCase().endsWith(".dtd");
  }


  public String getLiteralSystemID() {
    return Location;
  }

  public String getExpandedSystemId() {
    try {
      String s= XMLEntityManager.expandSystemId(Location,
                                             /*System.getProperty("user.dir") +
                                             "/"*/null, false);
      //JOptionPane.showMessageDialog(null, s,Location,JOptionPane.WARNING_MESSAGE);
      return s;

    }
    catch (Exception e) {
      return "";
    }
  }

  public String getRoot() {
    return Root;
  }

  public void setDesc(String s) {
    Desc=s;
  }

  public void setNamespace(String s) {
    Namespace=s;
  }

  public void setLiteralSystemID(String s) {
    Location=s.replace('\\','/');
  }

  public void setRoot(String s) {
    Root=s;
  }

  public boolean hasLocation() {
    return !Location.equals("");
  }

  public boolean hasDesc() {
    return !Desc.equals("");
  }

  public boolean hasNamespace() {
    return !Namespace.equals("");
  }

  public boolean hasRoot() {
    return !Root.equals("");
  }




}