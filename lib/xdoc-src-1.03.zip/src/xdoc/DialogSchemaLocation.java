/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.net.URL;
import java.net.MalformedURLException;
import javax.swing.border.*;



public class DialogSchemaLocation extends JDialog {
  JPanel panel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JButton jButton1 = new JButton();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JLabel jLabel3 = new JLabel();
  boolean OkPressed=false;
  JLabel jLabel5 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  Border border1;

  public DialogSchemaLocation(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DialogSchemaLocation(Frame parent) {
    this(parent, "", true);
  }
  private void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder();
    panel1.setLayout(null);
    jLabel1.setForeground(Color.black);
    jLabel1.setRequestFocusEnabled(true);
    jLabel1.setHorizontalTextPosition(SwingConstants.TRAILING);
    jLabel1.setText("<html>Please enter the schema location for namespace</html>");
    jLabel1.setBounds(new Rectangle(13, 12, 365, 17));
    jButton1.setBounds(new Rectangle(298, 46, 21, 20));
    jButton1.setText("...");
    jButton1.addActionListener(new DialogSchemaLocation_jButton1_actionAdapter(this));
    jTextField1.setText("");
    jTextField1.setBounds(new Rectangle(13, 46, 284, 21));
    jTextField1.addKeyListener(new DialogSchemaLocation_jTextField1_keyAdapter(this));
    jLabel2.setBounds(new Rectangle(13, 77, 314, 58));
    jLabel2.setText("<html>You can provide an optional label for this schema mapping, " +
    "<<br>which is displayed in the menu for creating new instances for " +
    "a given namespace:</html>");
    jLabel2.setRequestFocusEnabled(true);
    jLabel2.setToolTipText("");
    jLabel2.setForeground(Color.black);
    jTextField2.setText("");
    jTextField2.setBounds(new Rectangle(13, 144, 138, 21));
    jTextField2.addKeyListener(new DialogSchemaLocation_jTextField2_keyAdapter(this));
    panel1.setMinimumSize(new Dimension(1, 1));
    panel1.setNextFocusableComponent(jTextField1);
    panel1.setPreferredSize(new Dimension(433, 340));
    panel1.setBounds(new Rectangle(0, 0, 357, 281));
    panel1.addComponentListener(new DialogSchemaLocation_panel1_componentAdapter(this));
    panel1.addKeyListener(new DialogSchemaLocation_panel1_keyAdapter(this));
    jButton2.setBounds(new Rectangle(13, 227, 73, 25));
    jButton2.setText("OK");
    jButton2.addActionListener(new DialogSchemaLocation_jButton2_actionAdapter(this));
    jButton3.setBounds(new Rectangle(102, 227, 89, 25));
    jButton3.setBorderPainted(true);
    jButton3.setText("Cancel");
    jButton3.addActionListener(new DialogSchemaLocation_jButton3_actionAdapter(this));
    jLabel3.setText("<html>If you press <<b>OK<</b> and defined no schema file, you will " +
    "not again be asked to provide a schema location for this namespace. " +
    "You can do so manually in the <<b>Options<</b> dialog later.</html>");
    jLabel3.setBounds(new Rectangle(13, 257, 325, 61));
    this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    this.setModal(true);
    this.setResizable(false);
    this.setTitle("");
    this.addWindowListener(new DialogSchemaLocation_this_windowAdapter(this));
    jLabel5.setForeground(Color.black);
    jLabel5.setToolTipText("");
    jLabel5.setRequestFocusEnabled(true);
    jLabel5.setText("<html>Provide an optional root element, which is used for new created " +
    "documents:</html>");
    jLabel5.setBounds(new Rectangle(12, 166, 384, 31));
    jTextField3.setBounds(new Rectangle(13, 199, 138, 21));
    jTextField3.addKeyListener(new DialogSchemaLocation_jTextField3_keyAdapter(this));
    jTextField3.setText("");
    jTextField4.setFont(new java.awt.Font("Monospaced", 0, 11));
    jTextField4.setBorder(border1);
    jTextField4.setOpaque(false);
    jTextField4.setEditable(false);
    jTextField4.setText("jTextField4");
    jTextField4.setBounds(new Rectangle(14, 25, 379, 21));
    panel1.add(jTextField1, null);
    panel1.add(jLabel1, null);
    panel1.add(jButton1, null);
    panel1.add(jTextField2, null);
    panel1.add(jLabel5, null);
    panel1.add(jLabel2, null);
    panel1.add(jTextField3, null);
    panel1.add(jButton2, null);
    panel1.add(jButton3, null);
    panel1.add(jLabel3, null);
    panel1.add(jTextField4, null);
    this.getContentPane().add(panel1, null);
   //jTextField1.requestFocus(true);

  }

  static boolean DialogCanceled=false;

  static public MapNamespace getNewMappingFor(String ns, Frame parent) {
    if (DialogCanceled)
      return null;
    DialogSchemaLocation dlg = new DialogSchemaLocation(parent);
    dlg.setLocationRelativeTo(parent);
    dlg.jTextField4.setText(ns);
    dlg.show();
    if (dlg.OkPressed) {
      MapNamespace map=new MapNamespace(dlg.jTextField2.getText(),ns,dlg.jTextField1.getText(),dlg.jTextField3.getText());
      ConfigureNamespacesDialog.MapNamespaces.addElement(map);
      return map;
    } else {
      DialogCanceled=true;
      return null;
    }
//    MapNamespaces.add(new MapNamespace());

  }

  void jButton1_actionPerformed(ActionEvent e) {
    if (JFileChooser.APPROVE_OPTION == Frame3.jSchemaChooser.showOpenDialog(this))
      jTextField1.setText(Frame3.jSchemaChooser.getSelectedFile().getPath());
  }

  void jButton2_actionPerformed(ActionEvent e) {
    OkPressed=true;
    dispose();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    dispose();
  }

  void panel1_keyPressed(KeyEvent e) {
  }

  void jTextField1_keyPressed(KeyEvent e) {
    if (e.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
      jButton3_actionPerformed(null);
  }

  void panel1_componentShown(ComponentEvent e) {
   jTextField1.requestFocus(true);
  }

  void this_windowOpened(WindowEvent e) {
   jTextField1.requestFocus(true);
  }
}

class DialogSchemaLocation_jButton1_actionAdapter implements java.awt.event.ActionListener {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_jButton1_actionAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class DialogSchemaLocation_jButton2_actionAdapter implements java.awt.event.ActionListener {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_jButton2_actionAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class DialogSchemaLocation_jButton3_actionAdapter implements java.awt.event.ActionListener {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_jButton3_actionAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class DialogSchemaLocation_panel1_keyAdapter extends java.awt.event.KeyAdapter {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_panel1_keyAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.panel1_keyPressed(e);
  }
}

class DialogSchemaLocation_jTextField1_keyAdapter extends java.awt.event.KeyAdapter {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_jTextField1_keyAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jTextField1_keyPressed(e);
  }
}

class DialogSchemaLocation_jTextField2_keyAdapter extends java.awt.event.KeyAdapter {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_jTextField2_keyAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jTextField1_keyPressed(e);
  }
}

class DialogSchemaLocation_jTextField3_keyAdapter extends java.awt.event.KeyAdapter {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_jTextField3_keyAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void keyReleased(KeyEvent e) {
    adaptee.jTextField1_keyPressed(e);
  }
}

class DialogSchemaLocation_panel1_componentAdapter extends java.awt.event.ComponentAdapter {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_panel1_componentAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void componentShown(ComponentEvent e) {
    adaptee.panel1_componentShown(e);
  }
}

class DialogSchemaLocation_this_windowAdapter extends java.awt.event.WindowAdapter {
  DialogSchemaLocation adaptee;

  DialogSchemaLocation_this_windowAdapter(DialogSchemaLocation adaptee) {
    this.adaptee = adaptee;
  }
  public void windowOpened(WindowEvent e) {
    adaptee.this_windowOpened(e);
  }
}
