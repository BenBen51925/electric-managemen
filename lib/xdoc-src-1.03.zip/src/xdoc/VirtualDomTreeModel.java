/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;


import java.util.*;

import javax.swing.event.*;
import javax.swing.tree.*;

import org.w3c.dom.*;
public class VirtualDomTreeModel implements TreeModel {

  private Vector treeModelListeners = new Vector();

  Node root;
  public VirtualDomTreeModel() {
    //this.root=root;
  }

  public synchronized void setRoot(Node root) {
    //note that document!=null must be valid or else an exception is thrown
    this.root = root;
    fireTreeStructureChanged(root);
  }


  public Node getNode(Object ob) {
      return (Node)ob;
  }





  static public Vector GetChildrenNodes(Node node) {
    Vector v=new Vector();
    if (node==null) return v;
    node=node.getFirstChild();
    while (node!=null) {
      if (node instanceof Element)
        v.add(node);
      node=node.getNextSibling();
    }
    return v;
  }

  public Object getRoot() {
    return root;
  }

  public Object getChild(Object parm1, int parm2) {
    return GetChildrenNodes((Node)parm1).get(parm2);
  }

  public int getChildCount(Object parm1) {
    return GetChildrenNodes((Node)parm1).size();
  }

  public boolean isLeaf(Object parm1) {
    return GetChildrenNodes((Node)parm1).size()==0;
  }

  public void valueForPathChanged(TreePath parm1, Object parm2) {
    /**@todo Implement this javax.swing.tree.TreeModel method*/
    throw new java.lang.UnsupportedOperationException("Method valueForPathChanged() not yet implemented.");
  }

  public int getIndexOfChild(Object parm1, Object parm2) {
    if (parm1==null || parm2==null) return -1;
    return GetChildrenNodes((Node)parm1).indexOf(parm2);
  }

  public void addTreeModelListener(TreeModelListener parm1) {
    treeModelListeners.addElement(parm1);
  }

  public void removeTreeModelListener(TreeModelListener parm1) {
    treeModelListeners.removeElement(parm1);
  }

  protected void fireTreeStructureChanged(Object ob) {
        int len = treeModelListeners.size();
        TreeModelEvent e = new TreeModelEvent(this,
                                              new Object[] {ob});
        for (int i = 0; i < len; i++) {
            ((TreeModelListener)treeModelListeners.elementAt(i)).
                    treeStructureChanged(e);
        }
    }


}