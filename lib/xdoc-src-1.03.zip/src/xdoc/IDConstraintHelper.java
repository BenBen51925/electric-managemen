/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.*;
import org.apache.xerces.dom.*;
import org.apache.xerces.impl.dv.xs.*;
import org.apache.xerces.impl.xs.*;
import org.apache.xerces.impl.xs.identity.*;
import org.apache.xerces.xs.*;
import org.apache.xpath.*;
import org.w3c.dom.*;
import org.w3c.dom.traversal.*;


public class IDConstraintHelper {

  public static void AddPrefix(Element node, String PrefName, String PrefValue) {
    Attr newNode = new PSVIAttrNSImpl((CoreDocumentImpl)node.getOwnerDocument(),"http://www.w3.org/2000/xmlns/", "xmlns:"+PrefName);
    if (node.getAttributeNodeNS(newNode.getNamespaceURI(),newNode.getLocalName())!=null) return;
    newNode.setNodeValue(PrefValue);
    node.setAttributeNode(newNode);
  }

  public static String getSuitableNamespacePrefix(Element node) {
    //XSNamespaceItem n=GetNamespaceItem(node.getOwnerDocument().getDocumentElement().getNamespaceURI(),(CoreDocumentImpl)node.getOwnerDocument());
    XSModelImpl si=(XSModelImpl)((PSVIElementNSImpl)node.getOwnerDocument().getDocumentElement()).getSchemaInformation();
    XSNamespaceItemList nl=si.getNamespaceItems();
    for (int w = 0; w < nl.getLength(); w++) {
      XSNamespaceItem n = nl.item(w);
      if (n instanceof SchemaGrammar) {
        int i = XDocUtilities.FindStringInVector(node.getNamespaceURI(),
                                                 ( (SchemaGrammar) n).
                                                 CollectPrefixValues);
        if (i != -1)
          return (String) ( (SchemaGrammar) n).CollectPrefixNames.get(i);
      }
    }
    return null;
  }

  protected static XSNamespaceItem GetNamespaceItem(String ns, CoreDocumentImpl doc) {
    XSModelImpl si=(XSModelImpl)((PSVIElementNSImpl)doc.getDocumentElement()).getSchemaInformation();
    XSNamespaceItemList nl=si.getNamespaceItems();
    for (int i = 0; i < nl.getLength(); i++)
      if (nl.item(i).getSchemaNamespace().equals(ns))
        return nl.item(i);
    return null;
  }


  public static XSNamespaceItem GetNoNamespaceItem(String ExpandedSystemId, CoreDocumentImpl doc) {
    XSModelImpl si=(XSModelImpl)((PSVIElementNSImpl)doc.getDocumentElement()).getSchemaInformation();
    XSNamespaceItemList nl=si.getNamespaceItems();
    for (int i = 0; i < nl.getLength(); i++)
      if (nl.item(i) instanceof SchemaGrammar && ExpandedSystemId.equals(((SchemaGrammar)nl.item(i)).getGrammarDescription().getExpandedSystemId()))
        return nl.item(i);
    return null;
  }



  public static void AddSchemaPrefixes(SchemaGrammar n, Element node){
    for (int i=0; i<n.CollectPrefixNames.size(); i++) {
      AddPrefix(node,(String)n.CollectPrefixNames.get(i),(String)n.CollectPrefixValues.get(i));
/*      Attr newNode = new PSVIAttrNSImpl((CoreDocumentImpl)node.getOwnerDocument(),"http://www.w3.org/2000/xmlns/", "xmlns:"+(String)n.CollectPrefixNames.get(i));
      newNode.setNodeValue((String)n.CollectPrefixValues.get(i));
      node.setAttributeNode(newNode);*/
    }
  }

  protected static Node BuildNamespaceNode(Element node) {
    //XSNamespaceItem n=GetNamespaceItem(pnode.getNamespaceURI(),(CoreDocumentImpl)pnode.getOwnerDocument());
    Element nameSpaceNode = node.getOwnerDocument().createElement("NameSpace");
    XSModelImpl si=(XSModelImpl)((PSVIElementNSImpl)node.getOwnerDocument().getDocumentElement()).getSchemaInformation();
    XSNamespaceItemList nl=si.getNamespaceItems();
    for (int w = 0; w < nl.getLength(); w++) {
      XSNamespaceItem n = nl.item(w);
      if (n instanceof SchemaGrammar)
        AddSchemaPrefixes( (SchemaGrammar) n, nameSpaceNode);
      /*else
        nameSpaceNode = pnode;*/
    }
    return nameSpaceNode;
  }

  //Collects valid values for the "fieldIndex"th field of "keyref" of nodes identified by "key".
  //"keyref_context" is the element which contains the attribute for which values shall be collected
  //"key_context": in the declaration of this element the "key" declaration <key> is declared,
  //so XPath expressions in "key" refer to this context element.
  //This method can work in the other direction, too ("reverse"), so to collect all nodes referencing a key node;
  //in this case ("reverse"==true), "keyref" is actually a <key> and "key" is actually a <keyref>!
  protected static void CollectKeyValues(IdentityConstraint keyref,IdentityConstraint key,Node keyref_context,Node key_context,boolean reverse,Vector v,int fieldIndex,Node attr) {

    try {
      if (keyref.getFieldCount() != key.getFieldCount()) return;

      String xpath = "(" + key.getSelectorStr() + ")";
      for (int fieldIndex2 = 0; fieldIndex2 < key.getFieldCount(); fieldIndex2++)
        if (fieldIndex2 != fieldIndex || reverse) {
          String xpath2 = keyref.getFieldStrs().item(fieldIndex2);
          NodeIterator nl = XPathAPI.selectNodeIterator(keyref_context, xpath2,
              BuildNamespaceNode( (Element) keyref_context));
          NodeImpl n = (NodeImpl) nl.nextNode();
          if (n != null && ! ("").equals(n.getTextContent()))
            xpath = xpath + "[" + key.getFieldStrs().item(fieldIndex2) + "=" + "\"" +
                n.getTextContent() + "\"" + "]";
        }
      xpath = xpath + "/" + key.getFieldStrs().item(fieldIndex);
      NodeIterator nl = XPathAPI.selectNodeIterator(key_context, xpath,
                                                    BuildNamespaceNode( (Element)
          key_context));
      Node n;
      while ( (n = nl.nextNode()) != null)
      if (!(reverse && !IDConstraintHelper.getValidKeys(n).contains(attr))) //check if node is already bound by another keyref
        v.add(n);
    }
    catch (Exception e) {
    }
  }

  public static Vector getValidKeys(Node attr) {
    Node pnode=IDConstraintHelper.getOwnerElement((NodeImpl)attr);
    Vector v=new Vector();
    Vector ParentOfIC=new Vector();
    Field field=getIDConstraint(pnode,attr,true,ParentOfIC);
    if (field!=null) {
      IdentityConstraint keyref = field.getIdentityConstraint();
      int fieldIndex = 0;
      while (keyref.getFieldAt(fieldIndex) != field) fieldIndex++;
      IdentityConstraint key=(IdentityConstraint) keyref.getRefKey();
      CollectKeyValues(keyref, key, pnode,
                       GetElementWithIDConstraint( (Node) ParentOfIC.
                                                  firstElement(), key), false, v,
                       fieldIndex,attr);
    }
    return v;
  }

  public static NodeImpl getOwnerElement(NodeImpl node) {
    if (node instanceof AttrImpl)
      return (NodeImpl)((AttrImpl)node).getOwnerElement(); else
      return node;
  }

  public static boolean isKeyBound(NodeImpl attr) {
    return getIDConstraint(getOwnerElement(attr), attr, true, new Vector()) != null;
  }

  public static Vector getIDListeners(NodeImpl attr) {
    Node pnode=getOwnerElement(attr);
    Vector v=new Vector();
    Field field=getIDConstraint(pnode,attr,false,new Vector());
    if (field!=null && !attr.getTextContent().equals("")) {
      IdentityConstraint key = field.getIdentityConstraint();
      int fieldIndex = 0;
      while (key.getFieldAt(fieldIndex) != field) fieldIndex++;
      for (Node ppnode=pnode; ppnode instanceof PSVIElementNSImpl; ppnode = ppnode.getParentNode()) {
        XSElementDeclaration d = ( (PSVIElementNSImpl) ppnode).
            getElementDeclaration();
        XSNamedMap idcs = d.getIdentityConstraints();
        for (int i = 0; i < idcs.getLength(); i++) {
          IdentityConstraint keyref = (IdentityConstraint) idcs.item(i);
          if (keyref.getRefKey() != key) continue;
          CollectKeyValues(key, keyref, pnode, ppnode, true, v,
                           fieldIndex,attr);
        }
      }
    }
    return v;
  }

  protected static Node GetElementWithIDConstraint(Node pnode,XSIDCDefinition key) {
    if (!(pnode instanceof PSVIElementNSImpl)) return null;
    XSElementDeclaration d = ( (PSVIElementNSImpl) pnode).getElementDeclaration();
    XSNamedMap idcs = d.getIdentityConstraints();
    for (int i = 0; i < idcs.getLength(); i++)
      if (idcs.item(i)==key)
        return pnode;
    for (Node cnode=pnode.getFirstChild(); cnode!=null; cnode=cnode.getNextSibling())
      if ((pnode=GetElementWithIDConstraint(cnode,key))!=null)
        return pnode;
    return null;
  }


  protected static Field getIDConstraint(Node pnode, Node attr,boolean keyref, Vector ParentOfIC) {
    try {
      for (; pnode instanceof PSVIElementNSImpl; pnode = pnode.getParentNode()) {
        XSElementDeclaration d = ( (PSVIElementNSImpl) pnode).
            getElementDeclaration();
        if (d==null) return null;
        XSNamedMap idcs = d.getIdentityConstraints();
        for (int i = 0; i < idcs.getLength(); i++) {
          IdentityConstraint ic = (IdentityConstraint) idcs.item(i);
          if ((ic.getCategory()==XSIDCDefinition.IC_KEYREF)!=keyref)
            continue;
          for (int fieldIndex=0; fieldIndex<ic.getFieldCount(); fieldIndex++) {
            String xpath = "(" + ic.getSelectorStr() + ")/" +
                ic.getFieldAt(fieldIndex).getXPath();
            NodeIterator nl = XPathAPI.selectNodeIterator(pnode, xpath,
                BuildNamespaceNode( (Element) pnode));
            Node n;
            while ( (n = nl.nextNode()) != null)
              if (n == attr) {
                ParentOfIC.add(pnode);
                return ic.getFieldAt(fieldIndex);
              }
          }
        }
      }
    } catch (Exception e){
    }
    return null;
  }


  protected static void CollectIDs(Node node,Vector v) {
    NamedNodeMap attrs=node.getAttributes();
    if (attrs!=null)
    for (int i=0; i<attrs.getLength(); i++)
      if (attrs.item(i) instanceof PSVIAttrNSImpl) {
        PSVIAttrNSImpl attr = (PSVIAttrNSImpl) attrs.item(i);
        if (attr.getAttributeDeclaration()!=null && ((XSSimpleTypeDecl)attr.getAttributeDeclaration().getTypeDefinition()).isIDType())
        //if (attr.getAttributeDeclaration()!=null && AllowsValueOfType(attr.getAttributeDeclaration().getTypeDefinition(),"ID"))
          v.add(attr);
      }
    for (node=node.getFirstChild(); node!=null; node=node.getNextSibling())
      CollectIDs(node,v);
  }



  public static XSSimpleTypeDefinition getST(NodeImpl node) {
    if (node instanceof PSVIAttrNSImpl && ((PSVIAttrNSImpl)node).getAttributeDeclaration()!=null)
      return ((PSVIAttrNSImpl)node).getAttributeDeclaration().getTypeDefinition(); else
    if (node instanceof PSVIElementNSImpl && ((PSVIElementNSImpl)node).getElementDeclaration()!=null)
      return getST(((PSVIElementNSImpl)node).getElementDeclaration()); else
      return null;
  }



  public static XSSimpleTypeDefinition getST(XSElementDeclaration decl) {
      if (decl.getTypeDefinition() instanceof XSSimpleTypeDefinition)
        return (XSSimpleTypeDefinition)decl.getTypeDefinition(); else
      if (decl.getTypeDefinition() instanceof XSComplexTypeDefinition)
        return ((XSComplexTypeDefinition)decl.getTypeDefinition()).getSimpleType(); else
        return null;
  }


  public static Vector getPossibleReferences(NodeImpl attr) {
    if (IDConstraintHelper.isKeyBound(attr))
      return IDConstraintHelper.getValidKeys(attr);
    if (getST(attr)!=null && XDocUtilities.AllowsValueOfType(getST(attr),"IDREF")) {
      Vector v=new Vector();
      CollectIDs(attr.getOwnerDocument(),v);
      return v;
    }
    return new Vector();
  }

}
