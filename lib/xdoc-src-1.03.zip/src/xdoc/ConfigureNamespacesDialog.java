/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

import java.awt.*;
import javax.swing.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;

import java.awt.Dimension;
import java.awt.Color;

import java.awt.*;
import java.util.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ConfigureNamespacesDialog extends JDialog {
  JPanel panel1 = new JPanel();

  static public Vector MapNamespaces=new Vector();

  public ConfigureNamespacesDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ConfigureNamespacesDialog(Frame parent) {
    this(parent, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jButton1.setBounds(new Rectangle(16, 170, 73, 25));
    jButton1.setText("Add");
    jButton1.addActionListener(new ConfigureNamespacesDialog_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(89, 170, 73, 25));
    jButton2.setText("Delete");
    jButton2.addActionListener(new ConfigureNamespacesDialog_jButton2_actionAdapter(this));
    jButton3.setBounds(new Rectangle(162, 170, 99, 25));
    jButton3.setText("Move up");
    jButton3.addActionListener(new ConfigureNamespacesDialog_jButton3_actionAdapter(this));
    jButton4.setBounds(new Rectangle(261, 170, 113, 25));
    jButton4.setText("Move down");
    jButton4.addActionListener(new ConfigureNamespacesDialog_jButton4_actionAdapter(this));
    this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    this.setModal(true);
    this.setResizable(false);
    this.setTitle("Namespaces");
    this.addWindowListener(new ConfigureNamespacesDialog_this_windowAdapter(this));
    panel1.setMinimumSize(new Dimension(1, 1));
    panel1.setOpaque(true);
    panel1.setPreferredSize(new Dimension(745, 230));
    panel1.setRequestFocusEnabled(true);
    jButton5.setBounds(new Rectangle(16, 199, 73, 25));
    jButton5.setText("Close");
    jButton5.addKeyListener(new ConfigureNamespacesDialog_jButton5_keyAdapter(this));
    jButton5.addActionListener(new ConfigureNamespacesDialog_jButton5_actionAdapter(this));
    jScrollPane1.setBounds(new Rectangle(5, 57, 735, 108));
    jTable1.setAutoCreateColumnsFromModel(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);

    jTable1.setModel(dataModel);
    jTable1.addColumn(new TableColumn(0));
    jTable1.addColumn(new TableColumn(1));
    jTable1.addColumn(new TableColumn(2));
    jTable1.addColumn(new TableColumn(3));
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(120);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(120);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(10);


    jLabel3.setText("<html>A xml document  can belong to a <<b>namespace<</b>, so that " +
    "it has to satisfy the namespace\'s <<b>schema<</b> rules to be valid. " +
    "If the schema file is not already given by the <<i>schemaLocation<</i> " +
    "attribute in the root element, you can now connect the namespace " +
    "with a schema file (a description and a default root element  is " +
    "optional):</html>");
    jLabel3.setBounds(new Rectangle(6, 0, 714, 61));
    getContentPane().add(panel1);
    panel1.add(jLabel3, null);
    panel1.add(jButton2, null);
    panel1.add(jButton3, null);
    panel1.add(jScrollPane1, null);
    panel1.add(jButton1, null);
    panel1.add(jButton5, null);
    panel1.add(jButton4, null);
    jScrollPane1.getViewport().add(jTable1, null);
    /*
    //getRootPane().setDefaultButton(jButton5);
    String actionName = "Cancel";
        Action closeAction = new AbstractAction(actionName) {
          public void actionPerformed(ActionEvent e) {
            jButton5.doClick();
          }
        };
        KeyStroke stroke=KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,0);
        getLayeredPane().getActionMap().put(actionName,closeAction);


    getRootPane().getInputMap().put(
            stroke,
            actionName);*/

  }


  TableModel dataModel = new AbstractTableModel() {
      // These methods always need to be implemented.
      public int getColumnCount() { return 3; }
      public String getColumnName(int columnIndex) { return new String[] {"Description","Namespace URI","Schema Location","Root"} [columnIndex]; }
      public int getRowCount() { return MapNamespaces.size();}
      public Object getValueAt(int row, int col) {
        MapNamespace map=(MapNamespace)MapNamespaces.get(row);
        switch (col) {
          case 0: return map.getDesc();
          case 1: return map.getNamespace();
          case 2: return map.getLiteralSystemID();
          case 3: return map.getRoot();
        }
        return "invalid";
      }

      public boolean isCellEditable(int row, int col) {return true;}

      public void setValueAt(Object aValue, int row, int column) {
        String s=(String)aValue;
        MapNamespace map=(MapNamespace)MapNamespaces.get(row);
        switch (column) {
          case 0: map.setDesc(s); break;
          case 1: map.setNamespace(s); break;
          case 2: map.setLiteralSystemID(s); break;
          case 3: map.setRoot(s); break;
        }
      }
   };
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable();
  JLabel jLabel3 = new JLabel();

  void jButton1_actionPerformed(ActionEvent e) {
    String ns=JOptionPane.showInputDialog(this,"Enter a unique namespace URI:",
        "Create namespace mapping", JOptionPane.QUESTION_MESSAGE);
    DialogSchemaLocation.DialogCanceled=false;
    if (ns!=null && DialogSchemaLocation.getNewMappingFor(ns,(Frame)this.getParent())!=null)
      UpdateTable(jTable1.getRowCount()-1);
  }

  static public MapNamespace getMappingFor(String ns) {
    if (ns!=null && !ns.equals(""))
    for (int i=0; i<MapNamespaces.size(); i++) {
      MapNamespace map=(MapNamespace)MapNamespaces.get(i);
      if (map.getNamespace().equals(ns))
        return map;
    }
    return null;
  }

  static public Vector getNamespaces() {
    Vector v=new Vector();
    for (int i=0; i<MapNamespaces.size(); i++) {
      MapNamespace map=(MapNamespace)MapNamespaces.get(i);
      if (!map.getNamespace().equals(""))
        v.add(map.getNamespace());
    }
    return XDocUtilities.UniqueStringVector(v);
  }

  void jButton2_actionPerformed(ActionEvent e) {
    int sel=jTable1.getSelectedRow();
    if (sel>=0) {
      MapNamespaces.remove(sel);
      UpdateTable(sel);
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    int sel=jTable1.getSelectedRow();
    if (sel-1>=0) {
      MapNamespaces.insertElementAt(MapNamespaces.remove(sel),sel-1);
      UpdateTable(sel-1);
    }
  }

  void jButton4_actionPerformed(ActionEvent e) {
    int sel=jTable1.getSelectedRow();
    if (sel>=0 && sel+1<=MapNamespaces.size()-1) {
      MapNamespaces.insertElementAt(MapNamespaces.remove(sel),sel+1);
      UpdateTable(sel+1);
    }
  }

  void jButton5_actionPerformed(ActionEvent e) {
    this.dispose();
  }
  public static void DoUpdateTable(JTable table,int sel) {
    ( (AbstractTableModel) table.getModel()).fireTableStructureChanged();
    if (sel >= 0 && sel <= table.getRowCount() - 1)
      table.setRowSelectionInterval(sel, sel);
  }

  void UpdateTable(int sel) {
    DoUpdateTable(jTable1,sel);
  }

  void this_windowOpened(WindowEvent e) {
   jTable1.requestFocus(true);
  }

  void jButton5_keyPressed(KeyEvent e) {
    if (e.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
      jButton5_actionPerformed(null);
  }

}

class ConfigureNamespacesDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_jButton1_actionAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class ConfigureNamespacesDialog_jButton2_actionAdapter implements java.awt.event.ActionListener {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_jButton2_actionAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class ConfigureNamespacesDialog_jButton3_actionAdapter implements java.awt.event.ActionListener {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_jButton3_actionAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class ConfigureNamespacesDialog_jButton4_actionAdapter implements java.awt.event.ActionListener {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_jButton4_actionAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class ConfigureNamespacesDialog_jButton5_actionAdapter implements java.awt.event.ActionListener {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_jButton5_actionAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton5_actionPerformed(e);
  }
}

class ConfigureNamespacesDialog_this_windowAdapter extends java.awt.event.WindowAdapter {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_this_windowAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void windowOpened(WindowEvent e) {
    adaptee.this_windowOpened(e);
  }
}

class ConfigureNamespacesDialog_jButton5_keyAdapter extends java.awt.event.KeyAdapter {
  ConfigureNamespacesDialog adaptee;

  ConfigureNamespacesDialog_jButton5_keyAdapter(ConfigureNamespacesDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jButton5_keyPressed(e);
  }
}