/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.dom.DOMResult;

import org.apache.xerces.impl.xs.util.StringListImpl;

import org.apache.xerces.impl.dv.xs.*;

import java.text.Collator;



// Imported java.io classes
import java.io.IOException;
import java.io.FileNotFoundException;

// Imported SAX classes
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

// Imported DOM classes
import org.w3c.dom.Document;
import org.w3c.dom.Node;

// Imported Serializer classes
import org.apache.xalan.serialize.Serializer;
import org.apache.xalan.serialize.SerializerFactory;

import org.apache.xalan.templates.OutputProperties;
import org.apache.xalan.xslt.*;


// Imported JAVA API for XML Parsing classes
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;



import java.io.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.w3c.dom.*;
import org.w3c.dom.traversal.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.apache.xpath.*;
import org.apache.xerces.impl.xs.identity.*;



import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.URL;
import java.util.*;

import javax.swing.text.*;
import javax.swing.undo.*;
import javax.swing.event.*;
import javax.swing.*;

//import xni.Counter;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.plaf.basic.*;//import org.apache.xerces.dom.DSCCDocumentImpl;
import javax.swing.table.*;
import javax.swing.text.*;
import javax.swing.tree.*;

import org.apache.xerces.dom.*;
import org.apache.xerces.impl.*;
import org.apache.xerces.impl.xs.*;
import org.apache.xerces.util.*;
import org.apache.xerces.xni.*;
import org.apache.xerces.xni.parser.*;
import org.apache.xerces.parsers.*;
import org.apache.xerces.parsers.XML11Configuration;
import org.apache.xerces.xs.*;
import org.apache.xml.serialize.*;
import org.w3c.dom.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.*;
import com.borland.jbcl.layout.*;
//import ui.*;


import javax.swing.text.*;
import javax.swing.event.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FindDialog extends JDialog {
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JComboBox jComboBox1 = new JComboBox();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JComboBox jComboBox2 = new JComboBox();

  public FindDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public FindDialog(Frame parent) {
    this(parent, "", true);
  }


  private void jbInit() throws Exception {
    jPanel1.setMinimumSize(new Dimension(200, 150));
    jPanel1.setPreferredSize(new Dimension(270, 200));
    jPanel1.setBounds(new Rectangle(2, 0, 269, 192));
    jPanel1.setLayout(null);
    jLabel1.setText("Text to find (for Source pane):");
    jLabel1.setBounds(new Rectangle(13, 19, 183, 15));
    jLabel2.setText("XPath expression (for Edit pane):");
    jLabel2.setBounds(new Rectangle(14, 87, 197, 15));
    jComboBox1.setEditable(true);
    jComboBox1.setBounds(new Rectangle(14, 107, 245, 21));
    jComboBox1.addKeyListener(new FindDialog_jComboBox1_keyAdapter(this));
    jButton1.setBounds(new Rectangle(16, 153, 73, 25));
    jButton1.setText("Find");
    jButton1.addActionListener(new FindDialog_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(113, 153, 73, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new FindDialog_jButton2_actionAdapter(this));
    jComboBox2.setEditable(true);
    jComboBox2.setBounds(new Rectangle(14, 40, 245, 21));
    jComboBox2.addKeyListener(new FindDialog_jComboBox2_keyAdapter(this));
    jComboBox2.getEditor().getEditorComponent().addKeyListener(new FindDialog_jComboBox2_keyAdapter(this));
    jComboBox1.getEditor().getEditorComponent().addKeyListener(new FindDialog_jComboBox1_keyAdapter(this));

    this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    this.setResizable(false);
    this.setTitle("Find");
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jButton1, null);
    jPanel1.add(jButton2, null);
    jPanel1.add(jComboBox1, null);
    jPanel1.add(jComboBox2, null);
    this.getContentPane().add(jPanel1, null);
    this.setModal(true);
  }

  static FindDialog dlg=null;

  boolean OkPressed=false;

  static public void FindAgain(Object doc, boolean fromStart, Frame3 frame) {
    if (dlg==null) {
      Find(doc, frame);
      return;
    }
    try {
      boolean found = false;
      if (doc instanceof JTextArea) {
        JTextArea ta = frame.jTextXML;
        String s = ta.getText();
        int i = fromStart ? 0 : ta.getSelectionEnd();
        String findStr = (String) dlg.jComboBox2.getEditor().getItem() ;
        i = s.indexOf(findStr, i);
        if (i != -1) {
          ta.setSelectionStart(i);
          ta.setSelectionEnd(i + findStr.length());
          found = true;
        }
      }
      else {
        Node root = ( (Node) ( (VirtualDomTreeModel) frame.m_tree.getModel()).
                     getRoot());
        String xpath = (String) dlg.jComboBox1.getEditor().getItem();
        NodeIterator nl = XPathAPI.selectNodeIterator(root, xpath);
        Node n;

        if (fromStart || frame.GetSelectedNode() == null) {
          n = nl.nextNode();
        }
        else {
          Node nf=nl.nextNode();
          n=nf;
          while (n != null && n != frame.GetSelectedNode())
            n = nl.nextNode();
          if (n!=null)
            n = nl.nextNode(); else
            n = nf;
        }
        while (! (n instanceof PSVIElementNSImpl) && (n = nl.nextNode()) != null)
          ;
        if (n != null) {
          frame.SelectTreeNode( (PSVIElementNSImpl) n);
          found = true;
        }
      }
      if (!found)
        JOptionPane.showMessageDialog(null, "No more occurences found", null,
                                      JOptionPane.INFORMATION_MESSAGE);
    }
    catch(Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), null,
                                      JOptionPane.ERROR_MESSAGE);
    }
  }

  static public void Find(Object doc, Frame3 frame) {
    if (dlg==null)
      dlg = new FindDialog(frame);
    dlg.OkPressed=false;
    dlg.setLocationRelativeTo(null);
    NodeImpl n=(NodeImpl)frame.GetSelectedNode();
    if (n!=null) {
      String xpath=".//";
      String ns=n.getNamespaceURI();
      if (ns!=null) {
        ElementImpl root=(ElementImpl)n.getOwnerDocument().getDocumentElement();
        String pref=root.lookupPrefix(ns);
        if (pref==null)
        if (!(doc instanceof JTextArea)) {
          int res=JOptionPane.showConfirmDialog(null,
              "<html>No prefix is found for namespace \"" + ns + "\". <br>Qualified elements must be prefixed in XPath expressions. <br>Shall it be genenerated now?</html>", null,
                                        JOptionPane.YES_NO_CANCEL_OPTION);
          if (JOptionPane.YES_OPTION==res)  {
            pref=IDConstraintHelper.getSuitableNamespacePrefix((Element)n);
            if (pref==null)
            for (int i = 1; root.getAttributes().getNamedItem(pref = "pref" + i) != null; i++)
              ;
            IDConstraintHelper.AddPrefix(root, pref, ns);
            frame.SetDomModified(root);
          } else
            xpath=null;
        } else
          xpath=null;
        if (xpath!=null)
          xpath=xpath+pref+":";
      }
      if (xpath!=null) {
        xpath = xpath + n.getLocalName();
        if (frame.GetSelectedAttribute() != null)
          xpath = xpath + "[@" + frame.GetSelectedAttribute().getName() + "=\"" +
              frame.GetSelectedAttribute().getValue() + "\"]";
        dlg.jComboBox1.setSelectedItem(xpath);
      }
    }
    dlg.show();
    if (dlg.OkPressed) {
      FindAgain(doc,true,frame);
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    OkPressed=true;
    dispose();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    dispose();
  }

  void jComboBox2_keyPressed(KeyEvent e) {
    if (e.getKeyCode()==java.awt.event.KeyEvent.VK_ENTER)
      jButton1_actionPerformed(null);
    if (e.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
      jButton2_actionPerformed(null);
  }



}

class FindDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  FindDialog adaptee;

  FindDialog_jButton1_actionAdapter(FindDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class FindDialog_jButton2_actionAdapter implements java.awt.event.ActionListener {
  FindDialog adaptee;

  FindDialog_jButton2_actionAdapter(FindDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class FindDialog_jComboBox2_keyAdapter extends java.awt.event.KeyAdapter {
  FindDialog adaptee;

  FindDialog_jComboBox2_keyAdapter(FindDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jComboBox2_keyPressed(e);
  }
}

class FindDialog_jComboBox1_keyAdapter extends java.awt.event.KeyAdapter {
  FindDialog adaptee;

  FindDialog_jComboBox1_keyAdapter(FindDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jComboBox2_keyPressed(e);
  }
}
