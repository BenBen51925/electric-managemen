/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

import java.awt.*;
import javax.swing.*;
import com.borland.jbuilder.xml.database.template.*;
import java.beans.*;
import java.awt.event.*;


public class OptionsDialog extends JDialog {
  JPanel panel1 = new JPanel();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JComboBox jComboBox1 = new JComboBox();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JComboBox jComboBox4 = new JComboBox();
  JButton jButton1 = new JButton();

  public OptionsDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public OptionsDialog(JFrame parent) {
    this(parent, "", false);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jTabbedPane1.setBounds(new Rectangle(10, 8, 383, 178));
    jPanel1.setLayout(null);
    jComboBox1.setBounds(new Rectangle(26, 35, 165, 21));
    jComboBox1.addItemListener(new OptionsDialog_jComboBox1_itemAdapter(this));
    jLabel1.setText("Choose a font for the source editor:");
    jLabel1.setBounds(new Rectangle(26, 15, 284, 15));
    jLabel2.setBounds(new Rectangle(26, 15, 284, 15));
    jLabel2.setText("Choose a font for the source editor:");
    jLabel3.setBounds(new Rectangle(26, 79, 284, 15));
    jLabel3.setText("Choose a font for the input fields in the Edit pane:");
    jComboBox4.setBounds(new Rectangle(26, 97, 165, 21));
    jComboBox4.addItemListener(new OptionsDialog_jComboBox4_itemAdapter(this));
    panel1.setOpaque(true);
    panel1.setPreferredSize(new Dimension(400, 230));
    this.setTitle("Options");
    jButton1.setBounds(new Rectangle(11, 195, 73, 25));
    jButton1.setVerifyInputWhenFocusTarget(true);
    jButton1.setText("Close");
    jButton1.addActionListener(new OptionsDialog_jButton1_actionAdapter(this));
    getContentPane().add(panel1);
    panel1.add(jTabbedPane1, null);
    panel1.add(jButton1, null);
    jTabbedPane1.add(jPanel1,    "Fonts");
    jPanel1.add(jComboBox1, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jComboBox4, null);
  }



  void jComboBox1_itemStateChanged(ItemEvent e) {
    if (e.getStateChange()==ItemEvent.SELECTED)
      ((Frame3)getParent()).setFontFamilyForSRC((String)jComboBox1.getSelectedItem());
  }

  static void showDialog(Frame3 parent) {
    OptionsDialog dlg = new OptionsDialog(parent);
    dlg.setLocationRelativeTo(parent);

    String[] familyNames =
     java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
    dlg.jComboBox1.setModel(new DefaultComboBoxModel(familyNames));
    dlg.jComboBox4.setModel(new DefaultComboBoxModel(familyNames));

    dlg.jComboBox1.setSelectedIndex(XDocUtilities.FindStringInStrings(parent.jTextXML.getFont().getFamily(),familyNames));
    dlg.jComboBox4.setSelectedIndex(XDocUtilities.FindStringInStrings(parent.jTextContent.getFont().getFamily(),familyNames));
    dlg.show();
  }

  void jComboBox4_itemStateChanged(ItemEvent e) {
    if (e.getStateChange()==ItemEvent.SELECTED)
      ((Frame3)getParent()).setFontFamilyForDOM((String)jComboBox4.getSelectedItem());
  }

  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }
}

class OptionsDialog_jComboBox1_itemAdapter implements java.awt.event.ItemListener {
  OptionsDialog adaptee;

  OptionsDialog_jComboBox1_itemAdapter(OptionsDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void itemStateChanged(ItemEvent e) {
    adaptee.jComboBox1_itemStateChanged(e);
  }
}

class OptionsDialog_jComboBox4_itemAdapter implements java.awt.event.ItemListener {
  OptionsDialog adaptee;

  OptionsDialog_jComboBox4_itemAdapter(OptionsDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void itemStateChanged(ItemEvent e) {
    adaptee.jComboBox4_itemStateChanged(e);
  }
}

class OptionsDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  OptionsDialog adaptee;

  OptionsDialog_jButton1_actionAdapter(OptionsDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}