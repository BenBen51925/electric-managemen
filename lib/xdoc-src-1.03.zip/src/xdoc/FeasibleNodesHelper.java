/*
 * XDoc
 *
 * Copyright (C) 2004, Jörg Kiegeland <xdoc@kiegeland.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package xdoc;

import java.util.*;

import org.apache.xerces.dom.*;
import org.apache.xerces.impl.xs.*;
import org.apache.xerces.xs.*;
import org.w3c.dom.*;



public class FeasibleNodesHelper {

  static void ValidNodesForChildAppending(Node node,Vector Required,Vector Optional) {
    if (node==null) return;
    Node node2=node.getLastChild();
    while (node2!=null && node2.getNodeType()!=Node.ELEMENT_NODE) {
      node2=node2.getPreviousSibling();
    }
    if (node2!=null)
      ValidNodesAfter(node2,Required,Optional); else
    if (node instanceof PSVIElementNSImpl)
      getInsertableElements(((PSVIElementNSImpl)node).getTypeDefinition(),GetChildrenDecl(node),0,Required,Optional);
  }

  static void ValidNodesBefore(Node node,Vector Required,Vector Optional) {
    if (node==null) return;
    Node node2=node;
    do {
      node2=node2.getPreviousSibling();
    } while (node2!=null && node2.getNodeType()!=Node.ELEMENT_NODE);
    if (node2!=null)
      ValidNodesAfter(node2,Required,Optional); else
    if (node.getParentNode() instanceof PSVIElementNSImpl)
      getInsertableElements(((PSVIElementNSImpl)node.getParentNode()).getTypeDefinition(),GetChildrenDecl(node.getParentNode()),0,Required,Optional);
  }


  static void  ValidNodesAfter(Node node,Vector Required,Vector Optional) {
    if (node==null) return;
    if (node.getParentNode() instanceof PSVIElementNSImpl)
     getInsertableElements(((PSVIElementNSImpl)node.getParentNode()).getTypeDefinition(),GetChildrenDecl(node.getParentNode()),VirtualDomTreeModel.GetChildrenNodes(node.getParentNode()).indexOf(node)+1,Required,Optional);
  }

  protected static Vector GetAttrChildrenDecl(Node node) {
    Vector res=new Vector();
    for (int i=0; i<node.getAttributes().getLength(); i++) {
      PSVIAttrNSImpl attr=(PSVIAttrNSImpl)node.getAttributes().item(i);
      if (attr.getAttributeDeclaration()!=null)
        res.add(attr.getAttributeDeclaration());
    }
    return res;
  }


  protected static void ValidAttributes2(XSTypeDefinition d,Vector children,Vector Required,Vector Optional) {
    if (d==null || !(d instanceof XSComplexTypeDecl)) return;
    XSComplexTypeDecl CT=(XSComplexTypeDecl)d;
    XSAttributeGroupDecl ad=CT.getAttrGrp();
    CanMapAttributes(children,ad,Required,Optional);
  }

  static boolean CanMapAttributes(Vector cnodes,XSAttributeGroupDecl part,Vector RequiredNodes,Vector OptionalNodes) {

    XSObjectList parts=part.getAttributeUses();

    for (int i = 0; i < parts.getLength(); i++) {
      XSAttributeUse cpart = (XSAttributeUse) parts.item(i);

      int i2=0;
      for (; i2<cnodes.size(); i2++)
        if (cnodes.get(i2)==cpart.getAttrDeclaration()) break;

      if (i2<cnodes.size())
        cnodes.remove(i2); else
      if (cpart.getRequired())
        RequiredNodes.add(cpart.getAttrDeclaration()); else
        OptionalNodes.add(cpart.getAttrDeclaration());
    }
    return RequiredNodes.isEmpty();
  }


  public static void ValidAttributes(Node node,Vector Required,Vector Optional) {
    if (node instanceof PSVIElementNSImpl)
      ValidAttributes2(((PSVIElementNSImpl)node).getTypeDefinition(),GetAttrChildrenDecl(node),Required,Optional);
  }

  public static Vector RequiredAttributes(Node node) {
    Vector Required=new Vector();
    if (node instanceof PSVIElementNSImpl)
      ValidAttributes2(((PSVIElementNSImpl)node).getTypeDefinition(),new Vector(),Required,new Vector());
    return Required;
  }


  //returns true if the node can be matched up in the content model of its parent
  static public boolean AcceptedByParent(Node node) {
    if (node instanceof PSVIElementNSImpl && node.getParentNode() instanceof PSVIElementNSImpl && ((PSVIElementNSImpl)node.getParentNode()).getTypeDefinition()==null) return true;
    if (!(node instanceof PSVIElementNSImpl)) return false;

    if (node.getParentNode()==node.getOwnerDocument()) return true;

    Vector siblings=GetChildrenDecl(node.getParentNode());

    if (node.getParentNode() instanceof PSVIElementNSImpl) {
      XSTypeDefinition d = ( (PSVIElementNSImpl) node.getParentNode()).getTypeDefinition();


      if (d instanceof XSComplexTypeDecl && ( (XSComplexTypeDecl) d).
            getParticle()!=null) {

        XSParticle ppart = ( (XSComplexTypeDecl) d).
            getParticle();
        int childPos = VirtualDomTreeModel.GetChildrenNodes(node.getParentNode()).indexOf(node);
        siblings.setSize(childPos+1);
        Vector RequiredNodes = new Vector();
        Vector OptionalNodes = new Vector();
        getAppendableElements(siblings, ppart, RequiredNodes, OptionalNodes, true);
        return siblings.isEmpty();
      }
    }
    return false;

  }


  static public Vector GetChildrenDecl(Node node) {
    Vector v=new Vector();
    int LookAtIndex=-1;
    for (int i=0; i<node.getChildNodes().getLength(); i++) {
      Node _cnode = node.getChildNodes().item(i);
      if (_cnode instanceof PSVIElementNSImpl)
        v.add(((PSVIElementNSImpl)_cnode).getElementDeclaration());
    }
    return v;
  }

  static void getInsertableElements(XSTypeDefinition d,Vector children,int childPos,Vector Required,Vector Optional) {

    if (d == null || ! (d instanceof XSComplexTypeDecl))
      return;

    XSComplexTypeDecl CT = (XSComplexTypeDecl) d;

    if (CT.getContentType() == XSComplexTypeDecl.CONTENTTYPE_EMPTY ||
        CT.getContentType() == XSComplexTypeDecl.CONTENTTYPE_SIMPLE)
      return;

    XSParticle ppart = CT.getParticle();
    XSModelGroupImpl model = (XSModelGroupImpl) ppart.getTerm();

    Vector siblings = (Vector) children.clone();
    if (model.getCompositor() != XSModelGroup.COMPOSITOR_ALL)
      siblings.setSize(childPos);

    Vector RequiredNodes = new Vector();
    Vector OptionalNodes = new Vector();

    getAppendableElements(siblings, ppart, RequiredNodes, OptionalNodes, true);
    RequiredNodes = XDocUtilities.UniqueVector(RequiredNodes);
    OptionalNodes.addAll(RequiredNodes);
    OptionalNodes = XDocUtilities.UniqueVector(OptionalNodes);
    Vector v = getValidInitialElements(RequiredNodes, true);
    int RequiredCount = v.size();
    v.addAll(getValidInitialElements(OptionalNodes, false));
    v = XDocUtilities.UniqueVector(v);
    siblings = (Vector) children.clone();
    RequiredNodes.clear();
    OptionalNodes.clear();
    getAppendableElements(siblings, ppart, RequiredNodes, OptionalNodes, true);
    int LastAcceptedChild = children.size() - siblings.size() - 1;
    if (childPos <= LastAcceptedChild) //if even nodes after the designated position are matched,
      RequiredCount = 0;
    Vector RequiredAfterRequired=new Vector();
    for (int i = 0; i < v.size(); i++) {
      Vector siblings2 = (Vector) children.clone();
      siblings2.insertElementAt(v.get(i), childPos);
      Vector RequiredNodes2=new Vector();
      Vector OptionalNodes2=new Vector();
      getAppendableElements(siblings2, ppart, RequiredNodes2, OptionalNodes2, true);
      if (siblings2.size() <= siblings.size())
        if (i < RequiredCount)
          Required.add(v.get(i)); else
          Optional.add(v.get(i));
    }
  }


  //returns true if the attribute "node" can be added to element "pnode"
  static boolean AcceptedAttrByParent(PSVIAttrNSImpl node,Node pnode) {

    if (isReservedAttribute(node)) return true;
    Vector siblings=GetAttrChildrenDecl(pnode);

    if (pnode instanceof PSVIElementNSImpl) {

      if (((PSVIElementNSImpl)pnode).getTypeDefinition() instanceof XSComplexTypeDecl) {
        XSAttributeGroupDecl part = ( (XSComplexTypeDecl) ((PSVIElementNSImpl)pnode).getTypeDefinition()).
            getAttrGrp();
        int childPos = siblings.indexOf(((PSVIAttrNSImpl)node).getAttributeDeclaration());
        siblings.setSize(childPos+1);
        Vector RequiredNodes = new Vector();
        Vector OptionalNodes = new Vector();
        CanMapAttributes(siblings, part, RequiredNodes, OptionalNodes);
        return siblings.isEmpty();
      }
    }
    return false;
  }


  //getAppendableElements matches up element declarations in "cnodes" against
  //the content model represented by "part" (in the order they appear in the Vector "cnodes");
  //required/optional elements of the content model are added to "Required"/"Optional" (represented
  //as element declarations or <xs:any> declarations);
  //Note: required declarations are only added if "cnodes" cannot satisfy the content model
  //Note: when the method returns, vectors still in "cnodes" could not get matched up
  protected static void getAppendableElements(Vector cnodes,XSParticle part,Vector Required,Vector Optional,boolean IsTop) {

    int Occurs=0; //how often the partical's term can be mapped, minOccurs<=Occurs<=maxOccurs

    int PrevOptionalCount=(Optional!=null ? Optional.size() : 0);

    while (part.getMaxOccursUnbounded() || Occurs<part.getMaxOccurs()) {

      boolean OccuredOnce=false;

      if (!cnodes.isEmpty() && MapSingle(cnodes.firstElement(),part.getTerm())) {
          cnodes.remove(0);
          OccuredOnce=true;
          assert(Optional.size()==0);
      } else
      if (part.getTerm() instanceof XSModelGroupImpl) {

        XSModelGroupImpl model=(XSModelGroupImpl)part.getTerm();
        XSObjectList parts=model.getParticles();

        for (int i = 0; i < parts.getLength(); i++) {
          XSParticleDecl cpart = (XSParticleDecl) parts.item(i);

          int OldNodesCount=cnodes.size();
          if (model.getCompositor() == XSModelGroup.COMPOSITOR_ALL) {
           //now ANY node of cnodes can match (not only the first)
           for (int i2=0; i2<cnodes.size(); i2++)
           if (MapSingle(cnodes.get(i2),cpart.getTerm())) {
             cnodes.remove(i2);
             break;
           }
          } else {
            getAppendableElements(cnodes, cpart, Required, Optional, false);
            if (!Required.isEmpty())
              return;
          }
          boolean MapPart=OldNodesCount!=cnodes.size();
          OccuredOnce = OccuredOnce || MapPart;

          if (model.getCompositor() == XSModelGroup.COMPOSITOR_ALL) {
            if (!MapPart)
              if (minEffectiveTotalRange_Not_0(cpart))
                Required.add(cpart); else
                Optional.add(cpart);
            if (i == parts.getLength()-1) {
              if (!OccuredOnce && 0==part.getMinOccurs()) {
                //since minOccurs=0, all nodes are optional
                Optional.addAll(0,Required);
                Required.clear();
              }
              return;
            }
          }
          if (model.getCompositor() == XSModelGroup.COMPOSITOR_SEQUENCE) {
            if (!MapPart && minEffectiveTotalRange_Not_0(cpart)) {
              if (OccuredOnce) {
                Required.add(cpart);
                return;
              }
              else
                break;
            }
          }
          if (model.getCompositor() == XSModelGroup.COMPOSITOR_CHOICE) {
            if (MapPart)
              break;
            if (cnodes.isEmpty())
              break; //for speed only
          }
        }
      }
      if (!OccuredOnce) break;
      Occurs+=1;
      if (cnodes.isEmpty()) break;
    }
    if (Occurs<part.getMinOccurs() && (Occurs>=1 || IsTop && minEffectiveTotalRange_Not_0((XSParticleDecl)part))) {
      Required.add(part);
      return;
    }
    if (Optional!=null)
    if (cnodes.isEmpty()) //only interested for last node
    if (part.getMaxOccursUnbounded() || Occurs<part.getMaxOccurs()) {
      if (Occurs==0)
        Optional.setSize(PrevOptionalCount);//for speed only; remove items which are already included in "part"
      Optional.add(part);
    }
  }


  static SubstitutionGroupHandler fSubstitutionGroupHandler=new SubstitutionGroupHandler(null);

  static boolean MapSingle(Object ob, XSTerm term) {
    if (ob==term) return true;
    if (ob instanceof XSElementDecl && term instanceof XSElementDeclaration) {
      return fSubstitutionGroupHandler.inSubstitutionGroup((XSElementDecl)ob,(XSElementDecl)term);
    }
   if (term instanceof XSWildcardDecl) {
     XSWildcardDecl exemplar=(XSWildcardDecl)term;
     if (ob instanceof XSWildcardDecl)
      return ((XSWildcardDecl) ob).isSubsetOf(exemplar); else
     if (ob == null || ob instanceof XSElementDeclaration)
      return CreateWildcard( (XSElementDeclaration) ob).isSubsetOf(exemplar);
   }
   return false;
  }


  /**
   * We want to know if part.minEffectiveTotalRange() is >=1.
   * This could be determined by part.minEffectiveTotalRange()>=1, but
   * it has a bug when reading in XHTML 1.1 schema, namely
   * fParticles.length yields a Null-Pointer-Exception if fParticles is null.
   * This happens in XSModelGroupImpl.
   * Now instead accessing fParticles.length, we access fParticleCount.
   */
  static public boolean minEffectiveTotalRange_Not_0(XSParticleDecl part) {
      if (part.fType == XSParticleDecl.PARTICLE_EMPTY || part.fMinOccurs==0) return false;
      if (part.fType ==  XSParticleDecl.PARTICLE_MODELGROUP) {
          XSModelGroupImpl model=(XSModelGroupImpl) part.fValue;
          //if (model.fParticles==null) return false;
          if (model.fCompositor == XSModelGroup.COMPOSITOR_CHOICE) {
            for (int i=0; i<model.fParticleCount; i++)
              if (!minEffectiveTotalRange_Not_0(model.fParticles[i]))
                return false;
            return model.fParticleCount>0;
          } else {
            for (int i=0; i<model.fParticleCount; i++)
              if (minEffectiveTotalRange_Not_0(model.fParticles[i]))
                return true;
            return false;
          }
      }
      return true;
  }


  static XSWildcardDecl CreateWildcard(XSElementDeclaration d) {
    XSWildcardDecl wc=new XSWildcardDecl();
    if (d==null) {
      wc.fType=XSWildcard.NSCONSTRAINT_ANY;
      return wc;
    }
    wc.fType=XSWildcard.NSCONSTRAINT_LIST;
    wc.fNamespaceList=new String[] {d.getNamespace()};
    return wc;
  }


  //For all element sequences satisfying the content model "part",
  //the first element is collected into "validElements".
  //If cheapest==true, then only shortest element sequences are looked at.
  //Note that COMPOSITOR_ALL is not looked at (only COMPOSITOR_CHOICE and COMPOSITOR_SEQUENCE),
  //since it is never outputted in "Required" or "Optional" of getAppendableElements
  static void getValidInitialElements(XSParticleDecl part, Vector validElements, boolean cheapest) {

    if (part.getMaxOccurs()==0) return;

    if (cheapest && !minEffectiveTotalRange_Not_0(part)) return;

    if (part.getTerm() instanceof XSElementDeclaration || part.getTerm() instanceof XSWildcardDecl) {
      validElements.add(part.getTerm());
      return;
    }

    XSModelGroupImpl model=(XSModelGroupImpl)part.getTerm();
    XSObjectList parts=model.getParticles();

    if (model.getCompositor() == XSModelGroup.COMPOSITOR_CHOICE) {

      int min=model.minEffectiveTotalRange();

      for (int i = 0; i < parts.getLength(); i++) {
        XSParticleDecl cpart = (XSParticleDecl) parts.item(i);
        if (!cheapest || cpart.minEffectiveTotalRange()==min)
          getValidInitialElements(cpart,validElements,cheapest);
      }
    }

    if (model.getCompositor() == XSModelGroup.COMPOSITOR_SEQUENCE) {

      for (int i = 0; i < parts.getLength(); i++) {
        XSParticleDecl cpart = (XSParticleDecl) parts.item(i);
        getValidInitialElements(cpart, validElements, cheapest);
        if (minEffectiveTotalRange_Not_0(cpart))
          break;
      }
    }

  }

  static Vector getValidInitialElements(Vector v,boolean cheapest) {
    Vector validElements=new Vector();
    for (int i=0; i<v.size(); i++)
      getValidInitialElements((XSParticleDecl) v.get(i),validElements,cheapest);
    return XDocUtilities.UniqueVector(validElements);
  }

  //some attributes need not (and are not allowed) to be declared in a XML Schema
  //(so looking for their declaration is not senseful):
  static boolean isReservedAttribute(NodeImpl attr) {
    //see http://www.w3.org/TR/xmlschema-1/#no-xmlns
    //and schema build-in attribute declarations (see http://www.w3.org/TR/xmlschema-1/#d0e3067)
    return ("xmlns").equals(attr.getLocalName()) || ("xmlns").equals(attr.getPrefix()) ||
        ("http://www.w3.org/2001/XMLSchema-instance").equals(attr.getNamespaceURI()) && (("type").equals(attr.getLocalName()) || ("nil").equals(attr.getLocalName()) || ("schemaLocation").equals(attr.getLocalName()) || ("noNamespaceSchemaLocation").equals(attr.getLocalName()));
  }


}

