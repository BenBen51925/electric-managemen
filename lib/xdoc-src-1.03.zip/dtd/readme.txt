
DTDs downloaded from:

Portiko:
http://www.portiko.de/portiko/portiko.xml?chap_id=app_support&sct_id=sct_app_support_downloads

character entities:
http://www.w3.org/TR/xhtml-modularization/DTD/xhtml-symbol.ent
http://www.w3.org/TR/xhtml-modularization/DTD/xhtml-lat1.ent
http://www.w3.org/TR/xhtml-modularization/DTD/xhtml-special.ent

These character entities are designed for XHTML but not used currently.


