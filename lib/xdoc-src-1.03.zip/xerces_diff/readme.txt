
/*Changes to Xerces source:
*******XSDHandler.java:
commented out
 sg.addDocument(null, (String)fDoc2SystemId.get(currSchemaInfo.fSchemaDoc));
and un-commented
 sg.addDocument(currSchemaInfo.fSchemaDoc, (String)fDoc2SystemId.get(currSchemaInfo));

see http://issues.apache.org/jira/browse/XERCESJ-1086

*******SchemaGrammar.java:
Changed complete method addDocument()

see http://issues.apache.org/jira/browse/XERCESJ-1086

*******DOMNormalizer.java: replaced



 ..

                 AttributeMap attributes = (elem.hasAttributes()) ? (AttributeMap) elem.getAttributes() : null;

                 // fix namespaces and remove default attributes
                 if ((fConfiguration.features & DOMConfigurationImpl.NAMESPACES) !=0) {
                     // fix namespaces
                     // normalize attribute values
                     // remove default attributes
                     namespaceFixUp(elem, attributes);
                 } else {
 ..

 with



 ..

                 AttributeMap attributes = (elem.hasAttributes()) ? (AttributeMap) elem.getAttributes() : null;

                 // fix namespaces and remove default attributes
                 if ((fConfiguration.features & DOMConfigurationImpl.NAMESPACES) !=0) {
                     // fix namespaces
                     // normalize attribute values
                     // remove default attributes
                     namespaceFixUp(elem, attributes);
                     attributes = (elem.hasAttributes()) ? (AttributeMap) elem.getAttributes() : null; //new line
                 } else {
 ..


See http://issues.apache.org/jira/browse/XERCESJ-1074

 *******EncodingMap: replaced

         fIANA2JavaMap.put("UTF-16",           "UTF-16");

with

         fIANA2JavaMap.put("UTF-16",           "Unicode");

Otherwise the encoding is not recognized as Unicode in Encodings.java and the last
 printable character will be DEFAULT_LAST_PRINTABLE instead of LAST_PRINTABLE_UNICODE.
 This results in that every character greater than 0x7F will be escaped by a character reference.

Good News: this error is resolved, see http://issues.apache.org/jira/browse/XERCESJ-1073
(but not included in v2.6.2 yet)

 *******XSModelGroupImpl: replaced


        int min = 0, one;
        if (fParticle.length > 0)
            min = fParticles[0].minEffectiveTotalRange();

with


        int min = Integer.MAX_VALUE, one;
        if (fParticleCount > 0)
            min = fParticles[0].minEffectiveTotalRange();


Seems to be resolved at http://issues.apache.org/jira/browse/XERCESJ-943
(but not included in v2.6.2 yet)

*/
