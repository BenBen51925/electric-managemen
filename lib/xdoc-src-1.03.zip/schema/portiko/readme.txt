Notes to portiko dtd -> schema conversion:
 <caption> element removed; is it superflous?
 Done with XMLSPY; MATHML-schema is no longer direct referenced by schemaLocation, it is "outsourced" in mathml2 directory;
 XMLSPY has a bug: generates "name" attributes where "ref" attributes are present; deleted "name" attributes per hand;
 note that an element declaration must not have a prefix in the "name" attribute: all declared elements belong to targetNamespace or are imported by <import>; to force a prefix, use "form" attribute as defined by XML Schema
 XMLSPY copies schema of "vc" and "xsql" target namespaces into one file; out-sourced those via <import> elements; 
 default prefix namespace declarations are not possible with XML Schema, but with DTD


*Added various key/keyref elements.
*Changed type of crossref.ref
*Exchanged <td> and <th> position so that <td> is created as default and not <th>