For existing XSLT documents (.xsl) to work, having the form <xsl:stylesheet> and 
the target result elements of targetnamespace X without prefix, one should declare
<xsl:stylesheet xmlns="X">.

One should use xslt.xsd for producing ANY result elements, with the error
that you cannot include XSLT *into* the result elements (only elsewhere).
For XHTML it is shown how to mix both namespaces (xslt+xhtml.xsd).

The namespace of XSLT is stylesheet http://www.w3.org/1999/XSL/Transform.

The base schema for XSLT is xslt.xsd.

The schema for XSLT for XHTML is xslt+xhtml.xsd. This schema
imports xhtml11+xslt-model.xsd, which itself modifies XHTML so that it
can contain XSLT elements, but there are some element combinations not working.

The version attribute of <stylesheet> has now the new added type "versionType"
because it was invalid before to have a default value for a required
attribute (since if the attribute is not specified, a validation error is generated
instead of inserting the default value).

Since XHTML Modularization is build modular, it was easy to include XSLT elements in there.
Other target namespaces of XSLT are not implemented!

Now following problem exist:
For included XHTML elements with an attribute of type e.g. ID or URI, expressions
like <div id="{@ident}"> are not possible unless the attribute is redefined,
but since all attributes need redefinition if not defined as xs:string, 
this is not done. An example is included for the id attribute in xhtml11+xslt-model.xsd.
This example is commented out because:

To make in even worser, there is a bug with attributeGroup redefinition:
http://www.mail-archive.com/xerces-j-dev@xml.apache.org/msg06274.html
You get a error message like this:
[Error] Circular definitions detected for attribute group ':id_fn3dktizrknc9pi'. Recursively following attribute group references eventually leads back to itself. (file:///C:/XDoc/schema/xhtml-modularization/xhtml-attribs-1.xsd)

