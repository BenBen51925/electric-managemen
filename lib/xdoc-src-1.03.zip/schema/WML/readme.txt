Converted from DTD;

Deleted lines:
<xs:attribute name="xml:lang" type="xs:NMTOKEN"/>
<xs:attribute name="xml:space" type="xs:string" fixed="preserve"/>