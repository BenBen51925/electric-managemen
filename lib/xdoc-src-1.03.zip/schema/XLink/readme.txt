Deleted <!DOCTYPE>.
Deleted use="optional" constructs in global attributes.
XLink is needed by SVG, but certainly can be used in every
other schema as well