Replaced

<xsd:pattern value="([A-Za-z][A-Za-z0-9_-]*:)?[A-Za-z][A-Za-z0-9_\-\.]*"/>


with

<xsd:pattern value="([A-Za-z][A-Za-z0-9_\-]*:)?[A-Za-z][A-Za-z0-9_\-\.]*"/>



Replaced

<xsd:pattern value="\s*[A-Za-z_][A-Za-z0-9\-:_]*\s*"/>


with

<xsd:pattern value="\s*[A-Za-z_][A-Za-z0-9\-:\_]*\s*"/>



Replaced

http://www.w3.org/1999/XSL/TransformX

with

http://www.w3.org/1999/XSL/Transform


