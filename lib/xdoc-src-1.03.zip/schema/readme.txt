
schemas downloaded from:

namespace: http://www.w3.org/2001/xml.xsd
XMLSchema: http://www.w3.org/2001/XMLSchema.xsd
XMLSchema-instance: http://www.w3.org/1999/XMLSchema-instance
xforms: http://www.w3.org/TR/2003/REC-xforms-20031014/sliceA.html
XMLEvents: http://www.w3.org/TR/2003/REC-xml-events-20031014/#a_schema_attribs
svg: http://www.w3.org/TR/2002/WD-SVG11-20020108/SVG.xsd
mathml: http://www.w3.org/Math/XMLSchema/mathml2.tgz
xhtml 1.0: http://www.w3.org/2002/08/xhtml/xhtml1-transitional.xsd
xhtml 1.1: http://www.w3.org/TR/2004/WD-xhtml-modularization-20040218/xhtml-modularization.tgz
portiko dtd: http://www.portiko.de/portiko/portiko.xml?chap_id=app_support&sct_id=sct_app_support_downloads
portiko schema: converted from portiko dtd to schema with XMLSpy
DocBook: http://www.oasis-open.org/docbook/xmlschema/
XSLT: http://www.w3.org/TR/xslt#dtd
P3P: http://www.w3.org/TR/P3P/#Appendix_schema
XSQL: http://xsql.sourceforge.net/
SMIL: http://www.w3.org/TR/smil20/smil-SCHEMA.html
X3D: http://www.web3d.org/x3d/specifications/schema.html
CML: http://www.xml-cml.org/dtdschema/index.html
Soap envelope (used in soap messages): http://schemas.xmlsoap.org/soap/envelope/
Soap encoding: http://schemas.xmlsoap.org/soap/encoding/
WSDL: http://schemas.xmlsoap.org/wsdl/
Soap (in WSDL documents): http://schemas.xmlsoap.org/wsdl/soap/
WSIL: http://schemas.xmlsoap.org/ws/2001/10/inspection/
WML: DTD nach XML Schema �bersetzt, http://www.openmobilealliance.org/tech/DTD/wml13.dtd
JSP: got it from some google cache
XQueryX: http://www.w3.org/TR/xqueryx/#Schema
XLink: http://www.w3.org/TR/2002/WD-SVG11-20020108/xlink.xsd


Not longer supported:
WSDL: http://www.w3.org/2004/08/wsdl/

Note:note all schemas are referenced from XDoc, only the important ones
