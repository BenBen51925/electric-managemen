Deleted <!DOCTYPE> 
Add schemaLocation attribute so that not the web is contacted for xml.xsd and XMLSchema-hasFacetAndProperty.xsd

Commented out in simpleExplicitGroup:
                <xs:attribute name="minOccurs" use="prohibited"/>
                <xs:attribute name="maxOccurs" use="prohibited"/>

(why should it not be possible to have minOccurs in <choice>???)
