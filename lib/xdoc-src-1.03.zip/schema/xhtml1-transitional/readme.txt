Following modification is done to the schema:
Replaced 
     [-+]? 
with 
     [/-+]? 
otherwise not validated by xerces
