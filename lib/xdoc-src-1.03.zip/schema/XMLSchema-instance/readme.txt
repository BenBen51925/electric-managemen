Note that the attributes defined by the schema for the namespace
http://www.w3.org/1999/XMLSchema-instance are already global build-in
attributes, see
http://www.w3.org/TR/xmlschema-1/#d0e3067
So the file XMLSchema-instance.xsd is never used by XDoc, 
it is only listed for completeness.
By the way, this official W3C file declares the 
attribute "null" though it should be "nil", so it really is not meant
to be used by XML processors..

