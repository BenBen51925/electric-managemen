Note since the original not defined a namespace, I defined one:
http://www.oasis-open.org/docbook/xmlschema