Changed

<!ENTITY AsciiName    "[A-Za-z0-9_-]*">

to

<!ENTITY AsciiName    "[A-Za-z0-9_\-]*">


Similar situation to XSLT: we want that XHTML elements can embed jsp elements