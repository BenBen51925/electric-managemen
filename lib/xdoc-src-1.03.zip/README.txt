XDOC
========================
J�rg Kiegeland <joerg@kiegeland.com>

XDoc is a schema-aware XML editor, making use of XML Schema information
to provide assistance to the user.



INSTALL
=======

Unpack the rar to where you want, no further settings needed.
To launch XDoc, see the RUN section.



BUILD
=====

If you have downloaded XDoc's source archive, you can recompile XDoc.
XDoc is written with JBuilder, to use the visual designer(, but
currently, JBuilder has an error starting the designer for Frame3.java.
I would be very pleased if someone finds a way to "connect" to the JBuilder Designer again). 
You should have JBuilder installed.
XDoc.jar is build from the sources.
A Java version >=1.4 is needed.
JBuilder v9 is used.
Use the newest Xerces version at best (v2.6.2). Some files of Xerces
are bug-fixed so you need to rebuild that package with changes. Look at the 
xerces_diff directory. 


RUN
===

Execute "java -jar XDoc.jar" or, in Windows, double-click XDoc.jar 
in the explorer.


EXAMPLES
========
The examples directory contains some examples, see the readme files in the directories 
there for a description


XML Schema
==========
In the schema directory many well-known schemas are present. See the readme.txt in that
directory to know where they are from.