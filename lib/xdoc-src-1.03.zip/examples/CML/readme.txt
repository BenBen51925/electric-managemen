Demonstrate a large instance document for the CML schema to test validation speed.
Note that a validation of the ->WHOLE<- document is done after every change.
This is due to that you can not revalidate single elements with Xerces currently.

If for the namespace http://www.iupac.org/foo/ichi is asked, press OK button. This namespace is not included in XDoc