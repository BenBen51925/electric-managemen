The example is taken from Tomcat 5.0 installation, file webapps\jsp-examples\xml\xml.jsp

Some minor changes to prevent errors: 
*Set XHTML namespace as default
*enclosed <body> content into <div>
*removed align="left"

Note that <%..%> tags cannot be used in XML (cause they are no XML) but they
can be expressed by e.g. <jsp:scriptlet>..</jsp:scriptlet>