This example demonstrate the XSLT for XHTML schemas.
It is taken from the Portiko project.
Note: validating .xsl files is only experimental and is not the idea
of the XSLT specification. There exist no official XSLT schema since 
it is not meant to be validated against, because the target namespace
would need an adjustment to include XSLT elements in return. But even
then, there are insuperable difficulties.
