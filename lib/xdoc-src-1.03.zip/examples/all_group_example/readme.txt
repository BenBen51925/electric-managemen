Demonstrates <xsd:all>: children of purchaseOrder are in reverse order.
Taken from http://www.w3.org/TR/xmlschema-0/
