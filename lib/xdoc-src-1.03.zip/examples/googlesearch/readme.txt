Example of a Web Service definition with a sample query and response.
There is no schema for urn:GoogleSearch given here and 
SOAP messages are in general produced automatically.

http://www.google.com/apis/
These kinds of XML documents for 
RPC are normally generated not by human hands.
