This should be an example to convert an XQueryX document
to an XQuery document. Just choose menu item Edit|Apply Stylesheet. Unfortunately an error occurs in the XSL transformation.