Do you think, that emptyChoice.xml should be valid or not?
In my opinion, yes, since an element with no children
should be able to be mapped with an empty content model.

