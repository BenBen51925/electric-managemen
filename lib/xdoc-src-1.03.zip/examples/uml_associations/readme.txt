This example shows how a conceptual UML association 
can be transformed to XML. See association.png for an illustration
of 2 objects A and B referring to each other. In this 
diagram the min-max notation is used: e.g. object A
must participate on p to q relationships named R to object B
(the standard notation is that p/q are interchanged with r/s,
so this is a trivial difference for 2-ary relationships, but not for
n-ary relationships in general).
The association is converted to XML in a bidirectional fashion:
In element A all references to elements B are build in, and
in B all references to A elements are contained.
This is redundant information, but otherwise the 
cardinality conditions are hard to model. The example ua.xml has following cardinalities:
p=0 q=2 r=2 s=3

Note that some otherkind of redundancy is included: every R element has a "pid"
attribute which must have the same value as the "id" attribute of R's parent element.
This is because the "id" attribute of the parent cannot be referenced from an R context element 
due to a restriction of allowed XPath expressions in the XML Schema specification.

Note secondly, that Xerces not really supports multi-valued keys. So there
may be instances which are recognized as valid by Xerces but are not valid actually.
