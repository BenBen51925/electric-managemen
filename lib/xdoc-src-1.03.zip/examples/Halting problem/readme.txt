This schema declares an element "tg" which has a content model which
*extends* anyType (normally used one *restrict* anyType) by a minimum number
of 5 <many> instances. But since any "many" child element is matched up
by "anyType", there are no "many" instances left for the "many" element declarations
to be matched up. So one can never satisfy this content model. If one try to do so
programmatically (look Frame3.FillNeeded method) one has to ensure that 
one not tries to add more and more "many" children in the hope to satisfy
the content model. The content model not conforms to the specifications
(since parsing should be possible with no look-ahead, technically spoken),
but this is not checked by Xerces internally so one has to assure
a termination of the outer for-loop in Frame3.FillNeeded, see notes there.

A second content model, noted in DTD syntax, is not valid, too:
<!ELEMENT X ( (A,B) | (A,C))>
<x> <a> <c> </x> may be not get matched up since
a parser may stop after having successfully matched up A and then fails
to match up B (because no look-ahead is used, parsing is not retried after the second A).



