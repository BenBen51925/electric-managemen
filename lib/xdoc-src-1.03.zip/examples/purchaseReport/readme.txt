Taken from http://www.w3.org/TR/xmlschema-0/

restriction+substitution_po.xml demonstrates substitution groups,
see <ipo:testComment>.