Demonstrates multifielded key/keyref identity constraints.

Professors are identified by forename/surename pairs, which are 
referenced by lecture elements.

In the example uni.xml, 
<uni:lecture prof_forename="Peter" prof_surname="Pan"/>
"Peter" can be changed to "Hans" because there is a prof called "Hans, Pan" (surenames are identical), or
"Pan" can be changed to "Lustig" because there is a prof called "Peter, Lustig" (fornames are identical).
After the first change you can reach "Hans, Im Gl�ck", finally.
Note that you cannot change to "Albert, Einstein" without getting 
into an invalid state.